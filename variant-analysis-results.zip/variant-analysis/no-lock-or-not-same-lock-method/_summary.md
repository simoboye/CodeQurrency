### Results for "Mutual exclusion absense"

<details>
<summary>Query</summary>

```ql
/**
 * @name Mutual exclusion absense
 * @kind problem
 * @problem.severity warning
 * @id java/no-lock-or-not-same-lock-method
 */

import java
import annotation

predicate isSameLockAndAllFieldOccurences(ControlFlowNode cLock, ControlFlowNode cUnlock) {
  if cLock.toString() = "lock(...)"
  then
    if cUnlock.toString() = "unlock(...)"
    then cLock.getAPredecessor().toString() = cUnlock.getAPredecessor().toString() 
    else isSameLockAndAllFieldOccurences(cLock, cUnlock.getASuccessor())
  else isSameLockAndAllFieldOccurences(cLock.getAPredecessor(), cUnlock)
}

predicate hasSynchronizedBlock(Stmt s) {
  s. getAQlClass() = "SynchronizedStmt" or hasSynchronizedBlock(s.getEnclosingStmt())
}

from Class c, MethodAccess m
where 
  isElementInThreadSafeAnnotatedClass(c, m.getEnclosingCallable())
  and not m.getMethod().toString() = "lock" 
  and not m.getMethod().toString() = "unlock"
  and not m.getMethod().toString() = "<obinit>"
  and not m.getEnclosingCallable() instanceof Constructor
  and not isSameLockAndAllFieldOccurences(m.getControlFlowNode(), m.getControlFlowNode())
  and not hasSynchronizedBlock(m.getEnclosingStmt())
  and not m.getEnclosingCallable().isSynchronized()
select m, "Consider the method it being in a lock and make sure that the lock and unlock is on the same object."

```

</details>

<br />

### Summary

| Repository | Results |
| --- | --- |
| prestodb/presto | [8257 result(s)](./prestodb-presto.md) |
| grpc/grpc-java | [1839 result(s)](./grpc-grpc-java.md) |
| apache/beam | [1244 result(s)](./apache-beam.md) |
| apache/flink | [1187 result(s)](./apache-flink.md) |
| apache/hbase | [20 result(s)](./apache-hbase.md) |
| junit-team/junit4 | [12 result(s)](./junit-team-junit4.md) |
