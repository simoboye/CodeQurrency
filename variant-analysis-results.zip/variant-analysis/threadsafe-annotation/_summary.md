### Results for "thread-safe-annotation.ql"

<details>
<summary>Query</summary>

```ql
import java

from Class c, Element e
where c.getAnAnnotation().toString() = "ThreadSafe" and c.contains(e)
select c

```

</details>

<br />

### Summary

| Repository | Results |
| --- | --- |
| alibaba/canal | [1 result(s)](./alibaba-canal.md) |
| alibaba/nacos | [33 result(s)](./alibaba-nacos.md) |
| alibaba/Sentinel | [53 result(s)](./alibaba-Sentinel.md) |
| apache/beam | [298 result(s)](./apache-beam.md) |
| apache/dubbo | [25 result(s)](./apache-dubbo.md) |
| apache/flink | [129 result(s)](./apache-flink.md) |
| apache/hadoop | [50 result(s)](./apache-hadoop.md) |
| apache/hbase | [2 result(s)](./apache-hbase.md) |
| apache/incubator-seata | [34 result(s)](./apache-incubator-seata.md) |
| apache/logging-log4j2 | [1 result(s)](./apache-logging-log4j2.md) |
| apache/maven | [60 result(s)](./apache-maven.md) |
| apache/rocketmq | [45 result(s)](./apache-rocketmq.md) |
| ben-manes/caffeine | [17 result(s)](./ben-manes-caffeine.md) |
| deeplearning4j/deeplearning4j | [1 result(s)](./deeplearning4j-deeplearning4j.md) |
| dromara/hutool | [2 result(s)](./dromara-hutool.md) |
| dropwizard/dropwizard | [1 result(s)](./dropwizard-dropwizard.md) |
| elastic/elasticsearch | [8 result(s)](./elastic-elasticsearch.md) |
| flyway/flyway | [8 result(s)](./flyway-flyway.md) |
| grpc/grpc-java | [265 result(s)](./grpc-grpc-java.md) |
| hibernate/hibernate-orm | [8 result(s)](./hibernate-hibernate-orm.md) |
| jacoco/jacoco | [1 result(s)](./jacoco-jacoco.md) |
| JetBrains/kotlin | [1 result(s)](./JetBrains-kotlin.md) |
| jetty/jetty.project | [3 result(s)](./jetty-jetty.project.md) |
| junit-team/junit4 | [3 result(s)](./junit-team-junit4.md) |
| junit-team/junit5 | [6 result(s)](./junit-team-junit5.md) |
| keycloak/keycloak | [2 result(s)](./keycloak-keycloak.md) |
| prestodb/presto | [239 result(s)](./prestodb-presto.md) |
| projectlombok/lombok | [1 result(s)](./projectlombok-lombok.md) |
| quarkusio/quarkus | [70 result(s)](./quarkusio-quarkus.md) |
| reactor/reactor-core | [8 result(s)](./reactor-reactor-core.md) |
| rest-assured/rest-assured | [7 result(s)](./rest-assured-rest-assured.md) |
| SeleniumHQ/selenium | [2 result(s)](./SeleniumHQ-selenium.md) |
| spring-cloud/spring-cloud-config | [12 result(s)](./spring-cloud-spring-cloud-config.md) |
| spring-cloud/spring-cloud-gateway | [11 result(s)](./spring-cloud-spring-cloud-gateway.md) |
| spring-projects/spring-boot | [76 result(s)](./spring-projects-spring-boot.md) |
| spring-projects/spring-framework | [7 result(s)](./spring-projects-spring-framework.md) |
| spring-projects/spring-security | [36 result(s)](./spring-projects-spring-security.md) |
| square/okhttp | [8 result(s)](./square-okhttp.md) |
| swagger-api/swagger-core | [7 result(s)](./swagger-api-swagger-core.md) |
| testcontainers/testcontainers-java | [69 result(s)](./testcontainers-testcontainers-java.md) |
| testng-team/testng | [7 result(s)](./testng-team-testng.md) |
| xuxueli/xxl-job | [1 result(s)](./xuxueli-xxl-job.md) |
