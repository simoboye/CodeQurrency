### openrewrite/rewrite

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L145C16-L145C26)

<pre><code class="java">    @Override
    protected FileFilter getFileFilter() {
        return <strong>fileFilter</strong>;
    }

</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L191C13-L191C101)

<pre><code class="java">        try {
            final File baseDir = getSettings().getTempDirectory();
            <strong>tempFileLocation = Files.createTempDirectory(baseDir.toPath(), "check" + "tmp").toFile()</strong>;
        } catch (IOException ex) {
            setEnabled(false);
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L207C13-L207C29)

<pre><code class="java">    @Override
    public void closeAnalyzer() throws Exception {
        if (<strong>tempFileLocation</strong> != null &amp;&amp; tempFileLocation.exists()) {
            LOGGER.debug("Attempting to delete temporary files from `{}`", tempFileLocation.toString());
            final boolean success = FileUtils.delete(tempFileLocation);
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L207C41-L207C57)

<pre><code class="java">    @Override
    public void closeAnalyzer() throws Exception {
        if (tempFileLocation != null &amp;&amp; <strong>tempFileLocation</strong>.exists()) {
            LOGGER.debug("Attempting to delete temporary files from `{}`", tempFileLocation.toString());
            final boolean success = FileUtils.delete(tempFileLocation);
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L209C54-L209C70)

<pre><code class="java">        if (tempFileLocation != null &amp;&amp; tempFileLocation.exists()) {
            LOGGER.debug("Attempting to delete temporary files from `{}`", tempFileLocation.toString());
            final boolean success = FileUtils.delete(<strong>tempFileLocation</strong>);
            if (!success &amp;&amp; tempFileLocation.exists()) {
                final String[] l = tempFileLocation.list();
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L208C76-L208C92)

<pre><code class="java">    public void closeAnalyzer() throws Exception {
        if (tempFileLocation != null &amp;&amp; tempFileLocation.exists()) {
            LOGGER.debug("Attempting to delete temporary files from `{}`", <strong>tempFileLocation</strong>.toString());
            final boolean success = FileUtils.delete(tempFileLocation);
            if (!success &amp;&amp; tempFileLocation.exists()) {
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L210C29-L210C45)

<pre><code class="java">            LOGGER.debug("Attempting to delete temporary files from `{}`", tempFileLocation.toString());
            final boolean success = FileUtils.delete(tempFileLocation);
            if (!success &amp;&amp; <strong>tempFileLocation</strong>.exists()) {
                final String[] l = tempFileLocation.list();
                if (l != null &amp;&amp; l.length &gt; 0) {
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L211C36-L211C52)

<pre><code class="java">            final boolean success = FileUtils.delete(tempFileLocation);
            if (!success &amp;&amp; tempFileLocation.exists()) {
                final String[] l = <strong>tempFileLocation</strong>.list();
                if (l != null &amp;&amp; l.length &gt; 0) {
                    LOGGER.warn("Failed to delete the Archive Analyzer's temporary files from `{}`, "
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L214C67-L214C83)

<pre><code class="java">                if (l != null &amp;&amp; l.length &gt; 0) {
                    LOGGER.warn("Failed to delete the Archive Analyzer's temporary files from `{}`, "
                                + "see the log for more details", <strong>tempFileLocation</strong>.toString());
                }
            }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L295C71-L295C83)

<pre><code class="java">                    //TODO - can we get more evidence from the parent? EAR contains module name, etc.
                    //analyze the dependency (i.e. extract files) if it is a supported type.
                    if (this.accept(d.getActualFile()) &amp;&amp; scanDepth &lt; <strong>maxScanDepth</strong>) {
                        extractAndAnalyze(d, engine, scanDepth + 1);
                    }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L386C41-L386C57)

<pre><code class="java">     */
    private File getNextTempDirectory() throws AnalysisException {
        final File directory = new File(<strong>tempFileLocation</strong>, String.valueOf(DIRECTORY_COUNT.incrementAndGet()));
        //getting an exception for some directories not being able to be created; might be because the directory already exists?
        if (directory.exists()) {
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L676C9-L676C69)

<pre><code class="java">     */
    private void initializeSettings() {
        <strong>maxScanDepth = getSettings().getInt("archive.scan.depth", 3)</strong>;
        final Set&lt;String&gt; extensions = new HashSet&lt;&gt;(EXTENSIONS);
        extensions.addAll(KNOWN_ZIP_EXT);
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L685C9-L685C87)

<pre><code class="java">            Collections.addAll(ADDITIONAL_ZIP_EXT, ext);
        }
        <strong>fileFilter = FileFilterBuilder.newInstance().addExtensions(extensions).build()</strong>;
    }
}
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

| e |  |
| --- | --- |
| [`fileFilter`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L145C16-L145C25) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`...=...`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L191C13-L191C100) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`tempFileLocation`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L207C13-L207C28) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`tempFileLocation`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L207C41-L207C56) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`tempFileLocation`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L209C54-L209C69) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`tempFileLocation`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L208C76-L208C91) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`tempFileLocation`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L210C29-L210C44) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`tempFileLocation`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L211C36-L211C51) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`tempFileLocation`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L214C67-L214C82) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`maxScanDepth`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L295C71-L295C82) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`tempFileLocation`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L386C41-L386C56) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`...=...`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L676C9-L676C68) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`...=...`](https://github.com/openrewrite/rewrite/blob/735b3931ec1921c6aa01ec88169d05c0935c5586/rewrite-java-test/src/test/resources/dataflow-functional-tests/ArchiveAnalyzer.java#L685C9-L685C86) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |