### junit-team/junit4

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L131C13-L131C54)

<pre><code class="java">        @Override
        public void testRunStarted(Description description) throws Exception {
            <strong>startTime.set(System.currentTimeMillis())</strong>;
        }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L131C27-L131C53)

<pre><code class="java">        @Override
        public void testRunStarted(Description description) throws Exception {
            startTime.set(<strong>System.currentTimeMillis()</strong>);
        }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L136C28-L136C54)

<pre><code class="java">        @Override
        public void testRunFinished(Result result) throws Exception {
            long endTime = <strong>System.currentTimeMillis()</strong>;
            runTime.addAndGet(endTime - startTime.get());
        }
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L137C13-L137C57)

<pre><code class="java">        public void testRunFinished(Result result) throws Exception {
            long endTime = System.currentTimeMillis();
            <strong>runTime.addAndGet(endTime - startTime.get())</strong>;
        }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L137C41-L137C56)

<pre><code class="java">        public void testRunFinished(Result result) throws Exception {
            long endTime = System.currentTimeMillis();
            runTime.addAndGet(endTime - <strong>startTime.get()</strong>);
        }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L142C13-L142C36)

<pre><code class="java">        @Override
        public void testFinished(Description description) throws Exception {
            <strong>count.getAndIncrement()</strong>;
        }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L147C13-L147C34)

<pre><code class="java">        @Override
        public void testFailure(Failure failure) throws Exception {
            <strong>failures.add(failure)</strong>;
        }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L152C13-L152C42)

<pre><code class="java">        @Override
        public void testIgnored(Description description) throws Exception {
            <strong>ignoreCount.getAndIncrement()</strong>;
        }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L157C13-L157C53)

<pre><code class="java">        @Override
        public void testAssumptionFailure(Failure failure) {
            <strong>assumptionFailureCount.getAndIncrement()</strong>;
        }
    }
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/notification/SynchronizedRunListener.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L113C16-L113C35)

<pre><code class="java">    @Override
    public int hashCode() {
        return <strong>listener.hashCode()</strong>;
    }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/notification/SynchronizedRunListener.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L126C16-L126C46)

<pre><code class="java">        SynchronizedRunListener that = (SynchronizedRunListener) other;
        
        return <strong>listener.equals(that.listener)</strong>;
    }

</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[src/main/java/org/junit/runner/notification/SynchronizedRunListener.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L131C16-L131C35)

<pre><code class="java">    @Override
    public String toString() {
        return <strong>listener.toString()</strong> + " (with synchronization wrapper)";
    }
}
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

| m |  |
| --- | --- |
| [`set(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L131C13-L131C53) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`currentTimeMillis(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L131C27-L131C52) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`currentTimeMillis(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L136C28-L136C53) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addAndGet(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L137C13-L137C56) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`get(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L137C41-L137C55) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getAndIncrement(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L142C13-L142C35) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`add(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L147C13-L147C33) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getAndIncrement(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L152C13-L152C41) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getAndIncrement(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L157C13-L157C52) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`hashCode(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L113C16-L113C34) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`equals(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L126C16-L126C45) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`toString(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L131C16-L131C34) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |