### apache/flink

[flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L183C66-L183C71)

<pre><code class="java">    private static class EnvironmentCacheAndLock {
        final Lock lock;
        final LoadingCache&lt;Environment, WrappedSdkHarnessClient&gt; <strong>cache</strong>;

        EnvironmentCacheAndLock(
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L182C20-L182C24)

<pre><code class="java">
    private static class EnvironmentCacheAndLock {
        final Lock <strong>lock</strong>;
        final LoadingCache&lt;Environment, WrappedSdkHarnessClient&gt; cache;

</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L177C28-L177C39)

<pre><code class="java">        final Object payload;
        int refcount;
        ScheduledFuture&lt;?&gt; <strong>destroyTask</strong>;

        Instance(Object payload) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L176C13-L176C21)

<pre><code class="java">    private static class Instance {
        final Object payload;
        int <strong>refcount</strong>;
        ScheduledFuture&lt;?&gt; destroyTask;

</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L175C22-L175C29)

<pre><code class="java">
    private static class Instance {
        final Object <strong>payload</strong>;
        int refcount;
        ScheduledFuture&lt;?&gt; destroyTask;
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L45C23-L45C44)

<pre><code class="java">@ThreadSafe
public final class SharedResourceHolder {
    static final long <strong>DESTROY_DELAY_SECONDS</strong> = 0;

    // The sole holder instance.
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L123C32-L123C67)

<pre><code class="java">            PREFIX + ".totalAttemptsPerUpload";
    public static final String CHANGELOG_STORAGE_UPLOAD_BATCH_SIZES = PREFIX + ".uploadBatchSizes";
    public static final String <strong>CHANGELOG_STORAGE_UPLOAD_QUEUE_SIZE</strong> = PREFIX + ".uploadQueueSize";
}
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L122C32-L122C68)

<pre><code class="java">    public static final String CHANGELOG_STORAGE_TOTAL_ATTEMPTS_PER_UPLOAD =
            PREFIX + ".totalAttemptsPerUpload";
    public static final String <strong>CHANGELOG_STORAGE_UPLOAD_BATCH_SIZES</strong> = PREFIX + ".uploadBatchSizes";
    public static final String CHANGELOG_STORAGE_UPLOAD_QUEUE_SIZE = PREFIX + ".uploadQueueSize";
}
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L120C32-L120C75)

<pre><code class="java">    public static final String CHANGELOG_STORAGE_ATTEMPTS_PER_UPLOAD =
            PREFIX + ".attemptsPerUpload";
    public static final String <strong>CHANGELOG_STORAGE_TOTAL_ATTEMPTS_PER_UPLOAD</strong> =
            PREFIX + ".totalAttemptsPerUpload";
    public static final String CHANGELOG_STORAGE_UPLOAD_BATCH_SIZES = PREFIX + ".uploadBatchSizes";
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L118C32-L118C69)

<pre><code class="java">    public static final String CHANGELOG_STORAGE_UPLOAD_LATENCIES_NANOS =
            PREFIX + ".uploadLatenciesNanos";
    public static final String <strong>CHANGELOG_STORAGE_ATTEMPTS_PER_UPLOAD</strong> =
            PREFIX + ".attemptsPerUpload";
    public static final String CHANGELOG_STORAGE_TOTAL_ATTEMPTS_PER_UPLOAD =
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L116C32-L116C72)

<pre><code class="java">            PREFIX + ".numberOfUploadFailures";
    public static final String CHANGELOG_STORAGE_UPLOAD_SIZES = PREFIX + ".uploadSizes";
    public static final String <strong>CHANGELOG_STORAGE_UPLOAD_LATENCIES_NANOS</strong> =
            PREFIX + ".uploadLatenciesNanos";
    public static final String CHANGELOG_STORAGE_ATTEMPTS_PER_UPLOAD =
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L115C32-L115C62)

<pre><code class="java">    public static final String CHANGELOG_STORAGE_NUM_UPLOAD_FAILURES =
            PREFIX + ".numberOfUploadFailures";
    public static final String <strong>CHANGELOG_STORAGE_UPLOAD_SIZES</strong> = PREFIX + ".uploadSizes";
    public static final String CHANGELOG_STORAGE_UPLOAD_LATENCIES_NANOS =
            PREFIX + ".uploadLatenciesNanos";
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L113C32-L113C69)

<pre><code class="java">    public static final String CHANGELOG_STORAGE_NUM_UPLOAD_REQUESTS =
            PREFIX + ".numberOfUploadRequests";
    public static final String <strong>CHANGELOG_STORAGE_NUM_UPLOAD_FAILURES</strong> =
            PREFIX + ".numberOfUploadFailures";
    public static final String CHANGELOG_STORAGE_UPLOAD_SIZES = PREFIX + ".uploadSizes";
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L111C32-L111C69)

<pre><code class="java">
    private static final String PREFIX = "ChangelogStorage";
    public static final String <strong>CHANGELOG_STORAGE_NUM_UPLOAD_REQUESTS</strong> =
            PREFIX + ".numberOfUploadRequests";
    public static final String CHANGELOG_STORAGE_NUM_UPLOAD_FAILURES =
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java#L142C29-L142C37)

<pre><code class="java">        final Consumer&lt;List&lt;UploadResult&gt;&gt; successCallback;
        final BiConsumer&lt;List&lt;SequenceNumber&gt;, Throwable&gt; failureCallback;
        final AtomicBoolean <strong>finished</strong> = new AtomicBoolean();

        public UploadTask(
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java#L141C59-L141C74)

<pre><code class="java">        final Collection&lt;StateChangeSet&gt; changeSets;
        final Consumer&lt;List&lt;UploadResult&gt;&gt; successCallback;
        final BiConsumer&lt;List&lt;SequenceNumber&gt;, Throwable&gt; <strong>failureCallback</strong>;
        final AtomicBoolean finished = new AtomicBoolean();

</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java#L140C44-L140C59)

<pre><code class="java">    final class UploadTask {
        final Collection&lt;StateChangeSet&gt; changeSets;
        final Consumer&lt;List&lt;UploadResult&gt;&gt; <strong>successCallback</strong>;
        final BiConsumer&lt;List&lt;SequenceNumber&gt;, Throwable&gt; failureCallback;
        final AtomicBoolean finished = new AtomicBoolean();
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java#L139C42-L139C52)

<pre><code class="java">    @ThreadSafe
    final class UploadTask {
        final Collection&lt;StateChangeSet&gt; <strong>changeSets</strong>;
        final Consumer&lt;List&lt;UploadResult&gt;&gt; successCallback;
        final BiConsumer&lt;List&lt;SequenceNumber&gt;, Throwable&gt; failureCallback;
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/heartbeat/HeartbeatManagerImpl.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/heartbeat/HeartbeatManagerImpl.java#L73C32-L73C39)

<pre><code class="java">
    /** Running state of the heartbeat manager. */
    protected volatile boolean <strong>stopped</strong>;

    public HeartbeatManagerImpl(
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/heartbeat/HeartbeatManagerImpl.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/heartbeat/HeartbeatManagerImpl.java#L65C28-L65C31)

<pre><code class="java">    private final ScheduledExecutor mainThreadExecutor;

    protected final Logger <strong>log</strong>;

    /** Map containing the heartbeat monitors associated with the respective resource ID. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataIndexImpl.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataIndexImpl.java#L273C57-L273C65)

<pre><code class="java">                allocateAndConfigureBuffer(HsFileDataIndexImpl.InternalRegion.HEADER_SIZE);

        public static final HsFileDataIndexRegionHelper <strong>INSTANCE</strong> =
                new HsFileDataIndexRegionHelper();

</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataIndexImpl.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataIndexImpl.java#L184C33-L184C44)

<pre><code class="java">         * of released is variable payload. This field represents the size of header.
         */
        public static final int <strong>HEADER_SIZE</strong> = Integer.BYTES + Long.BYTES + Integer.BYTES;

        private final int firstBufferIndex;
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-runtime/src/test/java/org/apache/flink/runtime/io/network/util/TestBufferFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/test/java/org/apache/flink/runtime/io/network/util/TestBufferFactory.java#L36C29-L36C40)

<pre><code class="java">public class TestBufferFactory {

    public static final int <strong>BUFFER_SIZE</strong> = 32 * 1024;

    private static final BufferRecycler RECYCLER = FreeingBufferRecycler.INSTANCE;
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/legacy/metrics/MetricStore.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/legacy/metrics/MetricStore.java#L472C42-L472C49)

<pre><code class="java">    @ThreadSafe
    public static class ComponentMetricStore {
        public final Map&lt;String, String&gt; <strong>metrics</strong>;

        private ComponentMetricStore() {
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/legacy/metrics/MetricStore.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/legacy/metrics/MetricStore.java#L502C34-L502C55)

<pre><code class="java">    @ThreadSafe
    public static class TaskManagerMetricStore extends ComponentMetricStore {
        public final Set&lt;String&gt; <strong>garbageCollectorNames</strong>;

        private TaskManagerMetricStore() {
</code></pre>

*Potentially escaping field*

----------------------------------------

[flink-rpc/flink-rpc-akka/src/main/java/org/apache/flink/runtime/rpc/pekko/PekkoRpcService.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-rpc/flink-rpc-akka/src/main/java/org/apache/flink/runtime/rpc/pekko/PekkoRpcService.java#L91C22-L91C29)

<pre><code class="java">    private static final Logger LOG = LoggerFactory.getLogger(PekkoRpcService.class);

    static final int <strong>VERSION</strong> = 2;

    private final Object lock = new Object();
</code></pre>

*Potentially escaping field*

----------------------------------------

| f |  |
| --- | --- |
| `requestLog` | `Potentially escaping field` |
| `log` | `Potentially escaping field` |
| `HEADER_SDK_RETRY_INFO` | `Potentially escaping field` |
| `HEADER_SDK_TRANSACTION_ID` | `Potentially escaping field` |
| `HEADER_USER_AGENT` | `Potentially escaping field` |
| `errorResponseHandler` | `Potentially escaping field` |
| `awsCredentialsProvider` | `Potentially escaping field` |
| `configFactory` | `Potentially escaping field` |
| `S3_SERVICE_NAME` | `Potentially escaping field` |
| `compressedIso8601DateFormat` | `Potentially escaping field` |
| `rfc822DateFormat` | `Potentially escaping field` |
| `ISO8601_DATE_FORMAT_WITH_OFFSET` | `Potentially escaping field` |
| `alternateIso8601DateFormat` | `Potentially escaping field` |
| `iso8601DateFormat` | `Potentially escaping field` |
| `ERROR` | `Potentially escaping field` |
| `WARNING` | `Potentially escaping field` |
| `INFO` | `Potentially escaping field` |
| `DEBUG` | `Potentially escaping field` |
| `NAME_RESOLUTION_DELAYED` | `Potentially escaping field` |
| `ACCEPT_ENCODING_JOINER` | `Potentially escaping field` |
| `reservation` | `Potentially escaping field` |
| `parent` | `Potentially escaping field` |
| [`cache`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L183C66-L183C70) | `Potentially escaping field` |
| [`lock`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L182C20-L182C23) | `Potentially escaping field` |
| `shutdownHook` | `Potentially escaping field` |
| `INHERIT_IO_FILE` | `Potentially escaping field` |
| `ERROR` | `Potentially escaping field` |
| `WARNING` | `Potentially escaping field` |
| `INFO` | `Potentially escaping field` |
| `DEBUG` | `Potentially escaping field` |
| `ACCEPT_ENCODING_JOINER` | `Potentially escaping field` |
| `SERVER_CONTEXT_KEY` | `Potentially escaping field` |
| [`destroyTask`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L177C28-L177C38) | `Potentially escaping field` |
| [`refcount`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L176C13-L176C20) | `Potentially escaping field` |
| [`payload`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L175C22-L175C28) | `Potentially escaping field` |
| [`DESTROY_DELAY_SECONDS`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L45C23-L45C43) | `Potentially escaping field` |
| `NOOP` | `Potentially escaping field` |
| [`CHANGELOG_STORAGE_UPLOAD_QUEUE_SIZE`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L123C32-L123C66) | `Potentially escaping field` |
| [`CHANGELOG_STORAGE_UPLOAD_BATCH_SIZES`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L122C32-L122C67) | `Potentially escaping field` |
| [`CHANGELOG_STORAGE_TOTAL_ATTEMPTS_PER_UPLOAD`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L120C32-L120C74) | `Potentially escaping field` |
| [`CHANGELOG_STORAGE_ATTEMPTS_PER_UPLOAD`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L118C32-L118C68) | `Potentially escaping field` |
| [`CHANGELOG_STORAGE_UPLOAD_LATENCIES_NANOS`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L116C32-L116C71) | `Potentially escaping field` |
| [`CHANGELOG_STORAGE_UPLOAD_SIZES`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L115C32-L115C61) | `Potentially escaping field` |
| [`CHANGELOG_STORAGE_NUM_UPLOAD_FAILURES`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L113C32-L113C68) | `Potentially escaping field` |
| [`CHANGELOG_STORAGE_NUM_UPLOAD_REQUESTS`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/ChangelogStorageMetricGroup.java#L111C32-L111C68) | `Potentially escaping field` |
| [`finished`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java#L142C29-L142C36) | `Potentially escaping field` |
| [`failureCallback`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java#L141C59-L141C73) | `Potentially escaping field` |
| [`successCallback`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java#L140C44-L140C58) | `Potentially escaping field` |
| [`changeSets`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/StateChangeUploadScheduler.java#L139C42-L139C51) | `Potentially escaping field` |
| [`stopped`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/heartbeat/HeartbeatManagerImpl.java#L73C32-L73C38) | `Potentially escaping field` |
| [`log`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/heartbeat/HeartbeatManagerImpl.java#L65C28-L65C30) | `Potentially escaping field` |
| [`INSTANCE`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataIndexImpl.java#L273C57-L273C64) | `Potentially escaping field` |
| [`HEADER_SIZE`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataIndexImpl.java#L184C33-L184C43) | `Potentially escaping field` |
| [`BUFFER_SIZE`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/test/java/org/apache/flink/runtime/io/network/util/TestBufferFactory.java#L36C29-L36C39) | `Potentially escaping field` |
| [`metrics`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/legacy/metrics/MetricStore.java#L472C42-L472C48) | `Potentially escaping field` |
| [`garbageCollectorNames`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/legacy/metrics/MetricStore.java#L502C34-L502C54) | `Potentially escaping field` |
| [`VERSION`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-rpc/flink-rpc-akka/src/main/java/org/apache/flink/runtime/rpc/pekko/PekkoRpcService.java#L91C22-L91C28) | `Potentially escaping field` |