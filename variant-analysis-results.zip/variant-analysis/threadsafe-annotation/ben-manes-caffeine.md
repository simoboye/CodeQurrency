### ben-manes/caffeine

| c |
| --- |
| `StampedCommonCache` |
| `ModelPath` |
| `ModelType` |
| `ExecutionNodeAccessHierarchy` |
| `DeprecationLogger` |
| `ModelReference` |
| `AnalysisTask` |
| `Dependency` |
| `CveDB` |
| `MavenArtifact` |
| `DatabaseProperties` |
| `CpePlus` |
| `Pair` |
| `VulnerableSoftware` |
| `Evidence` |
| `EvidenceCollection` |
| `Reference` |