### killme2008/aviatorscript

[src/test/java/com/googlecode/aviator/test/function/OperatorFunctionTestWithInterpreter.java](https://github.com/killme2008/aviatorscript/blob/bd20856882c1fa7096dd6ebbf6cd4f50fa4a87ac/src/test/java/com/googlecode/aviator/test/function/OperatorFunctionTestWithInterpreter.java#L14C5-L14C71)

<pre><code class="java">  @Before
  public void setup() {
    <strong>this.instance = AviatorEvaluator.newInstance(EvalMode.INTERPRETER)</strong>;
  }

</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/test/java/com/googlecode/aviator/test/function/OperatorFunctionTestWithInterpreter.java](https://github.com/killme2008/aviatorscript/blob/bd20856882c1fa7096dd6ebbf6cd4f50fa4a87ac/src/test/java/com/googlecode/aviator/test/function/OperatorFunctionTestWithInterpreter.java#L20C5-L20C18)

<pre><code class="java">  @After
  public void tearDown() {
    <strong>this.instance</strong>.getOpsMap().clear();
  }
}
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

| e |  |
| --- | --- |
| [`...=...`](https://github.com/killme2008/aviatorscript/blob/bd20856882c1fa7096dd6ebbf6cd4f50fa4a87ac/src/test/java/com/googlecode/aviator/test/function/OperatorFunctionTestWithInterpreter.java#L14C5-L14C70) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`this.instance`](https://github.com/killme2008/aviatorscript/blob/bd20856882c1fa7096dd6ebbf6cd4f50fa4a87ac/src/test/java/com/googlecode/aviator/test/function/OperatorFunctionTestWithInterpreter.java#L20C5-L20C17) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |