### alibaba/canal

| c |
| --- |
| `TableLocationsCache` |