### apache/beam

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java#L169C9-L169C14)

<pre><code class="java">  static final class StreamData&lt;StreamT extends WindmillStream&gt; {
    final StreamT stream;
    int <strong>holds</strong>;

    @VisibleForTesting
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L45C7-L45C12)

<pre><code class="java">  int addIndex;
  int takeIndex;
  int <strong>count</strong>;
  @Nullable Exception cancellationException;

</code></pre>

*Is not safely published*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleReader.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleReader.java#L43C36-L43C44)

<pre><code class="java">
  /** Adapter used to import counterFactory from native code. */
  private ApplianceShuffleCounters <strong>counters</strong>;

  /** Whether the underlying C++ object was already destroyed. */
</code></pre>

*Is not safely published*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleReader.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleReader.java#L40C16-L40C29)

<pre><code class="java">
  /** Pointer to the underlying C++ ShuffleReader object. */
  private long <strong>nativePointer</strong>;

  /** Adapter used to import counterFactory from native code. */
</code></pre>

*Is not safely published*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleWriter.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleWriter.java#L42C36-L42C44)

<pre><code class="java">
  /** Adapter used to import counters from native code. */
  private ApplianceShuffleCounters <strong>counters</strong>;

  /**
</code></pre>

*Is not safely published*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleWriter.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleWriter.java#L39C16-L39C29)

<pre><code class="java">
  /** Pointer to the underlying native shuffle writer code. */
  private long <strong>nativePointer</strong>;

  /** Adapter used to import counters from native code. */
</code></pre>

*Is not safely published*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L117C19-L117C25)

<pre><code class="java">  private final Set&lt;WrappedSdkHarnessClient&gt; evictedActiveClients;

  private boolean <strong>closed</strong>;

  public static DefaultJobBundleFactory create(JobInfo jobInfo) {
</code></pre>

*Is not safely published*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L410C37-L410C50)

<pre><code class="java">    private BundleProcessor processor;
    private ExecutableProcessBundleDescriptor processBundleDescriptor;
    private WrappedSdkHarnessClient <strong>wrappedClient</strong>;
  }

</code></pre>

*Is not safely published*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L409C47-L409C70)

<pre><code class="java">  private static class PreparedClient {
    private BundleProcessor processor;
    private ExecutableProcessBundleDescriptor <strong>processBundleDescriptor</strong>;
    private WrappedSdkHarnessClient wrappedClient;
  }
</code></pre>

*Is not safely published*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L408C29-L408C38)

<pre><code class="java">
  private static class PreparedClient {
    private BundleProcessor <strong>processor</strong>;
    private ExecutableProcessBundleDescriptor processBundleDescriptor;
    private WrappedSdkHarnessClient wrappedClient;
</code></pre>

*Is not safely published*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L449C37-L449C50)

<pre><code class="java">    private final IdentityHashMap&lt;WrappedSdkHarnessClient, PreparedClient&gt; preparedClients =
        new IdentityHashMap&lt;&gt;();
    private volatile PreparedClient <strong>currentClient</strong>;

    private SimpleStageBundleFactory(ExecutableStage executableStage) {
</code></pre>

*Is not safely published*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L603C21-L603C27)

<pre><code class="java">    private final AtomicInteger bundleRefCount = new AtomicInteger();

    private boolean <strong>closed</strong>;

    static WrappedSdkHarnessClient wrapping(RemoteEnvironment environment, ServerInfo serverInfo) {
</code></pre>

*Is not safely published*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java#L66C21-L66C28)

<pre><code class="java">
  public static class RunningProcess {
    private Process <strong>process</strong>;

    RunningProcess(Process process) {
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L148C39-L148C57)

<pre><code class="java">  /** Only modified while holding a lock on {@code this}. */
  @SuppressFBWarnings("SE_BAD_FIELD")
  private volatile ComputedProperties <strong>computedProperties</strong>;

  // ProxyInvocationHandler implements Serializable only for the sake of throwing an informative
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L445C17-L445C34)

<pre><code class="java">    private long batchMaxBytes;
    private Duration batchTargetLatency;
    private int <strong>hintMaxNumWorkers</strong>;
    private boolean shouldReportDiagnosticMetrics;

</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L444C22-L444C40)

<pre><code class="java">    private int batchMaxCount;
    private long batchMaxBytes;
    private Duration <strong>batchTargetLatency</strong>;
    private int hintMaxNumWorkers;
    private boolean shouldReportDiagnosticMetrics;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L443C18-L443C31)

<pre><code class="java">    private int batchInitialCount;
    private int batchMaxCount;
    private long <strong>batchMaxBytes</strong>;
    private Duration batchTargetLatency;
    private int hintMaxNumWorkers;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L442C17-L442C30)

<pre><code class="java">    private Duration throttleDuration;
    private int batchInitialCount;
    private int <strong>batchMaxCount</strong>;
    private long batchMaxBytes;
    private Duration batchTargetLatency;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L441C17-L441C34)

<pre><code class="java">    private double overloadRatio;
    private Duration throttleDuration;
    private int <strong>batchInitialCount</strong>;
    private int batchMaxCount;
    private long batchMaxBytes;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L440C22-L440C38)

<pre><code class="java">    private Duration samplePeriodBucketSize;
    private double overloadRatio;
    private Duration <strong>throttleDuration</strong>;
    private int batchInitialCount;
    private int batchMaxCount;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L439C20-L439C33)

<pre><code class="java">    private Duration samplePeriod;
    private Duration samplePeriodBucketSize;
    private double <strong>overloadRatio</strong>;
    private Duration throttleDuration;
    private int batchInitialCount;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L438C22-L438C44)

<pre><code class="java">    private Duration initialBackoff;
    private Duration samplePeriod;
    private Duration <strong>samplePeriodBucketSize</strong>;
    private double overloadRatio;
    private Duration throttleDuration;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L437C22-L437C34)

<pre><code class="java">    private int maxAttempts;
    private Duration initialBackoff;
    private Duration <strong>samplePeriod</strong>;
    private Duration samplePeriodBucketSize;
    private double overloadRatio;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L436C22-L436C36)

<pre><code class="java">
    private int maxAttempts;
    private Duration <strong>initialBackoff</strong>;
    private Duration samplePeriod;
    private Duration samplePeriodBucketSize;
</code></pre>

*Is not safely published*

----------------------------------------

[sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L435C17-L435C28)

<pre><code class="java">    private static final int FIRESTORE_SINGLE_REQUEST_UPDATE_DOCUMENTS_MAX = 500;

    private int <strong>maxAttempts</strong>;
    private Duration initialBackoff;
    private Duration samplePeriod;
</code></pre>

*Is not safely published*

----------------------------------------

| f |  |
| --- | --- |
| [`holds`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java#L169C9-L169C13) | `Is not safely published` |
| [`count`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L45C7-L45C11) | `Is not safely published` |
| `ticker` | `Is not safely published` |
| [`counters`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleReader.java#L43C36-L43C43) | `Is not safely published` |
| [`nativePointer`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleReader.java#L40C16-L40C28) | `Is not safely published` |
| [`counters`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleWriter.java#L42C36-L42C43) | `Is not safely published` |
| [`nativePointer`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ApplianceShuffleWriter.java#L39C16-L39C28) | `Is not safely published` |
| [`closed`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L117C19-L117C24) | `Is not safely published` |
| [`wrappedClient`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L410C37-L410C49) | `Is not safely published` |
| [`processBundleDescriptor`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L409C47-L409C69) | `Is not safely published` |
| [`processor`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L408C29-L408C37) | `Is not safely published` |
| [`currentClient`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L449C37-L449C49) | `Is not safely published` |
| [`closed`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L603C21-L603C26) | `Is not safely published` |
| [`process`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java#L66C21-L66C27) | `Is not safely published` |
| [`computedProperties`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L148C39-L148C56) | `Is not safely published` |
| [`hintMaxNumWorkers`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L445C17-L445C33) | `Is not safely published` |
| [`batchTargetLatency`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L444C22-L444C39) | `Is not safely published` |
| [`batchMaxBytes`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L443C18-L443C30) | `Is not safely published` |
| [`batchMaxCount`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L442C17-L442C29) | `Is not safely published` |
| [`batchInitialCount`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L441C17-L441C33) | `Is not safely published` |
| [`throttleDuration`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L440C22-L440C37) | `Is not safely published` |
| [`overloadRatio`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L439C20-L439C32) | `Is not safely published` |
| [`samplePeriodBucketSize`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L438C22-L438C43) | `Is not safely published` |
| [`samplePeriod`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L437C22-L437C33) | `Is not safely published` |
| [`initialBackoff`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L436C22-L436C35) | `Is not safely published` |
| [`maxAttempts`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/io/google-cloud-platform/src/main/java/org/apache/beam/sdk/io/gcp/firestore/RpcQosOptions.java#L435C17-L435C27) | `Is not safely published` |