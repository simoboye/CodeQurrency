### dropwizard/dropwizard

| c |
| --- |
| `CodecFactory` |