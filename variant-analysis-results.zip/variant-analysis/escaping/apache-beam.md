### apache/beam

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java#L58C16-L58C25)

<pre><code class="java">    final UnboundedSource.UnboundedReader&lt;?&gt; reader;
    final long cacheToken;
    final long <strong>workToken</strong>;

    CacheEntry(UnboundedSource.UnboundedReader&lt;?&gt; reader, long cacheToken, long workToken) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java#L57C16-L57C26)

<pre><code class="java">
    final UnboundedSource.UnboundedReader&lt;?&gt; reader;
    final long <strong>cacheToken</strong>;
    final long workToken;

</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java#L56C46-L56C52)

<pre><code class="java">  private static class CacheEntry {

    final UnboundedSource.UnboundedReader&lt;?&gt; <strong>reader</strong>;
    final long cacheToken;
    final long workToken;
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java#L394C5-L394C10)

<pre><code class="java">    EXECUTE,
    DUPLICATE,
    <strong>STALE</strong>
  }
}
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java#L393C5-L393C14)

<pre><code class="java">    QUEUED,
    EXECUTE,
    <strong>DUPLICATE</strong>,
    STALE
  }
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java#L392C5-L392C12)

<pre><code class="java">  enum ActivateWorkResult {
    QUEUED,
    <strong>EXECUTE</strong>,
    DUPLICATE,
    STALE
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java#L391C5-L391C11)

<pre><code class="java">
  enum ActivateWorkResult {
    <strong>QUEUED</strong>,
    EXECUTE,
    DUPLICATE,
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java#L169C9-L169C14)

<pre><code class="java">  static final class StreamData&lt;StreamT extends WindmillStream&gt; {
    final StreamT stream;
    int <strong>holds</strong>;

    @VisibleForTesting
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java#L168C19-L168C25)

<pre><code class="java">  @VisibleForTesting
  static final class StreamData&lt;StreamT extends WindmillStream&gt; {
    final StreamT <strong>stream</strong>;
    int holds;

</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/work/budget/GetWorkBudgetRefresher.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/work/budget/GetWorkBudgetRefresher.java#L40C46-L40C77)

<pre><code class="java">@ThreadSafe
public final class GetWorkBudgetRefresher {
  @VisibleForTesting public static final int <strong>SCHEDULED_BUDGET_REFRESH_MILLIS</strong> = 100;
  private static final int INITIAL_BUDGET_REFRESH_PHASE = 0;
  private static final String BUDGET_REFRESH_THREAD = "GetWorkBudgetRefreshThread";
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L179C62-L179C67)

<pre><code class="java">  private static class EnvironmentCacheAndLock {
    final Lock lock;
    final LoadingCache&lt;Environment, WrappedSdkHarnessClient&gt; <strong>cache</strong>;

    EnvironmentCacheAndLock(LoadingCache&lt;Environment, WrappedSdkHarnessClient&gt; cache, Lock lock) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L178C16-L178C20)

<pre><code class="java">
  private static class EnvironmentCacheAndLock {
    final Lock <strong>lock</strong>;
    final LoadingCache&lt;Environment, WrappedSdkHarnessClient&gt; cache;

</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java#L53C36-L53C48)

<pre><code class="java">  private static final List&lt;ProcessManager&gt; ALL_PROCESS_MANAGERS = new ArrayList&lt;&gt;();

  @VisibleForTesting static Thread <strong>shutdownHook</strong> = null;

  private final Map&lt;String, Process&gt; processes;
</code></pre>

*Potentially escaping field*

----------------------------------------

[runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java#L45C28-L45C43)

<pre><code class="java">
  /** A symbolic file to indicate that we want to inherit I/O of parent process. */
  public static final File <strong>INHERIT_IO_FILE</strong> = new File("_inherit_io_unused_filename_");

  /** For debugging purposes, we inherit I/O of processes. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L46C23-L46C44)

<pre><code class="java">  int takeIndex;
  int count;
  @Nullable Exception <strong>cancellationException</strong>;

  /** Creates a {@link ThreadSafe} blocking queue with a maximum capacity. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L45C7-L45C12)

<pre><code class="java">  int addIndex;
  int takeIndex;
  int <strong>count</strong>;
  @Nullable Exception cancellationException;

</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L44C7-L44C16)

<pre><code class="java">  private final Condition notEmpty;
  int addIndex;
  int <strong>takeIndex</strong>;
  int count;
  @Nullable Exception cancellationException;
</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L43C7-L43C15)

<pre><code class="java">  private final Condition notFull;
  private final Condition notEmpty;
  int <strong>addIndex</strong>;
  int takeIndex;
  int count;
</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/fn/splittabledofn/RestrictionTrackers.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/splittabledofn/RestrictionTrackers.java#L47C65-L47C73)

<pre><code class="java">  private static class RestrictionTrackerObserver&lt;RestrictionT, PositionT&gt;
      extends RestrictionTracker&lt;RestrictionT, PositionT&gt; {
    protected final RestrictionTracker&lt;RestrictionT, PositionT&gt; <strong>delegate</strong>;
    private final ClaimObserver&lt;PositionT&gt; claimObserver;

</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/fn/splittabledofn/WatermarkEstimators.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/splittabledofn/WatermarkEstimators.java#L57C66-L57C84)

<pre><code class="java">  private static class ThreadSafeWatermarkEstimator&lt;WatermarkEstimatorStateT&gt;
      implements WatermarkAndStateObserver&lt;WatermarkEstimatorStateT&gt; {
    protected final WatermarkEstimator&lt;WatermarkEstimatorStateT&gt; <strong>watermarkEstimator</strong>;

    ThreadSafeWatermarkEstimator(WatermarkEstimator&lt;WatermarkEstimatorStateT&gt; watermarkEstimator) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L109C58-L109C73)

<pre><code class="java">    final ImmutableMap&lt;String, String&gt; gettersToPropertyNames;
    final ImmutableMap&lt;String, String&gt; settersToPropertyNames;
    final ImmutableSet&lt;Class&lt;? extends PipelineOptions&gt;&gt; <strong>knownInterfaces</strong>;

    private ComputedProperties(
</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L108C40-L108C62)

<pre><code class="java">    final ImmutableClassToInstanceMap&lt;PipelineOptions&gt; interfaceToProxyCache;
    final ImmutableMap&lt;String, String&gt; gettersToPropertyNames;
    final ImmutableMap&lt;String, String&gt; <strong>settersToPropertyNames</strong>;
    final ImmutableSet&lt;Class&lt;? extends PipelineOptions&gt;&gt; knownInterfaces;

</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L107C40-L107C62)

<pre><code class="java">  private static final class ComputedProperties {
    final ImmutableClassToInstanceMap&lt;PipelineOptions&gt; interfaceToProxyCache;
    final ImmutableMap&lt;String, String&gt; <strong>gettersToPropertyNames</strong>;
    final ImmutableMap&lt;String, String&gt; settersToPropertyNames;
    final ImmutableSet&lt;Class&lt;? extends PipelineOptions&gt;&gt; knownInterfaces;
</code></pre>

*Potentially escaping field*

----------------------------------------

[sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L106C56-L106C77)

<pre><code class="java">
  private static final class ComputedProperties {
    final ImmutableClassToInstanceMap&lt;PipelineOptions&gt; <strong>interfaceToProxyCache</strong>;
    final ImmutableMap&lt;String, String&gt; gettersToPropertyNames;
    final ImmutableMap&lt;String, String&gt; settersToPropertyNames;
</code></pre>

*Potentially escaping field*

----------------------------------------

| f |  |
| --- | --- |
| `DEFAULT_DURATION_SECONDS` | `Potentially escaping field` |
| `requestLog` | `Potentially escaping field` |
| `log` | `Potentially escaping field` |
| `HEADER_SDK_RETRY_INFO` | `Potentially escaping field` |
| `HEADER_SDK_TRANSACTION_ID` | `Potentially escaping field` |
| `HEADER_USER_AGENT` | `Potentially escaping field` |
| `DEFAULT_PROPERTIES_CONFIG_FILE_NAME` | `Potentially escaping field` |
| `DEFAULT_MAX_INBOUND_MESSAGE_SIZE` | `Potentially escaping field` |
| `DEFAULT_MAX_INBOUND_METADATA_SIZE` | `Potentially escaping field` |
| `ID_FIELD_NAME` | `Potentially escaping field` |
| `ADMIN_DATABASE_NAME` | `Potentially escaping field` |
| `VERIFIED` | `Potentially escaping field` |
| `SIGNED` | `Potentially escaping field` |
| `UNSIGNED` | `Potentially escaping field` |
| `DELETE` | `Potentially escaping field` |
| `PUT` | `Potentially escaping field` |
| `POST` | `Potentially escaping field` |
| `GET` | `Potentially escaping field` |
| `SC_SERVICE_UNAVAILABLE` | `Potentially escaping field` |
| `SC_SERVER_ERROR` | `Potentially escaping field` |
| `SC_NOT_FOUND` | `Potentially escaping field` |
| `SC_FORBIDDEN` | `Potentially escaping field` |
| `SC_UNAUTHORIZED` | `Potentially escaping field` |
| `SC_BAD_REQUEST` | `Potentially escaping field` |
| `SC_FOUND` | `Potentially escaping field` |
| `SC_CREATED` | `Potentially escaping field` |
| `SC_OK` | `Potentially escaping field` |
| `ERROR` | `Potentially escaping field` |
| `WARNING` | `Potentially escaping field` |
| `INFO` | `Potentially escaping field` |
| `DEBUG` | `Potentially escaping field` |
| `NAME_RESOLUTION_DELAYED` | `Potentially escaping field` |
| `ACCEPT_ENCODING_JOINER` | `Potentially escaping field` |
| `SERVER_CONTEXT_KEY` | `Potentially escaping field` |
| `DESTROY_DELAY_SECONDS` | `Potentially escaping field` |
| `NOOP` | `Potentially escaping field` |
| `reservation` | `Potentially escaping field` |
| `parent` | `Potentially escaping field` |
| [`workToken`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java#L58C16-L58C24) | `Potentially escaping field` |
| [`cacheToken`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java#L57C16-L57C25) | `Potentially escaping field` |
| [`reader`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/ReaderCache.java#L56C46-L56C51) | `Potentially escaping field` |
| [`STALE`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java#L394C5-L394C9) | `Potentially escaping field` |
| [`DUPLICATE`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java#L393C5-L393C13) | `Potentially escaping field` |
| [`EXECUTE`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java#L392C5-L392C11) | `Potentially escaping field` |
| [`QUEUED`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/streaming/ActiveWorkState.java#L391C5-L391C10) | `Potentially escaping field` |
| [`holds`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java#L169C9-L169C13) | `Potentially escaping field` |
| [`stream`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/client/WindmillStreamPool.java#L168C19-L168C24) | `Potentially escaping field` |
| [`SCHEDULED_BUDGET_REFRESH_MILLIS`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/google-cloud-dataflow-java/worker/src/main/java/org/apache/beam/runners/dataflow/worker/windmill/work/budget/GetWorkBudgetRefresher.java#L40C46-L40C76) | `Potentially escaping field` |
| [`cache`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L179C62-L179C66) | `Potentially escaping field` |
| [`lock`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L178C16-L178C19) | `Potentially escaping field` |
| [`shutdownHook`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java#L53C36-L53C47) | `Potentially escaping field` |
| [`INHERIT_IO_FILE`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/runners/java-fn-execution/src/main/java/org/apache/beam/runners/fnexecution/environment/ProcessManager.java#L45C28-L45C42) | `Potentially escaping field` |
| [`cancellationException`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L46C23-L46C43) | `Potentially escaping field` |
| [`count`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L45C7-L45C11) | `Potentially escaping field` |
| [`takeIndex`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L44C7-L44C15) | `Potentially escaping field` |
| [`addIndex`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/CancellableQueue.java#L43C7-L43C14) | `Potentially escaping field` |
| [`delegate`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/splittabledofn/RestrictionTrackers.java#L47C65-L47C72) | `Potentially escaping field` |
| [`watermarkEstimator`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/fn/splittabledofn/WatermarkEstimators.java#L57C66-L57C83) | `Potentially escaping field` |
| [`knownInterfaces`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L109C58-L109C72) | `Potentially escaping field` |
| [`settersToPropertyNames`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L108C40-L108C61) | `Potentially escaping field` |
| [`gettersToPropertyNames`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L107C40-L107C61) | `Potentially escaping field` |
| [`interfaceToProxyCache`](https://github.com/apache/beam/blob/4ea3898e589ebc3f8960b1d5bb60888f144d23a5/sdks/java/core/src/main/java/org/apache/beam/sdk/options/ProxyInvocationHandler.java#L106C56-L106C76) | `Potentially escaping field` |
| `ERROR` | `Potentially escaping field` |
| `WARNING` | `Potentially escaping field` |
| `INFO` | `Potentially escaping field` |
| `DEBUG` | `Potentially escaping field` |
| `NAME_RESOLUTION_DELAYED` | `Potentially escaping field` |
| `ACCEPT_ENCODING_JOINER` | `Potentially escaping field` |
| `SERVER_CONTEXT_KEY` | `Potentially escaping field` |
| `NOOP` | `Potentially escaping field` |
| `VERSION` | `Potentially escaping field` |
| `ticker` | `Potentially escaping field` |
| `stsClient` | `Potentially escaping field` |