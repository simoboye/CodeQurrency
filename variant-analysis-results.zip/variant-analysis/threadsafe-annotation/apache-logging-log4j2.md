### apache/logging-log4j2

| c |
| --- |
| `TopologyVersion` |