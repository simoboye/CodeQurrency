### junit-team/junit5

| c |
| --- |
| `StampedCommonCache` |
| `ModelPath` |
| `ModelType` |
| `ExecutionNodeAccessHierarchy` |
| `DeprecationLogger` |
| `ModelReference` |