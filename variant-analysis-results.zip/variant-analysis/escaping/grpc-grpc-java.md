### grpc/grpc-java

[api/src/main/java/io/grpc/ChannelLogger.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ChannelLogger.java#L49C5-L49C10)

<pre><code class="java">    INFO,
    WARNING,
    <strong>ERROR</strong>
  }

</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/ChannelLogger.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ChannelLogger.java#L48C5-L48C12)

<pre><code class="java">    DEBUG,
    INFO,
    <strong>WARNING</strong>,
    ERROR
  }
</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/ChannelLogger.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ChannelLogger.java#L47C5-L47C9)

<pre><code class="java">  public enum ChannelLogLevel {
    DEBUG,
    <strong>INFO</strong>,
    WARNING,
    ERROR
</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/ChannelLogger.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ChannelLogger.java#L46C5-L46C10)

<pre><code class="java">   */
  public enum ChannelLogLevel {
    <strong>DEBUG</strong>,
    INFO,
    WARNING,
</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L34C45-L34C68)

<pre><code class="java">   * result. If the call option is not set, the call did not experience name resolution delay.
   */
  public static final CallOptions.Key&lt;Long&gt; <strong>NAME_RESOLUTION_DELAYED</strong> =
      CallOptions.Key.create("io.grpc.ClientStreamTracer.NAME_RESOLUTION_DELAYED");

</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/DecompressorRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/DecompressorRegistry.java#L145C19-L145C29)

<pre><code class="java">  private static final class DecompressorInfo {
    final Decompressor decompressor;
    final boolean <strong>advertised</strong>;

    DecompressorInfo(Decompressor decompressor, boolean advertised) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/DecompressorRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/DecompressorRegistry.java#L144C24-L144C36)

<pre><code class="java">   */
  private static final class DecompressorInfo {
    final Decompressor <strong>decompressor</strong>;
    final boolean advertised;

</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/DecompressorRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/DecompressorRegistry.java#L38C23-L38C45)

<pre><code class="java">@ThreadSafe
public final class DecompressorRegistry {
  static final Joiner <strong>ACCEPT_ENCODING_JOINER</strong> = Joiner.on(',');

  public static DecompressorRegistry emptyInstance() {
</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/Server.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/Server.java#L38C36-L38C54)

<pre><code class="java">   * issue for us to discuss a public API.
   */
  static final Context.Key&lt;Server&gt; <strong>SERVER_CONTEXT_KEY</strong> =
      Context.key("io.grpc.Server");

</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L200C13-L200C23)

<pre><code class="java">    final Runnable task;
    boolean isCancelled;
    boolean <strong>hasStarted</strong>;

    ManagedRunnable(Runnable task) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L199C13-L199C24)

<pre><code class="java">  private static class ManagedRunnable implements Runnable {
    final Runnable task;
    boolean <strong>isCancelled</strong>;
    boolean hasStarted;

</code></pre>

*Potentially escaping field*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L198C20-L198C24)

<pre><code class="java">
  private static class ManagedRunnable implements Runnable {
    final Runnable <strong>task</strong>;
    boolean isCancelled;
    boolean hasStarted;
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L184C5-L184C24)

<pre><code class="java">    SHUTDOWN, // We've been shutdown and won't accept any additional calls (thought existing calls
    // may continue).
    <strong>SHUTDOWN_TERMINATED</strong> // We've been shutdown completely (or we failed to start). We can't send or
    // receive any data.
  }
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L182C5-L182C13)

<pre><code class="java">    SETUP, // We're setting up the connection.
    READY, // The transport is ready.
    <strong>SHUTDOWN</strong>, // We've been shutdown and won't accept any additional calls (thought existing calls
    // may continue).
    SHUTDOWN_TERMINATED // We've been shutdown completely (or we failed to start). We can't send or
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L181C5-L181C10)

<pre><code class="java">    NOT_STARTED, // We haven't been started yet.
    SETUP, // We're setting up the connection.
    <strong>READY</strong>, // The transport is ready.
    SHUTDOWN, // We've been shutdown and won't accept any additional calls (thought existing calls
    // may continue).
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L180C5-L180C10)

<pre><code class="java">  protected enum TransportState {
    NOT_STARTED, // We haven't been started yet.
    <strong>SETUP</strong>, // We're setting up the connection.
    READY, // The transport is ready.
    SHUTDOWN, // We've been shutdown and won't accept any additional calls (thought existing calls
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L179C5-L179C16)

<pre><code class="java">  /** The states of this transport. */
  protected enum TransportState {
    <strong>NOT_STARTED</strong>, // We haven't been started yet.
    SETUP, // We're setting up the connection.
    READY, // The transport is ready.
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L207C20-L207C34)

<pre><code class="java">  @GuardedBy("this")
  @Nullable
  protected Status <strong>shutdownStatus</strong>;

  @Nullable private OneWayBinderProxy outgoingBinder;
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L200C24-L200C34)

<pre><code class="java">
  @GuardedBy("this")
  protected Attributes <strong>attributes</strong>;

  @GuardedBy("this")
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L194C47-L194C62)

<pre><code class="java">
  protected final ConcurrentHashMap&lt;Integer, Inbound&lt;?&gt;&gt; ongoingCalls;
  protected final OneWayBinderProxy.Decorator <strong>binderDecorator</strong>;

  @GuardedBy("this")
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L193C58-L193C70)

<pre><code class="java">  private final LeakSafeOneWayBinder incomingBinder;

  protected final ConcurrentHashMap&lt;Integer, Inbound&lt;?&gt;&gt; <strong>ongoingCalls</strong>;
  protected final OneWayBinderProxy.Decorator binderDecorator;

</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L160C20-L160C37)

<pre><code class="java">
  /** Send to acknowledge receipt of rpc bytes, for flow control. */
  static final int <strong>ACKNOWLEDGE_BYTES</strong> = IBinder.FIRST_CALL_TRANSACTION + 2;

  /** A ping request. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L157C27-L157C45)

<pre><code class="java">  /** Send to shutdown the transport from either end. */
  @Internal
  public static final int <strong>SHUTDOWN_TRANSPORT</strong> = IBinder.FIRST_CALL_TRANSACTION + 1;

  /** Send to acknowledge receipt of rpc bytes, for flow control. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L153C27-L153C42)

<pre><code class="java">   */
  @Internal
  public static final int <strong>SETUP_TRANSPORT</strong> = IBinder.FIRST_CALL_TRANSACTION;

  /** Send to shutdown the transport from either end. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L139C27-L139C65)

<pre><code class="java">  /** The version code of the earliest wire format we support. */
  @Internal
  public static final int <strong>EARLIEST_SUPPORTED_WIRE_FORMAT_VERSION</strong> = 1;

  /** The max number of "in-flight" bytes before we start buffering transactions. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L135C27-L135C46)

<pre><code class="java">   */
  @Internal
  public static final int <strong>WIRE_FORMAT_VERSION</strong> = 1;

  /** The version code of the earliest wire format we support. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L125C63-L125C88)

<pre><code class="java">  /** A transport attribute to hold the {@link InboundParcelablePolicy}. */
  @Internal
  public static final Attributes.Key&lt;InboundParcelablePolicy&gt; <strong>INBOUND_PARCELABLE_POLICY</strong> =
      Attributes.Key.create("internal:inbound-parcelable-policy");

</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L120C46-L120C62)

<pre><code class="java">  /** The authority of the server. */
  @Internal
  public static final Attributes.Key&lt;String&gt; <strong>SERVER_AUTHORITY</strong> =
      Attributes.Key.create("internal:server-authority");

</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L115C47-L115C57)

<pre><code class="java">   */
  @Internal
  public static final Attributes.Key&lt;Integer&gt; <strong>REMOTE_UID</strong> =
      Attributes.Key.create("internal:remote-uid");

</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L68C5-L68C36)

<pre><code class="java">    BIND_SERVICE("bindService"),
    BIND_SERVICE_AS_USER("bindServiceAsUser"),
    <strong>DEVICE_POLICY_BIND_SEVICE_ADMIN</strong>("DevicePolicyManager.bindDeviceAdminServiceAsUser");

    private final String methodName;
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L67C5-L67C25)

<pre><code class="java">  private enum BindMethodType {
    BIND_SERVICE("bindService"),
    <strong>BIND_SERVICE_AS_USER</strong>("bindServiceAsUser"),
    DEVICE_POLICY_BIND_SEVICE_ADMIN("DevicePolicyManager.bindDeviceAdminServiceAsUser");

</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L66C5-L66C17)

<pre><code class="java">  // Type of the method used when binding the service.
  private enum BindMethodType {
    <strong>BIND_SERVICE</strong>("bindService"),
    BIND_SERVICE_AS_USER("bindServiceAsUser"),
    DEVICE_POLICY_BIND_SEVICE_ADMIN("DevicePolicyManager.bindDeviceAdminServiceAsUser");
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L61C5-L61C12)

<pre><code class="java">    BINDING,
    BOUND,
    <strong>UNBOUND</strong>,
  }

</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L60C5-L60C10)

<pre><code class="java">    NOT_BINDING,
    BINDING,
    <strong>BOUND</strong>,
    UNBOUND,
  }
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L59C5-L59C12)

<pre><code class="java">  private enum State {
    NOT_BINDING,
    <strong>BINDING</strong>,
    BOUND,
    UNBOUND,
</code></pre>

*Potentially escaping field*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L58C5-L58C16)

<pre><code class="java">  // States can only ever transition in one direction.
  private enum State {
    <strong>NOT_BINDING</strong>,
    BINDING,
    BOUND,
</code></pre>

*Potentially escaping field*

----------------------------------------

[gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L73C26-L73C40)

<pre><code class="java">
    /** Boolean to indicate if services and methods matching pattern needs to be excluded. */
    public final boolean <strong>excludePattern</strong>;

    /**
</code></pre>

*Potentially escaping field*

----------------------------------------

[gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L70C22-L70C34)

<pre><code class="java">
    /** Number of bytes of message to log. */
    public final int <strong>messageBytes</strong>;

    /** Boolean to indicate if services and methods matching pattern needs to be excluded. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L67C22-L67C33)

<pre><code class="java">
    /** Number of bytes of header to log. */
    public final int <strong>headerBytes</strong>;

    /** Number of bytes of message to log. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L64C26-L64C34)

<pre><code class="java">
    /** Boolean to indicate all services and methods. */
    public final boolean <strong>matchAll</strong>;

    /** Number of bytes of header to log. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L61C30-L61C37)

<pre><code class="java">
    /* Set of fullMethodNames. */
    public final Set&lt;String&gt; <strong>methods</strong>;

    /** Boolean to indicate all services and methods. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L58C30-L58C38)

<pre><code class="java">  class LogFilter {
    /** Set of services. */
    public final Set&lt;String&gt; <strong>services</strong>;

    /* Set of fullMethodNames. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L60C10-L60C13)

<pre><code class="java">
  private static final class LongHolder {
    long <strong>num</strong>;
  }

</code></pre>

*Potentially escaping field*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L709C25-L709C36)

<pre><code class="java">    private class InProcessClientStream implements ClientStream {
      final StatsTraceContext statsTraceCtx;
      final CallOptions <strong>callOptions</strong>;
      // All callbacks must run in syncContext to avoid possibility of deadlock in direct executors
      private ServerStreamListener serverStreamListener;
</code></pre>

*Potentially escaping field*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L708C31-L708C44)

<pre><code class="java">
    private class InProcessClientStream implements ClientStream {
      final StatsTraceContext <strong>statsTraceCtx</strong>;
      final CallOptions callOptions;
      // All callbacks must run in syncContext to avoid possibility of deadlock in direct executors
</code></pre>

*Potentially escaping field*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L425C31-L425C44)

<pre><code class="java">
    private class InProcessServerStream implements ServerStream {
      final StatsTraceContext <strong>statsTraceCtx</strong>;
      // All callbacks must run in syncContext to avoid possibility of deadlock in direct executors
      private ClientStreamListener clientStreamListener;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L541C13-L541C30)

<pre><code class="java">  private class TransportListener implements ManagedClientTransport.Listener {
    final ConnectionClientTransport transport;
    boolean <strong>shutdownInitiated</strong> = false;

    TransportListener(ConnectionClientTransport transport) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L540C37-L540C46)

<pre><code class="java">  /** Listener for real transports. */
  private class TransportListener implements ManagedClientTransport.Listener {
    final ConnectionClientTransport <strong>transport</strong>;
    boolean shutdownInitiated = false;

</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L799C19-L799C24)

<pre><code class="java">  static final class TransportLogger extends ChannelLogger {
    // Changed just after construction to break a cyclic dependency.
    InternalLogId <strong>logId</strong>;

    @Override
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L476C23-L476C31)

<pre><code class="java">
  private final class ChannelStreamProvider implements ClientStreamProvider {
    volatile Throttle <strong>throttle</strong>;

    private ClientTransport getTransport(PickSubchannelArgs args) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1467C32-L1467C34)

<pre><code class="java">
  private final class LbHelperImpl extends LoadBalancer.Helper {
    AutoConfiguredLoadBalancer <strong>lb</strong>;

    @Override
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1743C24-L1743C32)

<pre><code class="java">  final class NameResolverListener extends NameResolver.Listener2 {
    final LbHelperImpl helper;
    final NameResolver <strong>resolver</strong>;

    NameResolverListener(LbHelperImpl helperImpl, NameResolver resolver) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1742C24-L1742C30)

<pre><code class="java">
  final class NameResolverListener extends NameResolver.Listener2 {
    final LbHelperImpl <strong>helper</strong>;
    final NameResolver resolver;

</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1095C25-L1095C36)

<pre><code class="java">      final Context context;
      final MethodDescriptor&lt;ReqT, RespT&gt; method;
      final CallOptions <strong>callOptions</strong>;
      private final long callCreationTime;

</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1094C43-L1094C49)

<pre><code class="java">    private final class PendingCall&lt;ReqT, RespT&gt; extends DelayedClientCall&lt;ReqT, RespT&gt; {
      final Context context;
      final MethodDescriptor&lt;ReqT, RespT&gt; <strong>method</strong>;
      final CallOptions callOptions;
      private final long callCreationTime;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1093C21-L1093C28)

<pre><code class="java">
    private final class PendingCall&lt;ReqT, RespT&gt; extends DelayedClientCall&lt;ReqT, RespT&gt; {
      final Context <strong>context</strong>;
      final MethodDescriptor&lt;ReqT, RespT&gt; method;
      final CallOptions callOptions;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2339C5-L2339C10)

<pre><code class="java">    NO_RESOLUTION,
    SUCCESS,
    <strong>ERROR</strong>
  }
}
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2338C5-L2338C12)

<pre><code class="java">  enum ResolutionState {
    NO_RESOLUTION,
    <strong>SUCCESS</strong>,
    ERROR
  }
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2337C5-L2337C18)

<pre><code class="java">   */
  enum ResolutionState {
    <strong>NO_RESOLUTION</strong>,
    SUCCESS,
    ERROR
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2233C36-L2233C44)

<pre><code class="java">
  private static final class RestrictedScheduledExecutor implements ScheduledExecutorService {
    final ScheduledExecutorService <strong>delegate</strong>;

    private RestrictedScheduledExecutor(ScheduledExecutorService delegate) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1935C21-L1935C40)

<pre><code class="java">    boolean started;
    boolean shutdown;
    ScheduledHandle <strong>delayedShutdownTask</strong>;

    SubchannelImpl(CreateSubchannelArgs args) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1934C13-L1934C21)

<pre><code class="java">    InternalSubchannel subchannel;
    boolean started;
    boolean <strong>shutdown</strong>;
    ScheduledHandle delayedShutdownTask;

</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1933C13-L1933C20)

<pre><code class="java">    List&lt;EquivalentAddressGroup&gt; addressGroups;
    InternalSubchannel subchannel;
    boolean <strong>started</strong>;
    boolean shutdown;
    ScheduledHandle delayedShutdownTask;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1932C24-L1932C34)

<pre><code class="java">    final ChannelTracer subchannelTracer;
    List&lt;EquivalentAddressGroup&gt; addressGroups;
    InternalSubchannel <strong>subchannel</strong>;
    boolean started;
    boolean shutdown;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1931C34-L1931C47)

<pre><code class="java">    final ChannelLoggerImpl subchannelLogger;
    final ChannelTracer subchannelTracer;
    List&lt;EquivalentAddressGroup&gt; <strong>addressGroups</strong>;
    InternalSubchannel subchannel;
    boolean started;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1930C25-L1930C41)

<pre><code class="java">    final InternalLogId subchannelLogId;
    final ChannelLoggerImpl subchannelLogger;
    final ChannelTracer <strong>subchannelTracer</strong>;
    List&lt;EquivalentAddressGroup&gt; addressGroups;
    InternalSubchannel subchannel;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1929C29-L1929C45)

<pre><code class="java">    final CreateSubchannelArgs args;
    final InternalLogId subchannelLogId;
    final ChannelLoggerImpl <strong>subchannelLogger</strong>;
    final ChannelTracer subchannelTracer;
    List&lt;EquivalentAddressGroup&gt; addressGroups;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1928C25-L1928C40)

<pre><code class="java">  private final class SubchannelImpl extends AbstractSubchannel {
    final CreateSubchannelArgs args;
    final InternalLogId <strong>subchannelLogId</strong>;
    final ChannelLoggerImpl subchannelLogger;
    final ChannelTracer subchannelTracer;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1927C32-L1927C36)

<pre><code class="java">
  private final class SubchannelImpl extends AbstractSubchannel {
    final CreateSubchannelArgs <strong>args</strong>;
    final InternalLogId subchannelLogId;
    final ChannelLoggerImpl subchannelLogger;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1396C12-L1396C26)

<pre><code class="java">
    @GuardedBy("lock")
    Status <strong>shutdownStatus</strong>;

    void onShutdown(Status reason) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1393C30-L1393C57)

<pre><code class="java">
    @GuardedBy("lock")
    Collection&lt;ClientStream&gt; <strong>uncommittedRetriableStreams</strong> = new HashSet&lt;&gt;();

    @GuardedBy("lock")
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1390C18-L1390C22)

<pre><code class="java">    // TODO(zdapeng): This means we would acquire a lock for each new retry-able stream,
    // it's worthwhile to look for a lock-free approach.
    final Object <strong>lock</strong> = new Object();

    @GuardedBy("lock")
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L327C38-L327C58)

<pre><code class="java">  // Must be accessed from syncContext
  @VisibleForTesting
  final InUseStateAggregator&lt;Object&gt; <strong>inUseStateAggregator</strong> = new IdleModeStateAggregator();

  @Override
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L184C32-L184C43)

<pre><code class="java">
  @VisibleForTesting
  final SynchronizationContext <strong>syncContext</strong> = new SynchronizationContext(
      new Thread.UncaughtExceptionHandler() {
        @Override
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L149C23-L149C49)

<pre><code class="java">
  @VisibleForTesting
  static final Status <strong>SUBCHANNEL_SHUTDOWN_STATUS</strong> =
      Status.UNAVAILABLE.withDescription("Subchannel shutdown invoked");

</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L145C23-L145C38)

<pre><code class="java">
  @VisibleForTesting
  static final Status <strong>SHUTDOWN_STATUS</strong> =
      Status.UNAVAILABLE.withDescription("Channel shutdown invoked");

</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L141C23-L141C42)

<pre><code class="java">
  @VisibleForTesting
  static final Status <strong>SHUTDOWN_NOW_STATUS</strong> =
      Status.UNAVAILABLE.withDescription("Channel shutdownNow invoked");

</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L138C21-L138C54)

<pre><code class="java">  static final long IDLE_TIMEOUT_MILLIS_DISABLE = -1;

  static final long <strong>SUBCHANNEL_SHUTDOWN_DELAY_SECONDS</strong> = 5;

  @VisibleForTesting
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L136C21-L136C48)

<pre><code class="java">  static final Pattern URI_PATTERN = Pattern.compile("[a-zA-Z][a-zA-Z0-9+.-]*:/.*");

  static final long <strong>IDLE_TIMEOUT_MILLIS_DISABLE</strong> = -1;

  static final long SUBCHANNEL_SHUTDOWN_DELAY_SECONDS = 5;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L134C24-L134C35)

<pre><code class="java">  // From RFC 2396: scheme = alpha *( alpha | digit | "+" | "-" | "." )
  @VisibleForTesting
  static final Pattern <strong>URI_PATTERN</strong> = Pattern.compile("[a-zA-Z][a-zA-Z0-9+.-]*:/.*");

  static final long IDLE_TIMEOUT_MILLIS_DISABLE = -1;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L128C23-L128C29)

<pre><code class="java">    InternalInstrumented&lt;ChannelStats&gt; {
  @VisibleForTesting
  static final Logger <strong>logger</strong> = Logger.getLogger(ManagedChannelImpl.class.getName());

  // Matching this pattern means the target string is a URI target or at least intended to be one.
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/SharedResourceHolder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L178C24-L178C35)

<pre><code class="java">    final Object payload;
    int refcount;
    ScheduledFuture&lt;?&gt; <strong>destroyTask</strong>;

    Instance(Object payload) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/SharedResourceHolder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L177C9-L177C17)

<pre><code class="java">  private static class Instance {
    final Object payload;
    int <strong>refcount</strong>;
    ScheduledFuture&lt;?&gt; destroyTask;

</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/SharedResourceHolder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L176C18-L176C25)

<pre><code class="java">
  private static class Instance {
    final Object <strong>payload</strong>;
    int refcount;
    ScheduledFuture&lt;?&gt; destroyTask;
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/SharedResourceHolder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L43C21-L43C42)

<pre><code class="java">@ThreadSafe
public final class SharedResourceHolder {
  static final long <strong>DESTROY_DELAY_SECONDS</strong> = 1;

  // The sole holder instance.
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/StatsTraceContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/StatsTraceContext.java#L41C41-L41C45)

<pre><code class="java">@ThreadSafe
public final class StatsTraceContext {
  public static final StatsTraceContext <strong>NOOP</strong> = new StatsTraceContext(new StreamTracer[0]);

  private final StreamTracer[] tracers;
</code></pre>

*Potentially escaping field*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L824C13-L824C22)

<pre><code class="java">  static final class MaybeTruncated&lt;T&gt; {
    T proto;
    boolean <strong>truncated</strong>;

    private MaybeTruncated(T proto, boolean truncated) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L823C7-L823C12)

<pre><code class="java">
  static final class MaybeTruncated&lt;T&gt; {
    T <strong>proto</strong>;
    boolean truncated;

</code></pre>

*Potentially escaping field*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L386C18-L386C38)

<pre><code class="java">    long currentTimeNanos();

    TimeProvider <strong>SYSTEM_TIME_PROVIDER</strong> = new TimeProvider() {
      @Override
      public long currentTimeNanos() {
</code></pre>

*Potentially escaping field*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L90C20-L90C26)

<pre><code class="java">
  @VisibleForTesting
  final SinkWriter <strong>writer</strong>;

  @VisibleForTesting
</code></pre>

*Potentially escaping field*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L84C37-L84C55)

<pre><code class="java">  // represents a com.google.rpc.Status and is given special first class treatment.
  // See StatusProto.java
  static final Metadata.Key&lt;byte[]&gt; <strong>STATUS_DETAILS_KEY</strong> =
      Metadata.Key.of(
          "grpc-status-details-bin",
</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L533C40-L533C47)

<pre><code class="java">  abstract static class CacheEntry {

    protected final RouteLookupRequest <strong>request</strong>;

    CacheEntry(RouteLookupRequest request) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L371C18-L371C24)

<pre><code class="java">  private static final class RlsLbHelper extends ForwardingLoadBalancerHelper {

    final Helper <strong>helper</strong>;
    private ConnectivityState state;
    private SubchannelPicker picker;
</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L901C37-L901C49)

<pre><code class="java">  /** A header will be added when RLS server respond with additional header data. */
  @VisibleForTesting
  static final Metadata.Key&lt;String&gt; <strong>RLS_DATA_KEY</strong> =
      Metadata.Key.of("X-Google-RLS-Data", Metadata.ASCII_STRING_MARSHALLER);

</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L88C27-L88C41)

<pre><code class="java">  public static final int STRING_OVERHEAD_BYTES = 38;
  /** Minimum bytes for a Java Object. */
  public static final int <strong>OBJ_OVERHEAD_B</strong> = 16;

  // All cache status changes (pending, backoff, success) must be under this lock
</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L86C27-L86C48)

<pre><code class="java">  public static final long MIN_EVICTION_TIME_DELTA_NANOS = TimeUnit.SECONDS.toNanos(5);
  public static final int BYTES_PER_CHAR = 2;
  public static final int <strong>STRING_OVERHEAD_BYTES</strong> = 38;
  /** Minimum bytes for a Java Object. */
  public static final int OBJ_OVERHEAD_B = 16;
</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L85C27-L85C41)

<pre><code class="java">      RESPONSE_CONVERTER = new RouteLookupResponseConverter().reverse();
  public static final long MIN_EVICTION_TIME_DELTA_NANOS = TimeUnit.SECONDS.toNanos(5);
  public static final int <strong>BYTES_PER_CHAR</strong> = 2;
  public static final int STRING_OVERHEAD_BYTES = 38;
  /** Minimum bytes for a Java Object. */
</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L84C28-L84C57)

<pre><code class="java">  private static final Converter&lt;RouteLookupResponse, io.grpc.lookup.v1.RouteLookupResponse&gt;
      RESPONSE_CONVERTER = new RouteLookupResponseConverter().reverse();
  public static final long <strong>MIN_EVICTION_TIME_DELTA_NANOS</strong> = TimeUnit.SECONDS.toNanos(5);
  public static final int BYTES_PER_CHAR = 2;
  public static final int STRING_OVERHEAD_BYTES = 38;
</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L379C13-L379C18)

<pre><code class="java">  private final class SizedValue {
    volatile int size;
    final V <strong>value</strong>;

    SizedValue(int size, V value) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L378C18-L378C22)

<pre><code class="java">
  private final class SizedValue {
    volatile int <strong>size</strong>;
    final V value;

</code></pre>

*Potentially escaping field*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L37C48-L37C59)

<pre><code class="java">  private static final CallMetricRecorder NOOP = new CallMetricRecorder().disable();

  static final Context.Key&lt;CallMetricRecorder&gt; <strong>CONTEXT_KEY</strong> =
      Context.key("io.grpc.services.CallMetricRecorder");

</code></pre>

*Potentially escaping field*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L110C13-L110C18)

<pre><code class="java">
  private static final class Instance&lt;V extends Closeable&gt; {
    final V <strong>value</strong>;
    private int refCount;

</code></pre>

*Potentially escaping field*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderStore.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderStore.java#L48C31-L48C43)

<pre><code class="java">    private final Watcher watcher;
    @VisibleForTesting
    final CertificateProvider <strong>certProvider</strong>;

    private Handle(CertProviderKey key, Watcher watcher, CertificateProvider certProvider) {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1622C40-L1622C48)

<pre><code class="java">      final class ResolvingOobChannelBuilder
          extends ForwardingChannelBuilder2&lt;ResolvingOobChannelBuilder&gt; {
        final ManagedChannelBuilder&lt;?&gt; <strong>delegate</strong>;

        ResolvingOobChannelBuilder() {
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L185C24-L185C30)

<pre><code class="java">
    final class OobSubchannelPicker extends SubchannelPicker {
      final PickResult <strong>result</strong> = PickResult.withSubchannel(subchannelImpl);

      @Override
</code></pre>

*Potentially escaping field*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L273C28-L273C39)

<pre><code class="java">      case TRANSIENT_FAILURE:
        final class OobErrorPicker extends SubchannelPicker {
          final PickResult <strong>errorResult</strong> = PickResult.withError(newState.getStatus());

          @Override
</code></pre>

*Potentially escaping field*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L397C15-L397C35)

<pre><code class="java">  public ClientInterceptor getClientInterceptor(final long callId) {
    return new ClientInterceptor() {
      boolean <strong>trailersOnlyResponse</strong> = true;
      @Override
      public &lt;ReqT, RespT&gt; ClientCall&lt;ReqT, RespT&gt; interceptCall(
</code></pre>

*Potentially escaping field*

----------------------------------------

| f |  |
| --- | --- |
| [`ERROR`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ChannelLogger.java#L49C5-L49C9) | `Potentially escaping field` |
| [`WARNING`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ChannelLogger.java#L48C5-L48C11) | `Potentially escaping field` |
| [`INFO`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ChannelLogger.java#L47C5-L47C8) | `Potentially escaping field` |
| [`DEBUG`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ChannelLogger.java#L46C5-L46C9) | `Potentially escaping field` |
| [`NAME_RESOLUTION_DELAYED`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L34C45-L34C67) | `Potentially escaping field` |
| [`advertised`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/DecompressorRegistry.java#L145C19-L145C28) | `Potentially escaping field` |
| [`decompressor`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/DecompressorRegistry.java#L144C24-L144C35) | `Potentially escaping field` |
| [`ACCEPT_ENCODING_JOINER`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/DecompressorRegistry.java#L38C23-L38C44) | `Potentially escaping field` |
| [`SERVER_CONTEXT_KEY`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/Server.java#L38C36-L38C53) | `Potentially escaping field` |
| [`hasStarted`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L200C13-L200C22) | `Potentially escaping field` |
| [`isCancelled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L199C13-L199C23) | `Potentially escaping field` |
| [`task`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L198C20-L198C23) | `Potentially escaping field` |
| [`SHUTDOWN_TERMINATED`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L184C5-L184C23) | `Potentially escaping field` |
| [`SHUTDOWN`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L182C5-L182C12) | `Potentially escaping field` |
| [`READY`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L181C5-L181C9) | `Potentially escaping field` |
| [`SETUP`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L180C5-L180C9) | `Potentially escaping field` |
| [`NOT_STARTED`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L179C5-L179C15) | `Potentially escaping field` |
| [`shutdownStatus`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L207C20-L207C33) | `Potentially escaping field` |
| [`attributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L200C24-L200C33) | `Potentially escaping field` |
| [`binderDecorator`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L194C47-L194C61) | `Potentially escaping field` |
| [`ongoingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L193C58-L193C69) | `Potentially escaping field` |
| [`ACKNOWLEDGE_BYTES`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L160C20-L160C36) | `Potentially escaping field` |
| [`SHUTDOWN_TRANSPORT`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L157C27-L157C44) | `Potentially escaping field` |
| [`SETUP_TRANSPORT`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L153C27-L153C41) | `Potentially escaping field` |
| [`EARLIEST_SUPPORTED_WIRE_FORMAT_VERSION`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L139C27-L139C64) | `Potentially escaping field` |
| [`WIRE_FORMAT_VERSION`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L135C27-L135C45) | `Potentially escaping field` |
| [`INBOUND_PARCELABLE_POLICY`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L125C63-L125C87) | `Potentially escaping field` |
| [`SERVER_AUTHORITY`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L120C46-L120C61) | `Potentially escaping field` |
| [`REMOTE_UID`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L115C47-L115C56) | `Potentially escaping field` |
| [`DEVICE_POLICY_BIND_SEVICE_ADMIN`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L68C5-L68C35) | `Potentially escaping field` |
| [`BIND_SERVICE_AS_USER`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L67C5-L67C24) | `Potentially escaping field` |
| [`BIND_SERVICE`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L66C5-L66C16) | `Potentially escaping field` |
| [`UNBOUND`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L61C5-L61C11) | `Potentially escaping field` |
| [`BOUND`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L60C5-L60C9) | `Potentially escaping field` |
| [`BINDING`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L59C5-L59C11) | `Potentially escaping field` |
| [`NOT_BINDING`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L58C5-L58C15) | `Potentially escaping field` |
| [`excludePattern`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L73C26-L73C39) | `Potentially escaping field` |
| [`messageBytes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L70C22-L70C33) | `Potentially escaping field` |
| [`headerBytes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L67C22-L67C32) | `Potentially escaping field` |
| [`matchAll`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L64C26-L64C33) | `Potentially escaping field` |
| [`methods`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L61C30-L61C36) | `Potentially escaping field` |
| [`services`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/gcp-observability/src/main/java/io/grpc/gcp/observability/ObservabilityConfig.java#L58C30-L58C37) | `Potentially escaping field` |
| [`num`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L60C10-L60C12) | `Potentially escaping field` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L709C25-L709C35) | `Potentially escaping field` |
| [`statsTraceCtx`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L708C31-L708C43) | `Potentially escaping field` |
| [`statsTraceCtx`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L425C31-L425C43) | `Potentially escaping field` |
| [`shutdownInitiated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L541C13-L541C29) | `Potentially escaping field` |
| [`transport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L540C37-L540C45) | `Potentially escaping field` |
| [`logId`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L799C19-L799C23) | `Potentially escaping field` |
| [`throttle`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L476C23-L476C30) | `Potentially escaping field` |
| [`lb`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1467C32-L1467C33) | `Potentially escaping field` |
| [`resolver`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1743C24-L1743C31) | `Potentially escaping field` |
| [`helper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1742C24-L1742C29) | `Potentially escaping field` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1095C25-L1095C35) | `Potentially escaping field` |
| [`method`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1094C43-L1094C48) | `Potentially escaping field` |
| [`context`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1093C21-L1093C27) | `Potentially escaping field` |
| [`ERROR`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2339C5-L2339C9) | `Potentially escaping field` |
| [`SUCCESS`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2338C5-L2338C11) | `Potentially escaping field` |
| [`NO_RESOLUTION`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2337C5-L2337C17) | `Potentially escaping field` |
| [`delegate`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2233C36-L2233C43) | `Potentially escaping field` |
| [`delayedShutdownTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1935C21-L1935C39) | `Potentially escaping field` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1934C13-L1934C20) | `Potentially escaping field` |
| [`started`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1933C13-L1933C19) | `Potentially escaping field` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1932C24-L1932C33) | `Potentially escaping field` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1931C34-L1931C46) | `Potentially escaping field` |
| [`subchannelTracer`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1930C25-L1930C40) | `Potentially escaping field` |
| [`subchannelLogger`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1929C29-L1929C44) | `Potentially escaping field` |
| [`subchannelLogId`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1928C25-L1928C39) | `Potentially escaping field` |
| [`args`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1927C32-L1927C35) | `Potentially escaping field` |
| [`shutdownStatus`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1396C12-L1396C25) | `Potentially escaping field` |
| [`uncommittedRetriableStreams`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1393C30-L1393C56) | `Potentially escaping field` |
| [`lock`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1390C18-L1390C21) | `Potentially escaping field` |
| [`inUseStateAggregator`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L327C38-L327C57) | `Potentially escaping field` |
| [`syncContext`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L184C32-L184C42) | `Potentially escaping field` |
| [`SUBCHANNEL_SHUTDOWN_STATUS`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L149C23-L149C48) | `Potentially escaping field` |
| [`SHUTDOWN_STATUS`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L145C23-L145C37) | `Potentially escaping field` |
| [`SHUTDOWN_NOW_STATUS`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L141C23-L141C41) | `Potentially escaping field` |
| [`SUBCHANNEL_SHUTDOWN_DELAY_SECONDS`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L138C21-L138C53) | `Potentially escaping field` |
| [`IDLE_TIMEOUT_MILLIS_DISABLE`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L136C21-L136C47) | `Potentially escaping field` |
| [`URI_PATTERN`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L134C24-L134C34) | `Potentially escaping field` |
| [`logger`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L128C23-L128C28) | `Potentially escaping field` |
| [`destroyTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L178C24-L178C34) | `Potentially escaping field` |
| [`refcount`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L177C9-L177C16) | `Potentially escaping field` |
| [`payload`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L176C18-L176C24) | `Potentially escaping field` |
| [`DESTROY_DELAY_SECONDS`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L43C21-L43C41) | `Potentially escaping field` |
| [`NOOP`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/StatsTraceContext.java#L41C41-L41C44) | `Potentially escaping field` |
| [`truncated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L824C13-L824C21) | `Potentially escaping field` |
| [`proto`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L823C7-L823C11) | `Potentially escaping field` |
| [`SYSTEM_TIME_PROVIDER`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L386C18-L386C37) | `Potentially escaping field` |
| [`writer`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L90C20-L90C25) | `Potentially escaping field` |
| [`STATUS_DETAILS_KEY`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L84C37-L84C54) | `Potentially escaping field` |
| [`request`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L533C40-L533C46) | `Potentially escaping field` |
| [`helper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L371C18-L371C23) | `Potentially escaping field` |
| [`RLS_DATA_KEY`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L901C37-L901C48) | `Potentially escaping field` |
| [`OBJ_OVERHEAD_B`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L88C27-L88C40) | `Potentially escaping field` |
| [`STRING_OVERHEAD_BYTES`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L86C27-L86C47) | `Potentially escaping field` |
| [`BYTES_PER_CHAR`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L85C27-L85C40) | `Potentially escaping field` |
| [`MIN_EVICTION_TIME_DELTA_NANOS`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L84C28-L84C56) | `Potentially escaping field` |
| [`value`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L379C13-L379C17) | `Potentially escaping field` |
| [`size`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L378C18-L378C21) | `Potentially escaping field` |
| [`CONTEXT_KEY`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L37C48-L37C58) | `Potentially escaping field` |
| [`value`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L110C13-L110C17) | `Potentially escaping field` |
| [`certProvider`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderStore.java#L48C31-L48C42) | `Potentially escaping field` |
| `monitor` | `Potentially escaping field` |
| `DISABLED` | `Potentially escaping field` |
| `ENABLED` | `Potentially escaping field` |
| `SECONDx100_MAX` | `Potentially escaping field` |
| `SECONDx10_SECONDx100` | `Potentially escaping field` |
| `SECONDx1_SECONDx10` | `Potentially escaping field` |
| `MILLIx100_SECONDx1` | `Potentially escaping field` |
| `MILLIx10_MILLIx100` | `Potentially escaping field` |
| `MILLIx1_MILLIx10` | `Potentially escaping field` |
| `MICROSx100_MILLIx1` | `Potentially escaping field` |
| `MICROSx10_MICROSx100` | `Potentially escaping field` |
| `ZERO_MICROSx10` | `Potentially escaping field` |
| `ROOT` | `Potentially escaping field` |
| `ANY` | `Potentially escaping field` |
| `UNTYPED` | `Potentially escaping field` |
| [`delegate`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1622C40-L1622C47) | `Potentially escaping field` |
| [`result`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L185C24-L185C29) | `Potentially escaping field` |
| [`errorResult`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L273C28-L273C38) | `Potentially escaping field` |
| [`trailersOnlyResponse`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L397C15-L397C34) | `Potentially escaping field` |