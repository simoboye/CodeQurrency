### immutables/immutables

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L178C7-L178C45)

<pre><code class="java">     */
    public Builder executor(ListeningExecutorService executor) {
      <strong>this.executor = checkNotNull(executor)</strong>;
      return this;
    }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L191C7-L191C45)

<pre><code class="java">     */
    public Builder database(MongoDatabase database) {
      <strong>this.database = checkNotNull(database)</strong>;
      return this;
    }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L243C7-L243C62)

<pre><code class="java">     */
    public Builder codecRegistry(CodecRegistry registry, FieldNamingStrategy fieldNamingStrategy) {
      <strong>this.codecRegistry = checkNotNull(registry, "registry")</strong>;
      this.fieldNamingStrategy = checkNotNull(fieldNamingStrategy, "fieldNamingStrategy");
      return this;
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L244C7-L244C90)

<pre><code class="java">    public Builder codecRegistry(CodecRegistry registry, FieldNamingStrategy fieldNamingStrategy) {
      this.codecRegistry = checkNotNull(registry, "registry");
      <strong>this.fieldNamingStrategy = checkNotNull(fieldNamingStrategy, "fieldNamingStrategy")</strong>;
      return this;
    }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L272C18-L272C26)

<pre><code class="java">     */
    public RepositorySetup build() {
      checkState(<strong>executor</strong> != null, "executor is not set");
      checkState(database != null, "database is not set");
      checkState(codecRegistry != null, "codecRegistry is not set");
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L273C18-L273C26)

<pre><code class="java">    public RepositorySetup build() {
      checkState(executor != null, "executor is not set");
      checkState(<strong>database</strong> != null, "database is not set");
      checkState(codecRegistry != null, "codecRegistry is not set");
      checkState(fieldNamingStrategy != null, "fieldNamingStrategy is not set");
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L274C18-L274C31)

<pre><code class="java">      checkState(executor != null, "executor is not set");
      checkState(database != null, "database is not set");
      checkState(<strong>codecRegistry</strong> != null, "codecRegistry is not set");
      checkState(fieldNamingStrategy != null, "fieldNamingStrategy is not set");

</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L275C18-L275C37)

<pre><code class="java">      checkState(database != null, "database is not set");
      checkState(codecRegistry != null, "codecRegistry is not set");
      checkState(<strong>fieldNamingStrategy</strong> != null, "fieldNamingStrategy is not set");

      return new RepositorySetup(executor, database, codecRegistry, fieldNamingStrategy);
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L277C34-L277C42)

<pre><code class="java">      checkState(fieldNamingStrategy != null, "fieldNamingStrategy is not set");

      return new RepositorySetup(<strong>executor</strong>, database, codecRegistry, fieldNamingStrategy);
    }
  }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L277C44-L277C52)

<pre><code class="java">      checkState(fieldNamingStrategy != null, "fieldNamingStrategy is not set");

      return new RepositorySetup(executor, <strong>database</strong>, codecRegistry, fieldNamingStrategy);
    }
  }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L277C54-L277C67)

<pre><code class="java">      checkState(fieldNamingStrategy != null, "fieldNamingStrategy is not set");

      return new RepositorySetup(executor, database, <strong>codecRegistry</strong>, fieldNamingStrategy);
    }
  }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[mongo/src/org/immutables/mongo/repository/RepositorySetup.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L277C69-L277C88)

<pre><code class="java">      checkState(fieldNamingStrategy != null, "fieldNamingStrategy is not set");

      return new RepositorySetup(executor, database, codecRegistry, <strong>fieldNamingStrategy</strong>);
    }
  }
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[ordinal/src/org/immutables/ordinal/OrdinalDomain.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/ordinal/src/org/immutables/ordinal/OrdinalDomain.java#L62C17-L62C24)

<pre><code class="java">      @Override
      protected E computeNext() {
        int p = <strong>index++</strong>;
        if (p &lt; length) {
          return get(p);
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[ordinal/src/org/immutables/ordinal/OrdinalDomain.java](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/ordinal/src/org/immutables/ordinal/OrdinalDomain.java#L62C17-L62C22)

<pre><code class="java">      @Override
      protected E computeNext() {
        int p = <strong>index</strong>++;
        if (p &lt; length) {
          return get(p);
</code></pre>

*An access of this field is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

| e |  |
| --- | --- |
| [`...=...`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L178C7-L178C44) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`...=...`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L191C7-L191C44) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`...=...`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L243C7-L243C61) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`...=...`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L244C7-L244C89) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`executor`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L272C18-L272C25) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`database`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L273C18-L273C25) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`codecRegistry`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L274C18-L274C30) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`fieldNamingStrategy`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L275C18-L275C36) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`executor`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L277C34-L277C41) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`database`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L277C44-L277C51) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`codecRegistry`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L277C54-L277C66) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`fieldNamingStrategy`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/mongo/src/org/immutables/mongo/repository/RepositorySetup.java#L277C69-L277C87) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`...++`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/ordinal/src/org/immutables/ordinal/OrdinalDomain.java#L62C17-L62C23) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |
| [`index`](https://github.com/immutables/immutables/blob/d8520588e270d8b4ced1fde6817bb9acaa719cc0/ordinal/src/org/immutables/ordinal/OrdinalDomain.java#L62C17-L62C21) | `An access of this field is on a different lock either in a synchronized statement or a lock type.` |