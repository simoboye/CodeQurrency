### apache/hbase

| c |
| --- |
| `OpenTelemetrySdk` |
| [`HBaseClassTestRuleChecker`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L38C14-L38C38) |