### hibernate/hibernate-orm

| c |
| --- |
| `StampedCommonCache` |
| `ModelType` |
| `ModelPath` |
| `ExecutionNodeAccessHierarchy` |
| `DeprecationLogger` |
| `ModelReference` |
| `UnboundRule` |
| `UnboundRuleInput` |