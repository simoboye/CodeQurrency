### rest-assured/rest-assured

| c |
| --- |
| `JsonNodeReader` |
| `TreePointer<JsonNode>` |
| `TreePointer` |
| `TokenResolver` |
| `MessageBundle` |
| `SchemaLoader` |
| `StampedCommonCache` |