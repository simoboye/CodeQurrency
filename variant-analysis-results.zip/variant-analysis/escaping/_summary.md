### Results for "Escaping"

<details>
<summary>Query</summary>

```ql
/**
 * @name Escaping
 * @kind problem
 * @problem.severity warning
 * @id java/escaping
 */

import java
import annotation

predicate isNotPrivate(Field f) {
  not f.isPrivate()
}

from Field f, Class c
where isElementInThreadSafeAnnotatedClass(c, f) 
  and isNotPrivate(f)
select f, "Potentially escaping field"

```

</details>

<br />

### Summary

| Repository | Results |
| --- | --- |
| grpc/grpc-java | [107 result(s)](./grpc-grpc-java.md) |
| prestodb/presto | [36 result(s)](./prestodb-presto.md) |
| apache/flink | [26 result(s)](./apache-flink.md) |
| apache/beam | [24 result(s)](./apache-beam.md) |
