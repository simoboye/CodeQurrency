### prestodb/presto

[presto-client/src/main/java/com/facebook/presto/client/StatementClientV1.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-client/src/main/java/com/facebook/presto/client/StatementClientV1.java#L581C9-L581C17)

<pre><code class="java">         * finished on remote Presto server (including failed and successfully completed)
         */
        <strong>FINISHED</strong>,
    }
}
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-client/src/main/java/com/facebook/presto/client/StatementClientV1.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-client/src/main/java/com/facebook/presto/client/StatementClientV1.java#L577C9-L577C23)

<pre><code class="java">        RUNNING,
        CLIENT_ERROR,
        <strong>CLIENT_ABORTED</strong>,
        /**
         * finished on remote Presto server (including failed and successfully completed)
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-client/src/main/java/com/facebook/presto/client/StatementClientV1.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-client/src/main/java/com/facebook/presto/client/StatementClientV1.java#L576C9-L576C21)

<pre><code class="java">         */
        RUNNING,
        <strong>CLIENT_ERROR</strong>,
        CLIENT_ABORTED,
        /**
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-client/src/main/java/com/facebook/presto/client/StatementClientV1.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-client/src/main/java/com/facebook/presto/client/StatementClientV1.java#L575C9-L575C16)

<pre><code class="java">         * submitted to server, not in terminal state (including planning, queued, running, etc)
         */
        <strong>RUNNING</strong>,
        CLIENT_ERROR,
        CLIENT_ABORTED,
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L94C29-L94C56)

<pre><code class="java">            REMOTE_TASK_ERROR.toErrorCode());

    public static final int <strong>DEFAULT_TASK_ATTEMPT_NUMBER</strong> = 0;

    private final Session session;
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L87C40-L87C63)

<pre><code class="java">public final class SqlStageExecution
{
    public static final Set&lt;ErrorCode&gt; <strong>RECOVERABLE_ERROR_CODES</strong> = ImmutableSet.of(
            TOO_MANY_REQUESTS_FAILED.toErrorCode(),
            PAGE_TRANSPORT_ERROR.toErrorCode(),
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/MultilevelSplitQueue.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/MultilevelSplitQueue.java#L44C23-L44C45)

<pre><code class="java">{
    static final int[] LEVEL_THRESHOLD_SECONDS = {0, 1, 10, 60, 300};
    static final long <strong>LEVEL_CONTRIBUTION_CAP</strong> = SECONDS.toNanos(30);

    @GuardedBy("lock")
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/MultilevelSplitQueue.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/MultilevelSplitQueue.java#L43C24-L43C47)

<pre><code class="java">public class MultilevelSplitQueue
{
    static final int[] <strong>LEVEL_THRESHOLD_SECONDS</strong> = {0, 1, 10, 60, 300};
    static final long LEVEL_CONTRIBUTION_CAP = SECONDS.toNanos(30);

</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java#L51C48-L51C69)

<pre><code class="java">    protected final List&lt;PrioritizedSplitRunner&gt; runningIntermediateSplits = new ArrayList&lt;&gt;(10);
    @GuardedBy("this")
    protected final SplitConcurrencyController <strong>concurrencyController</strong>;

    private final AtomicInteger nextSplitId = new AtomicInteger();
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java#L49C50-L49C75)

<pre><code class="java">    protected final List&lt;PrioritizedSplitRunner&gt; runningLeafSplits = new ArrayList&lt;&gt;(10);
    @GuardedBy("this")
    protected final List&lt;PrioritizedSplitRunner&gt; <strong>runningIntermediateSplits</strong> = new ArrayList&lt;&gt;(10);
    @GuardedBy("this")
    protected final SplitConcurrencyController concurrencyController;
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java#L47C50-L47C67)

<pre><code class="java">    protected final Queue&lt;PrioritizedSplitRunner&gt; queuedLeafSplits = new ArrayDeque&lt;&gt;(10);
    @GuardedBy("this")
    protected final List&lt;PrioritizedSplitRunner&gt; <strong>runningLeafSplits</strong> = new ArrayList&lt;&gt;(10);
    @GuardedBy("this")
    protected final List&lt;PrioritizedSplitRunner&gt; runningIntermediateSplits = new ArrayList&lt;&gt;(10);
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java#L45C51-L45C67)

<pre><code class="java">
    @GuardedBy("this")
    protected final Queue&lt;PrioritizedSplitRunner&gt; <strong>queuedLeafSplits</strong> = new ArrayDeque&lt;&gt;(10);
    @GuardedBy("this")
    protected final List&lt;PrioritizedSplitRunner&gt; runningLeafSplits = new ArrayList&lt;&gt;(10);
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L89C29-L89C43)

<pre><code class="java">        implements ResourceGroup
{
    public static final int <strong>DEFAULT_WEIGHT</strong> = 1;

    private final InternalResourceGroup root;
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-hive-metastore/src/main/java/com/facebook/presto/hive/metastore/AbstractCachingHiveMetastore.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive-metastore/src/main/java/com/facebook/presto/hive/metastore/AbstractCachingHiveMetastore.java#L40C14-L40C23)

<pre><code class="java">    public enum MetastoreCacheScope
    {
        ALL, <strong>PARTITION</strong>
    }

</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-hive-metastore/src/main/java/com/facebook/presto/hive/metastore/AbstractCachingHiveMetastore.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive-metastore/src/main/java/com/facebook/presto/hive/metastore/AbstractCachingHiveMetastore.java#L40C9-L40C12)

<pre><code class="java">    public enum MetastoreCacheScope
    {
        <strong>ALL</strong>, PARTITION
    }

</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java#L35C32-L35C46)

<pre><code class="java">    // children local memory contexts. Since the memory pool API enforces a tag to be used for
    // reserve/free operations, we define this special tag to use with such free operations.
    public static final String <strong>FORCE_FREE_TAG</strong> = "FORCE_FREE_OPERATION";

    @GuardedBy("this")
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java#L30C38-L30C49)

<pre><code class="java">        implements AggregatedMemoryContext
{
    static final ListenableFuture&lt;?&gt; <strong>NOT_BLOCKED</strong> = Futures.immediateFuture(null);

    // When an aggregated memory context is closed, it force-frees the memory allocated by its
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java#L533C32-L533C34)

<pre><code class="java">{
    public static final CatalogSchemaName DEFAULT_NAMESPACE = new CatalogSchemaName("presto", "default");
    public static final String <strong>ID</strong> = "builtin";

    private final FunctionAndTypeManager functionAndTypeManager;
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java#L532C43-L532C60)

<pre><code class="java">        implements FunctionNamespaceManager&lt;SqlFunction&gt;
{
    public static final CatalogSchemaName <strong>DEFAULT_NAMESPACE</strong> = new CatalogSchemaName("presto", "default");
    public static final String ID = "builtin";

</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L201C9-L201C15)

<pre><code class="java">         * No longer needed
         */
        <strong>CLOSED</strong>
    }

</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L196C9-L196C34)

<pre><code class="java">         * Spilled input has been unspilled, LookupSource built from it
         */
        <strong>INPUT_UNSPILLED_AND_BUILT</strong>,

        /**
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L191C9-L191C25)

<pre><code class="java">         * Spilled input is being unspilled
         */
        <strong>INPUT_UNSPILLING</strong>,

        /**
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L186C9-L186C22)

<pre><code class="java">         * Input has been finished and spilled
         */
        <strong>INPUT_SPILLED</strong>,

        /**
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L181C9-L181C28)

<pre><code class="java">         * LookupSource has been built and passed on without any spill occurring
         */
        <strong>LOOKUP_SOURCE_BUILT</strong>,

        /**
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L176C9-L176C23)

<pre><code class="java">         * Memory revoking occurred during {@link #CONSUMING_INPUT}. Operator accepts input and spills it
         */
        <strong>SPILLING_INPUT</strong>,

        /**
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L171C9-L171C24)

<pre><code class="java">         * Operator accepts input
         */
        <strong>CONSUMING_INPUT</strong>,

        /**
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L39C9-L39C26)

<pre><code class="java">        PRODUCED,
        DISPOSE_REQUESTED,
        <strong>DISPOSE_COMPLETED</strong>,
    }

</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L38C9-L38C26)

<pre><code class="java">        UNSPILLING,
        PRODUCED,
        <strong>DISPOSE_REQUESTED</strong>,
        DISPOSE_COMPLETED,
    }
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L37C9-L37C17)

<pre><code class="java">        SPILLED,
        UNSPILLING,
        <strong>PRODUCED</strong>,
        DISPOSE_REQUESTED,
        DISPOSE_COMPLETED,
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L36C9-L36C19)

<pre><code class="java">    {
        SPILLED,
        <strong>UNSPILLING</strong>,
        PRODUCED,
        DISPOSE_REQUESTED,
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L35C9-L35C16)

<pre><code class="java">    private enum State
    {
        <strong>SPILLED</strong>,
        UNSPILLING,
        PRODUCED,
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryMetadata.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryMetadata.java#L75C32-L75C43)

<pre><code class="java">        implements ConnectorMetadata
{
    public static final String <strong>SCHEMA_NAME</strong> = "default";

    private final NodeManager nodeManager;
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-parser/src/main/java/com/facebook/presto/sql/parser/RefreshableSqlBaseParserInitializer.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-parser/src/main/java/com/facebook/presto/sql/parser/RefreshableSqlBaseParserInitializer.java#L48C42-L48C48)

<pre><code class="java">    {
        public final AntlrATNCacheFields lexer = new AntlrATNCacheFields(SqlBaseLexer._ATN);
        public final AntlrATNCacheFields <strong>parser</strong> = new AntlrATNCacheFields(SqlBaseParser._ATN);
    }
}
</code></pre>

*Potentially escaping field*

----------------------------------------

[presto-parser/src/main/java/com/facebook/presto/sql/parser/RefreshableSqlBaseParserInitializer.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-parser/src/main/java/com/facebook/presto/sql/parser/RefreshableSqlBaseParserInitializer.java#L47C42-L47C47)

<pre><code class="java">    private static final class SqlBaseParserAndLexerATNCaches
    {
        public final AntlrATNCacheFields <strong>lexer</strong> = new AntlrATNCacheFields(SqlBaseLexer._ATN);
        public final AntlrATNCacheFields parser = new AntlrATNCacheFields(SqlBaseParser._ATN);
    }
</code></pre>

*Potentially escaping field*

----------------------------------------

[redis-hbo-provider/src/main/java/com/facebook/presto/statistic/RedisProviderApiStats.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/redis-hbo-provider/src/main/java/com/facebook/presto/statistic/RedisProviderApiStats.java#L38C9-L38C17)

<pre><code class="java">    {
        FetchStats,
        <strong>PutStats</strong>
    }

</code></pre>

*Potentially escaping field*

----------------------------------------

[redis-hbo-provider/src/main/java/com/facebook/presto/statistic/RedisProviderApiStats.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/redis-hbo-provider/src/main/java/com/facebook/presto/statistic/RedisProviderApiStats.java#L37C9-L37C19)

<pre><code class="java">    enum Operation
    {
        <strong>FetchStats</strong>,
        PutStats
    }
</code></pre>

*Potentially escaping field*

----------------------------------------

| f |  |
| --- | --- |
| `EMPTY_URI` | `Potentially escaping field` |
| `WILDCARD` | `Potentially escaping field` |
| `CUR_DIR` | `Potentially escaping field` |
| `SEPARATOR` | `Potentially escaping field` |
| `PARTITION` | `Potentially escaping field` |
| `TABLE` | `Potentially escaping field` |
| `SCHEMA` | `Potentially escaping field` |
| `GLOBAL` | `Potentially escaping field` |
| `GLOBAL` | `Potentially escaping field` |
| `SEPARATOR` | `Potentially escaping field` |
| `ENFORCE` | `Potentially escaping field` |
| `WARN` | `Potentially escaping field` |
| `IGNORE` | `Potentially escaping field` |
| `CREDENTIALS` | `Potentially escaping field` |
| `DEFAULT` | `Potentially escaping field` |
| `CLASS` | `Potentially escaping field` |
| `ENUM` | `Potentially escaping field` |
| `LIST` | `Potentially escaping field` |
| `DATASIZE` | `Potentially escaping field` |
| `DURATION` | `Potentially escaping field` |
| `STRING` | `Potentially escaping field` |
| `DOUBLE` | `Potentially escaping field` |
| `LONG` | `Potentially escaping field` |
| `INTEGER` | `Potentially escaping field` |
| `BOOLEAN` | `Potentially escaping field` |
| `TEST_DEPRECATED_KEY` | `Potentially escaping field` |
| `EXTRA_LOADED_FILESYSTEM_CLASSNAME` | `Potentially escaping field` |
| `CLIENT_WRITE_TO_UFS_ENABLED` | `Potentially escaping field` |
| `DORA_READ_VIRTUAL_BLOCK_SIZE` | `Potentially escaping field` |
| `DORA_UFS_LIST_STATUS_CACHE_NR_FILES` | `Potentially escaping field` |
| `DORA_UFS_LIST_STATUS_CACHE_TTL` | `Potentially escaping field` |
| `DORA_WORKER_METASTORE_ROCKSDB_INDEX` | `Potentially escaping field` |
| `DORA_WORKER_METASTORE_ROCKSDB_BLOCK_INDEX` | `Potentially escaping field` |
| `DORA_WORKER_METASTORE_ROCKSDB_CACHE_SIZE` | `Potentially escaping field` |
| `DORA_WORKER_METASTORE_ROCKSDB_BLOOM_FILTER` | `Potentially escaping field` |
| `DORA_WORKER_METASTORE_ROCKSDB_TTL` | `Potentially escaping field` |
| `DORA_WORKER_METASTORE_ROCKSDB_DIR` | `Potentially escaping field` |
| `DORA_CLIENT_METADATA_CACHE_ENABLED` | `Potentially escaping field` |
| `DORA_CLIENT_UFS_ROOT` | `Potentially escaping field` |
| `DORA_CLIENT_UFS_FALLBACK_ENABLED` | `Potentially escaping field` |
| `DORA_ENABLED` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_TIMEOUT_MS` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_WRITER_CLOSE_TIMEOUT_MS` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_CHANNEL_POOL_DISABLED` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_READER_BUFFER_SIZE_PACKETS` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_WRITER_BUFFER_SIZE_PACKETS` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_WRITER_PACKET_SIZE_BYTES` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_CHANNEL_POOL_GC_THRESHOLD_MS` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_CHANNEL_POOL_SIZE_MAX` | `Potentially escaping field` |
| `WORKER_HTTP_SERVER_PORT` | `Potentially escaping field` |
| `WORKER_HTTP_SERVER_ENABLED` | `Potentially escaping field` |
| `USER_DYNAMIC_CONSISTENT_HASH_RING_ENABLED` | `Potentially escaping field` |
| `USER_NETTY_DATA_TRANSMISSION_ENABLED` | `Potentially escaping field` |
| `HADOOP_KERBEROS_KEYTAB_LOGIN_AUTORENEWAL` | `Potentially escaping field` |
| `HADOOP_KRB5_CONF_FILE` | `Potentially escaping field` |
| `HADOOP_SECURITY_AUTHENTICATION` | `Potentially escaping field` |
| `STANDALONE_FUSE_JVM_MONITOR_ENABLED` | `Potentially escaping field` |
| `WORKER_JVM_MONITOR_ENABLED` | `Potentially escaping field` |
| `MASTER_JVM_MONITOR_ENABLED` | `Potentially escaping field` |
| `JVM_MONITOR_SLEEP_INTERVAL_MS` | `Potentially escaping field` |
| `JVM_MONITOR_INFO_THRESHOLD_MS` | `Potentially escaping field` |
| `JVM_MONITOR_WARN_THRESHOLD_MS` | `Potentially escaping field` |
| `ETCD_PASSWORD` | `Potentially escaping field` |
| `ETCD_USERNAME` | `Potentially escaping field` |
| `ETCD_ENDPOINTS` | `Potentially escaping field` |
| `ALLUXIO_CLUSTER_NAME` | `Potentially escaping field` |
| `ZOOKEEPER_JOB_LEADER_PATH` | `Potentially escaping field` |
| `ZOOKEEPER_JOB_ELECTION_PATH` | `Potentially escaping field` |
| `JOB_MASTER_NETWORK_PERMIT_KEEPALIVE_TIME_MS` | `Potentially escaping field` |
| `JOB_MASTER_NETWORK_KEEPALIVE_TIMEOUT_MS` | `Potentially escaping field` |
| `JOB_MASTER_NETWORK_KEEPALIVE_TIME_MS` | `Potentially escaping field` |
| `JOB_MASTER_NETWORK_FLOWCONTROL_WINDOW` | `Potentially escaping field` |
| `JOB_MASTER_NETWORK_MAX_INBOUND_MESSAGE_SIZE` | `Potentially escaping field` |
| `JOB_MASTER_EMBEDDED_JOURNAL_PORT` | `Potentially escaping field` |
| `JOB_MASTER_EMBEDDED_JOURNAL_ADDRESSES` | `Potentially escaping field` |
| `JOB_MASTER_RPC_ADDRESSES` | `Potentially escaping field` |
| `JOB_WORKER_WEB_PORT` | `Potentially escaping field` |
| `JOB_WORKER_WEB_BIND_HOST` | `Potentially escaping field` |
| `JOB_WORKER_THROTTLING` | `Potentially escaping field` |
| `JOB_WORKER_THREADPOOL_SIZE` | `Potentially escaping field` |
| `JOB_WORKER_RPC_PORT` | `Potentially escaping field` |
| `JOB_WORKER_HOSTNAME` | `Potentially escaping field` |
| `JOB_WORKER_DATA_PORT` | `Potentially escaping field` |
| `JOB_WORKER_BIND_HOST` | `Potentially escaping field` |
| `JOB_MASTER_WEB_PORT` | `Potentially escaping field` |
| `JOB_MASTER_WEB_HOSTNAME` | `Potentially escaping field` |
| `JOB_MASTER_WEB_BIND_HOST` | `Potentially escaping field` |
| `JOB_MASTER_RPC_PORT` | `Potentially escaping field` |
| `JOB_MASTER_LOST_WORKER_INTERVAL` | `Potentially escaping field` |
| `JOB_MASTER_LOST_MASTER_INTERVAL` | `Potentially escaping field` |
| `JOB_MASTER_HOSTNAME` | `Potentially escaping field` |
| `JOB_MASTER_BIND_HOST` | `Potentially escaping field` |
| `JOB_MASTER_WORKER_TIMEOUT` | `Potentially escaping field` |
| `JOB_MASTER_WORKER_HEARTBEAT_INTERVAL` | `Potentially escaping field` |
| `JOB_MASTER_MASTER_TIMEOUT` | `Potentially escaping field` |
| `JOB_MASTER_MASTER_HEARTBEAT_INTERVAL` | `Potentially escaping field` |
| `JOB_MASTER_JOB_CAPACITY` | `Potentially escaping field` |
| `JOB_MASTER_FINISHED_JOB_RETENTION_TIME` | `Potentially escaping field` |
| `JOB_MASTER_FINISHED_JOB_PURGE_COUNT` | `Potentially escaping field` |
| `JOB_MASTER_CLIENT_THREADS` | `Potentially escaping field` |
| `JOB_RETENTION_TIME` | `Potentially escaping field` |
| `JOB_BATCH_SIZE` | `Potentially escaping field` |
| `UNDERFS_VERSION` | `Potentially escaping field` |
| `NETWORK_TLS_ENABLED` | `Potentially escaping field` |
| `NETWORK_TLS_SSL_CONTEXT_PROVIDER_CLASSNAME` | `Potentially escaping field` |
| `S3_REST_AUTHENTICATOR_CLASSNAME` | `Potentially escaping field` |
| `S3_REST_AUTHENTICATION_ENABLED` | `Potentially escaping field` |
| `AUTHENTICATION_INACTIVE_CHANNEL_REAUTHENTICATE_PERIOD` | `Potentially escaping field` |
| `SECURITY_LOGIN_USERNAME` | `Potentially escaping field` |
| `SECURITY_LOGIN_IMPERSONATION_USERNAME` | `Potentially escaping field` |
| `SECURITY_GROUP_MAPPING_CLASS` | `Potentially escaping field` |
| `SECURITY_GROUP_MAPPING_CACHE_TIMEOUT_MS` | `Potentially escaping field` |
| `SECURITY_AUTHORIZATION_PERMISSION_UMASK` | `Potentially escaping field` |
| `SECURITY_AUTHORIZATION_PERMISSION_SUPERGROUP` | `Potentially escaping field` |
| `SECURITY_AUTHORIZATION_PERMISSION_ENABLED` | `Potentially escaping field` |
| `SECURITY_AUTHENTICATION_TYPE` | `Potentially escaping field` |
| `SECURITY_AUTHENTICATION_CUSTOM_PROVIDER_CLASS` | `Potentially escaping field` |
| `FUSE_WEB_PORT` | `Potentially escaping field` |
| `FUSE_WEB_HOSTNAME` | `Potentially escaping field` |
| `FUSE_WEB_BIND_HOST` | `Potentially escaping field` |
| `FUSE_WEB_ENABLED` | `Potentially escaping field` |
| `FUSE_SPECIAL_COMMAND_ENABLED` | `Potentially escaping field` |
| `FUSE_USER_GROUP_TRANSLATION_ENABLED` | `Potentially escaping field` |
| `FUSE_UPDATE_CHECK_ENABLED` | `Potentially escaping field` |
| `FUSE_UMOUNT_TIMEOUT` | `Potentially escaping field` |
| `FUSE_STAT_CACHE_REFRESH_INTERVAL` | `Potentially escaping field` |
| `FUSE_POSITION_READ_ENABLED` | `Potentially escaping field` |
| `FUSE_MOUNT_POINT` | `Potentially escaping field` |
| `FUSE_MOUNT_OPTIONS` | `Potentially escaping field` |
| `FUSE_MOUNT_ALLUXIO_PATH` | `Potentially escaping field` |
| `FUSE_MAX_READER_CONCURRENCY` | `Potentially escaping field` |
| `FUSE_LOGGING_THRESHOLD` | `Potentially escaping field` |
| `FUSE_JNIFUSE_LIBFUSE_VERSION` | `Potentially escaping field` |
| `FUSE_FS_NAME` | `Potentially escaping field` |
| `FUSE_DEBUG_ENABLED` | `Potentially escaping field` |
| `FUSE_CACHED_PATHS_MAX` | `Potentially escaping field` |
| `FUSE_AUTH_POLICY_CUSTOM_GROUP` | `Potentially escaping field` |
| `FUSE_AUTH_POLICY_CUSTOM_USER` | `Potentially escaping field` |
| `FUSE_AUTH_POLICY_CLASS` | `Potentially escaping field` |
| `USER_UPDATE_FILE_ACCESSTIME_DISABLED` | `Potentially escaping field` |
| `USER_UFS_BLOCK_READ_CONCURRENCY_MAX` | `Potentially escaping field` |
| `USER_UFS_BLOCK_LOCATION_ALL_FALLBACK_ENABLED` | `Potentially escaping field` |
| `USER_RPC_RETRY_MAX_SLEEP_MS` | `Potentially escaping field` |
| `USER_WORKER_LIST_REFRESH_INTERVAL` | `Potentially escaping field` |
| `USER_WORKER_SELECTION_POLICY` | `Potentially escaping field` |
| `USER_RPC_SHUFFLE_MASTERS_ENABLED` | `Potentially escaping field` |
| `USER_RPC_RETRY_MAX_DURATION` | `Potentially escaping field` |
| `USER_RPC_RETRY_BASE_SLEEP_MS` | `Potentially escaping field` |
| `USER_NETWORK_STREAMING_MAX_CONNECTIONS` | `Potentially escaping field` |
| `USER_NETWORK_STREAMING_NETTY_WORKER_THREADS` | `Potentially escaping field` |
| `USER_NETWORK_STREAMING_NETTY_CHANNEL` | `Potentially escaping field` |
| `USER_NETWORK_STREAMING_MAX_INBOUND_MESSAGE_SIZE` | `Potentially escaping field` |
| `USER_NETWORK_STREAMING_KEEPALIVE_TIMEOUT` | `Potentially escaping field` |
| `USER_NETWORK_STREAMING_KEEPALIVE_TIME` | `Potentially escaping field` |
| `USER_NETWORK_STREAMING_FLOWCONTROL_WINDOW` | `Potentially escaping field` |
| `USER_NETWORK_RPC_MAX_CONNECTIONS` | `Potentially escaping field` |
| `USER_NETWORK_RPC_NETTY_WORKER_THREADS` | `Potentially escaping field` |
| `USER_NETWORK_RPC_NETTY_CHANNEL` | `Potentially escaping field` |
| `USER_NETWORK_RPC_MAX_INBOUND_MESSAGE_SIZE` | `Potentially escaping field` |
| `USER_NETWORK_RPC_KEEPALIVE_TIMEOUT` | `Potentially escaping field` |
| `USER_NETWORK_RPC_KEEPALIVE_TIME` | `Potentially escaping field` |
| `USER_NETWORK_RPC_FLOWCONTROL_WINDOW` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_WORKER_THREADS` | `Potentially escaping field` |
| `USER_NETWORK_NETTY_CHANNEL` | `Potentially escaping field` |
| `USER_NETWORK_MAX_INBOUND_MESSAGE_SIZE` | `Potentially escaping field` |
| `USER_NETWORK_KEEPALIVE_TIMEOUT` | `Potentially escaping field` |
| `USER_NETWORK_KEEPALIVE_TIME` | `Potentially escaping field` |
| `USER_NETWORK_FLOWCONTROL_WINDOW` | `Potentially escaping field` |
| `USER_NETWORK_ZEROCOPY_ENABLED` | `Potentially escaping field` |
| `USER_NETWORK_WRITER_FLUSH_TIMEOUT` | `Potentially escaping field` |
| `USER_NETWORK_WRITER_CLOSE_TIMEOUT_MS` | `Potentially escaping field` |
| `USER_NETWORK_WRITER_CHUNK_SIZE_BYTES` | `Potentially escaping field` |
| `USER_NETWORK_WRITER_BUFFER_SIZE_MESSAGES` | `Potentially escaping field` |
| `USER_NETWORK_READER_CHUNK_SIZE_BYTES` | `Potentially escaping field` |
| `USER_NETWORK_READER_BUFFER_SIZE_MESSAGES` | `Potentially escaping field` |
| `USER_NETWORK_DATA_TIMEOUT_MS` | `Potentially escaping field` |
| `USER_STREAMING_ZEROCOPY_ENABLED` | `Potentially escaping field` |
| `USER_STREAMING_WRITER_FLUSH_TIMEOUT` | `Potentially escaping field` |
| `USER_STREAMING_WRITER_CLOSE_TIMEOUT` | `Potentially escaping field` |
| `USER_STREAMING_WRITER_CHUNK_SIZE_BYTES` | `Potentially escaping field` |
| `USER_STREAMING_WRITER_BUFFER_SIZE_MESSAGES` | `Potentially escaping field` |
| `USER_STREAMING_READER_CLOSE_TIMEOUT` | `Potentially escaping field` |
| `USER_STREAMING_READER_CHUNK_SIZE_BYTES` | `Potentially escaping field` |
| `USER_STREAMING_READER_BUFFER_SIZE_MESSAGES` | `Potentially escaping field` |
| `USER_STREAMING_DATA_WRITE_TIMEOUT` | `Potentially escaping field` |
| `USER_STREAMING_DATA_READ_TIMEOUT` | `Potentially escaping field` |
| `USER_POSITION_READER_PRELOAD_DATA_SIZE` | `Potentially escaping field` |
| `USER_POSITION_READER_PRELOAD_DATA_FILE_SIZE_THRESHOLD` | `Potentially escaping field` |
| `USER_POSITION_READER_PRELOAD_DATA_ENABLED` | `Potentially escaping field` |
| `USER_POSITION_READER_STREAMING_PREFETCH_MAX_SIZE` | `Potentially escaping field` |
| `USER_POSITION_READER_STREAMING_ADAPTIVE_POLICY_ENABLED` | `Potentially escaping field` |
| `USER_POSITION_READER_STREAMING_MULTIPLIER` | `Potentially escaping field` |
| `USER_APP_ID` | `Potentially escaping field` |
| `USER_METRICS_HEARTBEAT_INTERVAL_MS` | `Potentially escaping field` |
| `USER_METRICS_COLLECTION_ENABLED` | `Potentially escaping field` |
| `USER_METADATA_CACHE_EXPIRATION_TIME` | `Potentially escaping field` |
| `USER_METADATA_CACHE_MAX_SIZE` | `Potentially escaping field` |
| `USER_MASTER_POLLING_CONCURRENT` | `Potentially escaping field` |
| `USER_MASTER_POLLING_TIMEOUT` | `Potentially escaping field` |
| `USER_LOGGING_THRESHOLD` | `Potentially escaping field` |
| `USER_LOCAL_WRITER_CHUNK_SIZE_BYTES` | `Potentially escaping field` |
| `USER_LOCAL_READER_CHUNK_SIZE_BYTES` | `Potentially escaping field` |
| `USER_HDFS_CLIENT_EXCLUDE_MOUNT_INFO_ON_LIST_STATUS` | `Potentially escaping field` |
| `USER_FILE_WRITE_INIT_MAX_DURATION` | `Potentially escaping field` |
| `USER_FILE_INCLUDE_OPERATION_ID` | `Potentially escaping field` |
| `USER_FILE_WRITE_TIER_DEFAULT` | `Potentially escaping field` |
| `USER_HOSTNAME` | `Potentially escaping field` |
| `USER_FILE_WRITE_TYPE_DEFAULT` | `Potentially escaping field` |
| `USER_MULTI_PROBE_HASH_PROBE_NUM` | `Potentially escaping field` |
| `USER_MAGLEV_HASH_LOOKUP_SIZE` | `Potentially escaping field` |
| `USER_KETAMA_HASH_REPLICAS` | `Potentially escaping field` |
| `USER_CONSISTENT_HASH_VIRTUAL_NODE_COUNT_PER_WORKER` | `Potentially escaping field` |
| `USER_CLIENT_REPORT_VERSION_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_IDENTIFIER_INCLUDE_MTIME` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_IN_STREAM_BUFFER_SIZE` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_PAGE_SIZE` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SIZE` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_TTL_THRESHOLD_SECONDS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_TTL_CHECK_INTERVAL_SECONDS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_TTL_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_QUOTA_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_LOCAL_STORE_FILE_BUCKETS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_STORE_TYPE` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_STORE_OVERHEAD` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_TIMEOUT_THREADS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_TIMEOUT_DURATION` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_EVICTION_RETRIES` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_DIRS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_CUCKOO_SIZE_SUFFIX_BITS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_CUCKOO_SIZE_PREFIX_BITS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_CUCKOO_SIZE_ENCODER_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_CUCKOO_SCOPE_BITS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_CUCKOO_SIZE_BITS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_CUCKOO_CLOCK_BITS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_BLOOMFILTER_NUM` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_MEMORY_OVERHEAD` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_WINDOW` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_TYPE` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_SHADOW_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_EVICTOR_NONDETERMINISTIC_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_EVICTOR_LFU_LOGBASE` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_EVICTOR_CLASS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_FILTER_CONFIG_FILE` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_FILTER_CLASS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_FALLBACK_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_ASYNC_WRITE_THREADS` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_ASYNC_WRITE_ENABLED` | `Potentially escaping field` |
| `USER_CLIENT_CACHE_ASYNC_RESTORE_ENABLED` | `Potentially escaping field` |
| `USER_BLOCK_AVOID_EVICTION_POLICY_RESERVED_BYTES` | `Potentially escaping field` |
| `USER_BLOCK_READ_METRICS_ENABLED` | `Potentially escaping field` |
| `USER_FILE_CREATE_TTL_ACTION` | `Potentially escaping field` |
| `USER_FILE_CREATE_TTL` | `Potentially escaping field` |
| `USER_FILE_WAITCOMPLETED_POLL_MS` | `Potentially escaping field` |
| `USER_FILE_PERSISTENCE_INITIAL_WAIT_TIME` | `Potentially escaping field` |
| `USER_FILE_PERSIST_ON_RENAME` | `Potentially escaping field` |
| `USER_FILE_READ_TYPE_DEFAULT` | `Potentially escaping field` |
| `USER_FILE_PASSIVE_CACHE_ENABLED` | `Potentially escaping field` |
| `USER_FILE_METADATA_LOAD_REAL_CONTENT_HASH` | `Potentially escaping field` |
| `USER_FILE_METADATA_SYNC_INTERVAL` | `Potentially escaping field` |
| `USER_FILE_METADATA_LOAD_TYPE` | `Potentially escaping field` |
| `USER_FILE_MASTER_CLIENT_POOL_GC_THRESHOLD_MS` | `Potentially escaping field` |
| `USER_FILE_MASTER_CLIENT_POOL_GC_INTERVAL_MS` | `Potentially escaping field` |
| `USER_FILE_MASTER_CLIENT_POOL_SIZE_MAX` | `Potentially escaping field` |
| `USER_FILE_MASTER_CLIENT_POOL_SIZE_MIN` | `Potentially escaping field` |
| `USER_FILE_DELETE_UNCHECKED` | `Potentially escaping field` |
| `USER_FILE_RESERVED_BYTES` | `Potentially escaping field` |
| `USER_FILE_BUFFER_BYTES` | `Potentially escaping field` |
| `USER_DATE_FORMAT_PATTERN` | `Potentially escaping field` |
| `USER_CONF_CLUSTER_DEFAULT_ENABLED` | `Potentially escaping field` |
| `USER_BLOCK_SIZE_BYTES_DEFAULT` | `Potentially escaping field` |
| `USER_FILE_TARGET_MEDIA` | `Potentially escaping field` |
| `USER_FILE_REPLICATION_DURABLE` | `Potentially escaping field` |
| `USER_FILE_REPLICATION_MIN` | `Potentially escaping field` |
| `USER_FILE_REPLICATION_MAX` | `Potentially escaping field` |
| `USER_CONF_SYNC_INTERVAL` | `Potentially escaping field` |
| `USER_BLOCK_WORKER_CLIENT_POOL_GC_THRESHOLD_MS` | `Potentially escaping field` |
| `USER_BLOCK_WORKER_CLIENT_POOL_MAX` | `Potentially escaping field` |
| `USER_BLOCK_WORKER_CLIENT_POOL_MIN` | `Potentially escaping field` |
| `USER_BLOCK_MASTER_CLIENT_POOL_GC_THRESHOLD_MS` | `Potentially escaping field` |
| `USER_BLOCK_MASTER_CLIENT_POOL_GC_INTERVAL_MS` | `Potentially escaping field` |
| `USER_BLOCK_MASTER_CLIENT_POOL_SIZE_MAX` | `Potentially escaping field` |
| `USER_BLOCK_MASTER_CLIENT_POOL_SIZE_MIN` | `Potentially escaping field` |
| `PROXY_S3_TRANSFER_BUFFER_SIZE` | `Potentially escaping field` |
| `PROXY_S3_GLOBAL_READ_RATE_LIMIT_MB` | `Potentially escaping field` |
| `PROXY_S3_SINGLE_CONNECTION_READ_RATE_LIMIT_MB` | `Potentially escaping field` |
| `PROXY_S3_BUCKETPATHCACHE_TIMEOUT_MS` | `Potentially escaping field` |
| `PROXY_AUDIT_LOGGING_ENABLED` | `Potentially escaping field` |
| `PROXY_WEB_PORT` | `Potentially escaping field` |
| `PROXY_WEB_HOSTNAME` | `Potentially escaping field` |
| `PROXY_WEB_BIND_HOST` | `Potentially escaping field` |
| `PROXY_STREAM_CACHE_TIMEOUT_MS` | `Potentially escaping field` |
| `PROXY_S3_V2_ASYNC_HEAVY_POOL_QUEUE_SIZE` | `Potentially escaping field` |
| `PROXY_S3_V2_ASYNC_HEAVY_POOL_MAXIMUM_THREAD_NUMBER` | `Potentially escaping field` |
| `PROXY_S3_V2_ASYNC_HEAVY_POOL_CORE_THREAD_NUMBER` | `Potentially escaping field` |
| `PROXY_S3_V2_ASYNC_LIGHT_POOL_QUEUE_SIZE` | `Potentially escaping field` |
| `PROXY_S3_V2_ASYNC_LIGHT_POOL_MAXIMUM_THREAD_NUMBER` | `Potentially escaping field` |
| `PROXY_S3_V2_ASYNC_LIGHT_POOL_CORE_THREAD_NUMBER` | `Potentially escaping field` |
| `PROXY_S3_V2_ASYNC_PROCESSING_ENABLED` | `Potentially escaping field` |
| `PROXY_S3_V2_VERSION_ENABLED` | `Potentially escaping field` |
| `PROXY_S3_TAGGING_RESTRICTIONS_ENABLED` | `Potentially escaping field` |
| `PROXY_S3_BUCKET_NAMING_RESTRICTIONS_ENABLED` | `Potentially escaping field` |
| `PROXY_S3_METADATA_HEADER_MAX_SIZE` | `Potentially escaping field` |
| `PROXY_S3_COMPLETE_MULTIPART_UPLOAD_POOL_SIZE` | `Potentially escaping field` |
| `PROXY_S3_COMPLETE_MULTIPART_UPLOAD_MIN_PART_SIZE` | `Potentially escaping field` |
| `PROXY_S3_COMPLETE_MULTIPART_UPLOAD_KEEPALIVE_TIME_INTERVAL` | `Potentially escaping field` |
| `PROXY_S3_COMPLETE_MULTIPART_UPLOAD_KEEPALIVE_ENABLED` | `Potentially escaping field` |
| `PROXY_S3_MULTIPART_UPLOAD_CLEANER_POOL_SIZE` | `Potentially escaping field` |
| `PROXY_S3_MULTIPART_UPLOAD_CLEANER_RETRY_DELAY` | `Potentially escaping field` |
| `PROXY_S3_MULTIPART_UPLOAD_CLEANER_RETRY_COUNT` | `Potentially escaping field` |
| `PROXY_S3_MULTIPART_UPLOAD_CLEANER_TIMEOUT` | `Potentially escaping field` |
| `PROXY_S3_MULTIPART_UPLOAD_CLEANER_ENABLED` | `Potentially escaping field` |
| `PROXY_S3_DELETE_TYPE` | `Potentially escaping field` |
| `PROXY_S3_WRITE_TYPE` | `Potentially escaping field` |
| `PROXY_MASTER_HEARTBEAT_INTERVAL` | `Potentially escaping field` |
| `WORKER_STATIC_MEMBERSHIP_MANAGER_CONFIG_FILE` | `Potentially escaping field` |
| `WORKER_FAILURE_DETECTION_TIMEOUT` | `Potentially escaping field` |
| `WORKER_MEMBERSHIP_MANAGER_TYPE` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_FJP_ASYNC` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_FJP_MIN_RUNNABLE` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_FJP_PARALLELISM` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_TPE_ALLOW_CORE_THREADS_TIMEOUT` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_TPE_QUEUE_TYPE` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_KEEPALIVE` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_MAX_POOL_SIZE` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_CORE_POOL_SIZE` | `Potentially escaping field` |
| `WORKER_RPC_EXECUTOR_TYPE` | `Potentially escaping field` |
| `WORKER_UFS_INSTREAM_CACHE_MAX_SIZE` | `Potentially escaping field` |
| `WORKER_UFS_INSTREAM_CACHE_EXPIRARTION_TIME` | `Potentially escaping field` |
| `WORKER_UFS_INSTREAM_CACHE_ENABLED` | `Potentially escaping field` |
| `WORKER_UFS_BLOCK_OPEN_TIMEOUT_MS` | `Potentially escaping field` |
| `WORKER_S3_ASYNC_HEAVY_POOL_QUEUE_SIZE` | `Potentially escaping field` |
| `WORKER_S3_ASYNC_HEAVY_POOL_MAXIMUM_THREAD_NUMBER` | `Potentially escaping field` |
| `WORKER_S3_ASYNC_HEAVY_POOL_CORE_THREAD_NUMBER` | `Potentially escaping field` |
| `WORKER_S3_ASYNC_LIGHT_POOL_QUEUE_SIZE` | `Potentially escaping field` |
| `WORKER_S3_ASYNC_LIGHT_POOL_MAXIMUM_THREAD_NUMBER` | `Potentially escaping field` |
| `WORKER_S3_ASYNC_LIGHT_POOL_CORE_THREAD_NUMBER` | `Potentially escaping field` |
| `WORKER_S3_ASYNC_PROCESS_ENABLED` | `Potentially escaping field` |
| `WORKER_S3_AUDIT_LOGGING_ENABLED` | `Potentially escaping field` |
| `WORKER_S3_REST_ENABLED` | `Potentially escaping field` |
| `WORKER_REST_PORT` | `Potentially escaping field` |
| `WORKER_WEB_PORT` | `Potentially escaping field` |
| `WORKER_WEB_HOSTNAME` | `Potentially escaping field` |
| `WORKER_WEB_BIND_HOST` | `Potentially escaping field` |
| `WORKER_TIERED_STORE_LEVELS` | `Potentially escaping field` |
| `WORKER_DATA_PORT` | `Potentially escaping field` |
| `WORKER_DATA_HOSTNAME` | `Potentially escaping field` |
| `WORKER_DATA_BIND_HOST` | `Potentially escaping field` |
| `WORKER_RPC_PORT` | `Potentially escaping field` |
| `WORKER_REGISTER_LEASE_ENABLED` | `Potentially escaping field` |
| `WORKER_PRINCIPAL` | `Potentially escaping field` |
| `WORKER_PRELOAD_DATA_THREAD_POOL_SIZE` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_TYPE` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_TIMEOUT_THREADS` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_TIMEOUT_DURATION` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_SIZES` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_QUOTA_ENABLED` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_PAGE_SIZE` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_OVERHEAD` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_LOCAL_STORE_FILE_BUCKETS` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_EVICTOR_NONDETERMINISTIC_ENABLED` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_EVICTOR_LFU_LOGBASE` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_EVICTOR_CLASS` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_EVICTION_RETRIES` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_DIRS` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_ASYNC_WRITE_THREADS` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_ASYNC_WRITE_ENABLED` | `Potentially escaping field` |
| `WORKER_PAGE_STORE_ASYNC_RESTORE_ENABLED` | `Potentially escaping field` |
| `WORKER_BLOCK_MASTER_CLIENT_POOL_SIZE` | `Potentially escaping field` |
| `WORKER_REMOTE_IO_SLOW_THRESHOLD` | `Potentially escaping field` |
| `WORKER_REGISTER_TO_ALL_MASTERS` | `Potentially escaping field` |
| `WORKER_REGISTER_STREAM_COMPLETE_TIMEOUT` | `Potentially escaping field` |
| `WORKER_REGISTER_STREAM_RESPONSE_TIMEOUT` | `Potentially escaping field` |
| `WORKER_REGISTER_STREAM_DEADLINE` | `Potentially escaping field` |
| `WORKER_REGISTER_STREAM_BATCH_SIZE` | `Potentially escaping field` |
| `WORKER_REGISTER_STREAM_ENABLED` | `Potentially escaping field` |
| `WORKER_NETWORK_ZEROCOPY_ENABLED` | `Potentially escaping field` |
| `WORKER_NETWORK_SHUTDOWN_TIMEOUT` | `Potentially escaping field` |
| `WORKER_NETWORK_READER_MAX_CHUNK_SIZE_BYTES` | `Potentially escaping field` |
| `WORKER_NETWORK_READER_BUFFER_POOLED` | `Potentially escaping field` |
| `WORKER_NETWORK_READER_BUFFER_SIZE_BYTES` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_WORKER_THREADS` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_WATERMARK_LOW` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_WATERMARK_HIGH` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_SHUTDOWN_QUIET_PERIOD` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_FILE_TRANSFER_TYPE` | `Potentially escaping field` |
| `WORKER_NETWORK_PACKET_SENDING_TIMEOUT` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_CHANNEL` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_BOSS_THREADS` | `Potentially escaping field` |
| `WORKER_NETWORK_MAX_INBOUND_MESSAGE_SIZE` | `Potentially escaping field` |
| `WORKER_NETWORK_PERMIT_KEEPALIVE_TIME_MS` | `Potentially escaping field` |
| `WORKER_NETWORK_KEEPALIVE_TIMEOUT_MS` | `Potentially escaping field` |
| `WORKER_NETWORK_KEEPALIVE_TIME_MS` | `Potentially escaping field` |
| `WORKER_NETWORK_FLOWCONTROL_WINDOW` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_READER_BUFFER_SIZE_PACKETS` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_WRITER_BUFFER_SIZE_PACKETS` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_RPC_THREADS_MAX` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_UFS_WRITER_THREADS_MAX` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_WRITER_THREADS_MAX` | `Potentially escaping field` |
| `WORKER_NETWORK_NETTY_READER_THREADS_MAX` | `Potentially escaping field` |
| `WORKER_NETWORK_WRITER_BUFFER_SIZE_MESSAGES` | `Potentially escaping field` |
| `WORKER_NETWORK_GRPC_WRITER_THREADS_MAX` | `Potentially escaping field` |
| `WORKER_NETWORK_GRPC_READER_THREADS_MAX` | `Potentially escaping field` |
| `WORKER_RAMDISK_SIZE` | `Potentially escaping field` |
| `WORKER_MASTER_PERIODICAL_RPC_TIMEOUT` | `Potentially escaping field` |
| `WORKER_MASTER_CONNECT_RETRY_TIMEOUT` | `Potentially escaping field` |
| `WORKER_KEYTAB_FILE` | `Potentially escaping field` |
| `WORKER_IDENTITY_UUID_FILE_PATH` | `Potentially escaping field` |
| `WORKER_IDENTITY_UUID` | `Potentially escaping field` |
| `WORKER_HOSTNAME` | `Potentially escaping field` |
| `WORKER_FREE_SPACE_TIMEOUT` | `Potentially escaping field` |
| `WORKER_FILE_BUFFER_SIZE` | `Potentially escaping field` |
| `WORKER_STARTUP_TIMEOUT` | `Potentially escaping field` |
| `WORKER_DATA_SERVER_DOMAIN_SOCKET_AS_UUID` | `Potentially escaping field` |
| `WORKER_FAST_DATA_LOAD_ENABLED` | `Potentially escaping field` |
| `WORKER_DATA_SERVER_DOMAIN_SOCKET_ADDRESS` | `Potentially escaping field` |
| `WORKER_DATA_FOLDER_PERMISSIONS` | `Potentially escaping field` |
| `WORKER_DATA_FOLDER` | `Potentially escaping field` |
| `WORKER_CONTAINER_HOSTNAME` | `Potentially escaping field` |
| `WORKER_BLOCK_STORE_TYPE` | `Potentially escaping field` |
| `WORKER_BLOCK_HEARTBEAT_INTERVAL_MS` | `Potentially escaping field` |
| `WORKER_BIND_HOST` | `Potentially escaping field` |
| `MASTER_FILE_SYSTEM_MERGE_INODE_JOURNALS` | `Potentially escaping field` |
| `MASTER_FILE_SYSTEM_OPERATION_RETRY_CACHE_SIZE` | `Potentially escaping field` |
| `MASTER_FILE_SYSTEM_OPERATION_RETRY_CACHE_ENABLED` | `Potentially escaping field` |
| `MASTER_FILE_SYSTEM_LISTSTATUS_RESULTS_PER_MESSAGE` | `Potentially escaping field` |
| `STANDBY_MASTER_GRPC_ENABLED` | `Potentially escaping field` |
| `STANDBY_MASTER_WEB_ENABLED` | `Potentially escaping field` |
| `STANDBY_MASTER_METRICS_SINK_ENABLED` | `Potentially escaping field` |
| `MASTER_WORKER_REGISTER_LEASE_TTL` | `Potentially escaping field` |
| `MASTER_WORKER_REGISTER_LEASE_RESPECT_JVM_SPACE` | `Potentially escaping field` |
| `MASTER_WORKER_REGISTER_LEASE_COUNT` | `Potentially escaping field` |
| `MASTER_WORKER_REGISTER_LEASE_ENABLED` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_FJP_ASYNC` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_FJP_MIN_RUNNABLE` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_FJP_PARALLELISM` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_TPE_ALLOW_CORE_THREADS_TIMEOUT` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_TPE_QUEUE_TYPE` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_KEEPALIVE` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_MAX_POOL_SIZE` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_CORE_POOL_SIZE` | `Potentially escaping field` |
| `MASTER_RPC_EXECUTOR_TYPE` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_IGNORE_TTL` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_UFS_PREFETCH_TIMEOUT` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_UFS_PREFETCH_ENABLED` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_TRAVERSAL_ORDER` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_UFS_PREFETCH_POOL_SIZE` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_GET_DIRECTORY_STATUS_SKIP_LOADING_CHILDREN` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_REPORT_FAILURE` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_INSTRUMENT_EXECUTOR` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_EXECUTOR_POOL_SIZE` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_CONCURRENCY_LEVEL` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_LOCK_POOL_CONCURRENCY_LEVEL` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_LOCK_POOL_HIGH_WATERMARK` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_LOCK_POOL_LOW_WATERMARK` | `Potentially escaping field` |
| `MASTER_METADATA_SYNC_LOCK_POOL_INITSIZE` | `Potentially escaping field` |
| `MASTER_METADATA_CONCURRENT_SYNC_DEDUP` | `Potentially escaping field` |
| `MASTER_LOST_WORKER_DELETION_TIMEOUT_MS` | `Potentially escaping field` |
| `MASTER_WORKER_TIMEOUT_MS` | `Potentially escaping field` |
| `MASTER_WORKER_INFO_CACHE_REFRESH_TIME` | `Potentially escaping field` |
| `MASTER_WORKER_CONNECT_WAIT_TIME` | `Potentially escaping field` |
| `MASTER_WHITELIST` | `Potentially escaping field` |
| `MASTER_WEB_IN_ALLUXIO_DATA_PAGE_COUNT` | `Potentially escaping field` |
| `MASTER_WEB_JOURNAL_CHECKPOINT_WARNING_THRESHOLD_TIME` | `Potentially escaping field` |
| `MASTER_WEB_PORT` | `Potentially escaping field` |
| `MASTER_WEB_HOSTNAME` | `Potentially escaping field` |
| `MASTER_WEB_BIND_HOST` | `Potentially escaping field` |
| `MASTER_UNSAFE_DIRECT_PERSIST_OBJECT_ENABLED` | `Potentially escaping field` |
| `MASTER_UPDATE_CHECK_INTERVAL` | `Potentially escaping field` |
| `MASTER_UPDATE_CHECK_ENABLED` | `Potentially escaping field` |
| `MASTER_UFS_PATH_CACHE_THREADS` | `Potentially escaping field` |
| `MASTER_UFS_PATH_CACHE_CAPACITY` | `Potentially escaping field` |
| `MASTER_UFS_MANAGED_BLOCKING_ENABLED` | `Potentially escaping field` |
| `MASTER_UFS_BLOCK_LOCATION_CACHE_CAPACITY` | `Potentially escaping field` |
| `MASTER_TTL_CHECKER_INTERVAL_MS` | `Potentially escaping field` |
| `MASTER_TIERED_STORE_GLOBAL_MEDIUMTYPE` | `Potentially escaping field` |
| `MASTER_TIERED_STORE_GLOBAL_LEVELS` | `Potentially escaping field` |
| `MASTER_STATE_LOCK_ERROR_THRESHOLD` | `Potentially escaping field` |
| `MASTER_SKIP_ROOT_ACL_CHECK` | `Potentially escaping field` |
| `MASTER_RPC_PORT` | `Potentially escaping field` |
| `MASTER_LOST_PROXY_DELETION_TIMEOUT_MS` | `Potentially escaping field` |
| `MASTER_PROXY_CHECK_HEARTBEAT_INTERVAL` | `Potentially escaping field` |
| `MASTER_PROXY_TIMEOUT_MS` | `Potentially escaping field` |
| `MASTER_PRINCIPAL` | `Potentially escaping field` |
| `MASTER_PERSISTENCE_BLACKLIST` | `Potentially escaping field` |
| `MASTER_PERSISTENCE_SCHEDULER_INTERVAL_MS` | `Potentially escaping field` |
| `MASTER_PERSISTENCE_MAX_TOTAL_WAIT_TIME_MS` | `Potentially escaping field` |
| `MASTER_PERSISTENCE_MAX_INTERVAL_MS` | `Potentially escaping field` |
| `MASTER_PERSISTENCE_INITIAL_INTERVAL_MS` | `Potentially escaping field` |
| `MASTER_PERSISTENCE_CHECKER_INTERVAL_MS` | `Potentially escaping field` |
| `MASTER_RECURSIVE_OPERATION_JOURNAL_FORCE_FLUSH_MAX_ENTRIES` | `Potentially escaping field` |
| `MASTER_MERGE_JOURNAL_CONTEXT_NUM_ENTRIES_LOGGING_THRESHOLD` | `Potentially escaping field` |
| `MASTER_LOG_CONFIG_REPORT_HEARTBEAT_INTERVAL` | `Potentially escaping field` |
| `MASTER_KEYTAB_KEY_FILE` | `Potentially escaping field` |
| `MASTER_JOURNAL_TEMPORARY_FILE_GC_THRESHOLD_MS` | `Potentially escaping field` |
| `MASTER_JOURNAL_GC_THRESHOLD_MS` | `Potentially escaping field` |
| `MASTER_JOURNAL_GC_PERIOD_MS` | `Potentially escaping field` |
| `MASTER_JOURNAL_LOCAL_LOG_COMPACTION` | `Potentially escaping field` |
| `MASTER_JOURNAL_CHECKPOINT_PERIOD_ENTRIES` | `Potentially escaping field` |
| `MASTER_JOURNAL_TAILER_SLEEP_TIME_MS` | `Potentially escaping field` |