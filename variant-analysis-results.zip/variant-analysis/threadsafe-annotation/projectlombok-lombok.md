### projectlombok/lombok

| c |
| --- |
| [`S3Configuration`](https://github.com/projectlombok/lombok/blob/9dc7e7f0cf55554c90ae59f00e73d810d4cce22b/ivyCache/software.amazon.awssdk/s3/jars/s3-2.19.29.jar/software/amazon/awssdk/services/s3/S3Configuration.class) |