### swagger-api/swagger-core

| c |
| --- |
| `StampedCommonCache` |
| `ModelType` |
| `ModelPath` |
| `ExecutionNodeAccessHierarchy` |
| `ModelReference` |
| `UnboundRule` |
| `UnboundRuleInput` |