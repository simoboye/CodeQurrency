### prestodb/presto

[presto-cassandra/src/main/java/com/facebook/presto/cassandra/ReopeningCluster.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-cassandra/src/main/java/com/facebook/presto/cassandra/ReopeningCluster.java#L39C21-L39C27)

<pre><code class="java">    private Cluster delegate;
    @GuardedBy("this")
    private boolean <strong>closed</strong>;

    private final Supplier&lt;Cluster&gt; supplier;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L51C67-L51C85)

<pre><code class="java">    // Types can be cached in BuiltInTypeAndFunctionNamespaceManager, so let's ensure this is thread safe.
    private Optional&lt;DistinctType&gt; lazilyLoadedParentType;
    private Optional&lt;Function&lt;QualifiedObjectName, DistinctType&gt;&gt; <strong>distinctTypeLoader</strong>;

    public DistinctType(DistinctTypeInfo distinctTypeInfo, Type baseType, Function&lt;QualifiedObjectName, DistinctType&gt; distinctTypeLoader)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L50C36-L50C58)

<pre><code class="java">    private final Optional&lt;QualifiedObjectName&gt; parentTypeName;
    // Types can be cached in BuiltInTypeAndFunctionNamespaceManager, so let's ensure this is thread safe.
    private Optional&lt;DistinctType&gt; <strong>lazilyLoadedParentType</strong>;
    private Optional&lt;Function&lt;QualifiedObjectName, DistinctType&gt;&gt; distinctTypeLoader;

</code></pre>

*Is not safely published*

----------------------------------------

[presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L52C17-L52C30)

<pre><code class="java">    private boolean finishing;
    @GuardedBy("this")
    private int <strong>borrowerCount</strong>;

    private final Executor executor;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L50C21-L50C30)

<pre><code class="java">    private SettableFuture&lt;?&gt; notEmptySignal = SettableFuture.create();
    @GuardedBy("this")
    private boolean <strong>finishing</strong>;
    @GuardedBy("this")
    private int borrowerCount;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L48C31-L48C45)

<pre><code class="java">    // This future is completed when the queue transitions from empty to not. But it will be replaced by a new instance of future immediately.
    @GuardedBy("this")
    private SettableFuture&lt;?&gt; <strong>notEmptySignal</strong> = SettableFuture.create();
    @GuardedBy("this")
    private boolean finishing;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L45C31-L45C44)

<pre><code class="java">    // This future is completed when the queue transitions from full to not. But it will be replaced by a new instance of future immediately.
    @GuardedBy("this")
    private SettableFuture&lt;?&gt; <strong>notFullSignal</strong> = SettableFuture.create();
    // This future is completed when the queue transitions from empty to not. But it will be replaced by a new instance of future immediately.
    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L42C22-L42C30)

<pre><code class="java">
    @GuardedBy("this")
    private Queue&lt;T&gt; <strong>elements</strong>;
    // This future is completed when the queue transitions from full to not. But it will be replaced by a new instance of future immediately.
    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-hive-metastore/src/main/java/com/facebook/presto/hive/metastore/file/FileHiveMetastore.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive-metastore/src/main/java/com/facebook/presto/hive/metastore/file/FileHiveMetastore.java#L141C18-L141C31)

<pre><code class="java">
    private final BiMap&lt;Long, HiveTableName&gt; lockedHiveTables = HashBiMap.create();
    private long <strong>currentLockId</strong>;

    private final JsonCodec&lt;DatabaseMetadata&gt; databaseCodec = JsonCodec.jsonCodec(DatabaseMetadata.class);
</code></pre>

*Is not safely published*

----------------------------------------

[presto-jdbc/src/main/java/com/facebook/presto/jdbc/WarningsManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-jdbc/src/main/java/com/facebook/presto/jdbc/WarningsManager.java#L33C30-L33C42)

<pre><code class="java">{
    @GuardedBy("this")
    private Set&lt;WarningCode&gt; <strong>warningsSeen</strong> = new HashSet&lt;&gt;();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L280C26-L280C39)

<pre><code class="java">            private final AtomicDouble localValue = new AtomicDouble();
            private long previousTaskAge;
            private long <strong>previousValue</strong>;

            AccumulatedTaskStatsTracker(String counterName, TaskId taskId, AtomicDouble totalValue)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L279C26-L279C41)

<pre><code class="java">            private final AtomicDouble totalValue;
            private final AtomicDouble localValue = new AtomicDouble();
            private long <strong>previousTaskAge</strong>;
            private long previousValue;

</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java#L1198C25-L1198C48)

<pre><code class="java">        private final Map&lt;URI, TaskId&gt; exchangeLocations = new LinkedHashMap&lt;&gt;();
        @GuardedBy("this")
        private boolean <strong>noMoreExchangeLocations</strong>;

        public QueryOutputManager(Executor executor)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java#L1194C28-L1194C39)

<pre><code class="java">        private List&lt;String&gt; columnNames;
        @GuardedBy("this")
        private List&lt;Type&gt; <strong>columnTypes</strong>;
        @GuardedBy("this")
        private final Map&lt;URI, TaskId&gt; exchangeLocations = new LinkedHashMap&lt;&gt;();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java#L1192C30-L1192C41)

<pre><code class="java">
        @GuardedBy("this")
        private List&lt;String&gt; <strong>columnNames</strong>;
        @GuardedBy("this")
        private List&lt;Type&gt; columnTypes;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/QueryTracker.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/QueryTracker.java#L83C32-L83C46)

<pre><code class="java">
    @GuardedBy("this")
    private ScheduledFuture&lt;?&gt; <strong>backgroundTask</strong>;

    private final Optional&lt;ClusterQueryTrackerService&gt; clusterQueryTrackerService;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L141C49-L141C74)

<pre><code class="java">
    @GuardedBy("this")
    private Optional&lt;StageTaskRecoveryCallback&gt; <strong>stageTaskRecoveryCallback</strong> = Optional.empty();

    public static SqlStageExecution createSqlStageExecution(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L697C22-L697C42)

<pre><code class="java">    {
        private long previousUserMemory;
        private long <strong>previousSystemMemory</strong>;
        private final Set&lt;Lifespan&gt; completedDriverGroups = new HashSet&lt;&gt;();
        private final TaskId taskId;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L696C22-L696C40)

<pre><code class="java">            implements StateChangeListener&lt;TaskStatus&gt;
    {
        private long <strong>previousUserMemory</strong>;
        private long previousSystemMemory;
        private final Set&lt;Lifespan&gt; completedDriverGroups = new HashSet&lt;&gt;();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L756C25-L756C31)

<pre><code class="java">    {
        private final List&lt;Consumer&lt;T&gt;&gt; listeners = new ArrayList&lt;&gt;();
        private boolean <strong>frozen</strong>;

        public synchronized void addListener(Consumer&lt;T&gt; listener)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlTaskExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlTaskExecution.java#L1156C25-L1156C40)

<pre><code class="java">
        @GuardedBy("this")
        private boolean <strong>noMoreLifespans</strong>;

        public Status(TaskContext taskContext, OutputBuffer outputBuffer, Map&lt;Integer, PipelineExecutionStrategy&gt; pipelineToExecutionStrategy)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlTaskExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlTaskExecution.java#L1153C21-L1153C43)

<pre><code class="java">
        @GuardedBy("this")
        private int <strong>overallRemainingDriver</strong>;

        @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/StateMachine.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/StateMachine.java#L54C24-L54C29)

<pre><code class="java">
    @GuardedBy("lock")
    private volatile T <strong>state</strong>;

    @GuardedBy("lock")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/buffer/ArbitraryOutputBuffer.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/ArbitraryOutputBuffer.java#L445C25-L445C36)

<pre><code class="java">
        @GuardedBy("this")
        private boolean <strong>noMorePages</strong>;

        private final AtomicInteger bufferedPages = new AtomicInteger();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/buffer/ClientBuffer.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/ClientBuffer.java#L65C21-L65C32)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>noMorePages</strong>;

    // destroyed is set when the client sends a DELETE to the buffer
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/buffer/OutputBufferMemoryManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/OutputBufferMemoryManager.java#L55C33-L55C48)

<pre><code class="java">    private SettableFuture&lt;?&gt; bufferBlockedFuture; // null indicates "no listener registered"
    @GuardedBy("this")
    private ListenableFuture&lt;?&gt; <strong>blockedOnMemory</strong> = NOT_BLOCKED;

    private final AtomicBoolean blockOnFull = new AtomicBoolean(true);
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/buffer/OutputBufferMemoryManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/OutputBufferMemoryManager.java#L50C21-L50C27)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>closed</strong>;
    @Nullable
    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/buffer/SerializedPageReference.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/SerializedPageReference.java#L36C26-L36C40)

<pre><code class="java">    private final SerializedPage serializedPage;
    private final Lifespan lifespan;
    private volatile int <strong>referenceCount</strong>;

    public SerializedPageReference(SerializedPage serializedPage, int referenceCount, Lifespan lifespan)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L184C30-L184C39)

<pre><code class="java">    private volatile boolean closed;

    private volatile boolean <strong>lowMemory</strong>;

    @Inject
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L182C30-L182C36)

<pre><code class="java">    private final TimeStat unblockedQuantaWallTime = new TimeStat(MICROSECONDS);

    private volatile boolean <strong>closed</strong>;

    private volatile boolean lowMemory;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java#L38C30-L38C39)

<pre><code class="java">public class TaskHandle
{
    private volatile boolean <strong>destroyed</strong>;
    private final TaskId taskId;
    private final DoubleSupplier utilizationSupplier;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L160C27-L160C34)

<pre><code class="java">    private AtomicLong lastRunningQueryStartTime = new AtomicLong(currentTimeMillis());
    @GuardedBy("root")
    private AtomicBoolean <strong>isDirty</strong> = new AtomicBoolean();

    protected InternalResourceGroup(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L158C24-L158C49)

<pre><code class="java">
    @GuardedBy("root")
    private AtomicLong <strong>lastRunningQueryStartTime</strong> = new AtomicLong(currentTimeMillis());
    @GuardedBy("root")
    private AtomicBoolean isDirty = new AtomicBoolean();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L153C18-L153C33)

<pre><code class="java">    private long cpuUsageMillis;
    @GuardedBy("root")
    private long <strong>lastStartMillis</strong>;
    @GuardedBy("root")
    private final CounterStat timeBetweenStartsSec = new CounterStat();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L151C18-L151C32)

<pre><code class="java">    private long cachedMemoryUsageBytes;
    @GuardedBy("root")
    private long <strong>cpuUsageMillis</strong>;
    @GuardedBy("root")
    private long lastStartMillis;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L149C18-L149C40)

<pre><code class="java">    // Memory usage is cached because it changes very rapidly while queries are running, and would be expensive to track continuously
    @GuardedBy("root")
    private long <strong>cachedMemoryUsageBytes</strong>;
    @GuardedBy("root")
    private long cpuUsageMillis;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L146C17-L146C40)

<pre><code class="java">    private int descendantRunningQueries;
    @GuardedBy("root")
    private int <strong>descendantQueuedQueries</strong>;
    // Memory usage is cached because it changes very rapidly while queries are running, and would be expensive to track continuously
    @GuardedBy("root")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L144C17-L144C41)

<pre><code class="java">    private final Set&lt;ManagedQueryExecution&gt; runningQueries = new HashSet&lt;&gt;();
    @GuardedBy("root")
    private int <strong>descendantRunningQueries</strong>;
    @GuardedBy("root")
    private int descendantQueuedQueries;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L140C48-L140C61)

<pre><code class="java">    private final Set&lt;InternalResourceGroup&gt; dirtySubGroups = new HashSet&lt;&gt;();
    @GuardedBy("root")
    private TieredQueue&lt;ManagedQueryExecution&gt; <strong>queuedQueries</strong> = new TieredQueue&lt;&gt;(FifoQueue::new);
    @GuardedBy("root")
    private final Set&lt;ManagedQueryExecution&gt; runningQueries = new HashSet&lt;&gt;();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L135C42-L135C59)

<pre><code class="java">    // That is, they must return true when internalStartNext() is called on them
    @GuardedBy("root")
    private Queue&lt;InternalResourceGroup&gt; <strong>eligibleSubGroups</strong> = new FifoQueue&lt;&gt;();
    // Sub groups whose memory usage may be out of date. Most likely because they have a running query.
    @GuardedBy("root")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L126C38-L126C52)

<pre><code class="java">    private boolean jmxExport;
    @GuardedBy("root")
    private ResourceGroupQueryLimits <strong>perQueryLimits</strong> = NO_LIMITS;

    // Live data structures
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L124C21-L124C30)

<pre><code class="java">    private SchedulingPolicy schedulingPolicy = FAIR;
    @GuardedBy("root")
    private boolean <strong>jmxExport</strong>;
    @GuardedBy("root")
    private ResourceGroupQueryLimits perQueryLimits = NO_LIMITS;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L122C30-L122C46)

<pre><code class="java">    private int schedulingWeight = DEFAULT_WEIGHT;
    @GuardedBy("root")
    private SchedulingPolicy <strong>schedulingPolicy</strong> = FAIR;
    @GuardedBy("root")
    private boolean jmxExport;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L120C17-L120C33)

<pre><code class="java">    private long cpuQuotaGenerationMillisPerSecond = Long.MAX_VALUE;
    @GuardedBy("root")
    private int <strong>schedulingWeight</strong> = DEFAULT_WEIGHT;
    @GuardedBy("root")
    private SchedulingPolicy schedulingPolicy = FAIR;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L118C18-L118C51)

<pre><code class="java">    private long hardCpuLimitMillis = Long.MAX_VALUE;
    @GuardedBy("root")
    private long <strong>cpuQuotaGenerationMillisPerSecond</strong> = Long.MAX_VALUE;
    @GuardedBy("root")
    private int schedulingWeight = DEFAULT_WEIGHT;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L116C18-L116C36)

<pre><code class="java">    private long softCpuLimitMillis = Long.MAX_VALUE;
    @GuardedBy("root")
    private long <strong>hardCpuLimitMillis</strong> = Long.MAX_VALUE;
    @GuardedBy("root")
    private long cpuQuotaGenerationMillisPerSecond = Long.MAX_VALUE;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L114C18-L114C36)

<pre><code class="java">    private int maxQueuedQueries;
    @GuardedBy("root")
    private long <strong>softCpuLimitMillis</strong> = Long.MAX_VALUE;
    @GuardedBy("root")
    private long hardCpuLimitMillis = Long.MAX_VALUE;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L112C17-L112C33)

<pre><code class="java">    private int hardConcurrencyLimit;
    @GuardedBy("root")
    private int <strong>maxQueuedQueries</strong>;
    @GuardedBy("root")
    private long softCpuLimitMillis = Long.MAX_VALUE;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L110C17-L110C37)

<pre><code class="java">    private int workersPerQueryLimit;
    @GuardedBy("root")
    private int <strong>hardConcurrencyLimit</strong>;
    @GuardedBy("root")
    private int maxQueuedQueries;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L108C17-L108C37)

<pre><code class="java">    private int softConcurrencyLimit;
    @GuardedBy("root")
    private int <strong>workersPerQueryLimit</strong>;
    @GuardedBy("root")
    private int hardConcurrencyLimit;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L106C17-L106C37)

<pre><code class="java">    private long softMemoryLimitBytes = Long.MAX_VALUE;
    @GuardedBy("root")
    private int <strong>softConcurrencyLimit</strong>;
    @GuardedBy("root")
    private int workersPerQueryLimit;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L104C18-L104C38)

<pre><code class="java">    // =============
    @GuardedBy("root")
    private long <strong>softMemoryLimitBytes</strong> = Long.MAX_VALUE;
    @GuardedBy("root")
    private int softConcurrencyLimit;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L1131C31-L1131C48)

<pre><code class="java">            extends InternalResourceGroup
    {
        private AtomicBoolean <strong>taskLimitExceeded</strong> = new AtomicBoolean();

        public RootInternalResourceGroup(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/scheduler/BroadcastOutputBufferManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/scheduler/BroadcastOutputBufferManager.java#L37C27-L37C40)

<pre><code class="java">
    @GuardedBy("this")
    private OutputBuffers <strong>outputBuffers</strong> = createInitialEmptyOutputBuffers(BROADCAST);

    public BroadcastOutputBufferManager(Consumer&lt;OutputBuffers&gt; outputBufferTarget)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java#L49C18-L49C29)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>leakedBytes</strong>;

    /**
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java#L46C26-L46C39)

<pre><code class="java">
    @GuardedBy("this")
    private Set&lt;QueryId&gt; <strong>leakedQueries</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java#L58C17-L58C32)

<pre><code class="java">
    @GuardedBy("this")
    private int <strong>assignedQueries</strong>;

    // Does not include queries with zero memory usage
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java#L49C18-L49C51)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>reservedRevocableDistributedBytes</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java#L46C18-L46C42)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>reservedDistributedBytes</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java#L43C18-L43C39)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>totalDistributedBytes</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L122C30-L122C46)

<pre><code class="java">
    @GuardedBy("this")
    private Optional&lt;String&gt; <strong>heapDumpFilePath</strong>;

    public QueryContext(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L119C21-L119C57)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>heapDumpOnExceededMemoryLimitEnabled</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L116C21-L116C60)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>verboseExceededMemoryLimitErrorsEnabled</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L113C18-L113C27)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>spillUsed</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L110C24-L110C34)

<pre><code class="java">
    @GuardedBy("this")
    private MemoryPool <strong>memoryPool</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L105C18-L105C40)

<pre><code class="java">    private long broadcastUsed;
    @GuardedBy("this")
    private long <strong>maxBroadcastUsedMemory</strong>;

    private final MemoryTrackingContext queryMemoryContext;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L103C18-L103C31)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>broadcastUsed</strong>;
    @GuardedBy("this")
    private long maxBroadcastUsedMemory;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L100C18-L100C36)

<pre><code class="java">    private long peakNodeTotalMemory;
    @GuardedBy("this")
    private long <strong>maxRevocableMemory</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L98C18-L98C37)

<pre><code class="java">    private long maxTotalMemory;
    @GuardedBy("this")
    private long <strong>peakNodeTotalMemory</strong>;
    @GuardedBy("this")
    private long maxRevocableMemory;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L96C18-L96C32)

<pre><code class="java">    private long maxUserMemory;
    @GuardedBy("this")
    private long <strong>maxTotalMemory</strong>;
    @GuardedBy("this")
    private long peakNodeTotalMemory;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L94C18-L94C31)

<pre><code class="java">    // TODO: This field should be final. However, due to the way QueryContext is constructed the memory limit is not known in advance
    @GuardedBy("this")
    private long <strong>maxUserMemory</strong>;
    @GuardedBy("this")
    private long maxTotalMemory;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L90C30-L90C53)

<pre><code class="java">    @GuardedBy("this")
    private boolean resourceOverCommit;
    private volatile boolean <strong>memoryLimitsInitialized</strong>;

    // TODO: This field should be final. However, due to the way QueryContext is constructed the memory limit is not known in advance
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L89C21-L89C39)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>resourceOverCommit</strong>;
    private volatile boolean memoryLimitsInitialized;

</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java#L547C34-L547C43)

<pre><code class="java">    private final MagicLiteralFunction magicLiteralFunction;

    private volatile FunctionMap <strong>functions</strong> = new FunctionMap();

    public BuiltInTypeAndFunctionNamespaceManager(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L128C31-L128C45)

<pre><code class="java">
    @GuardedBy("this")
    private Set&lt;InternalNode&gt; <strong>catalogServers</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L125C31-L125C47)

<pre><code class="java">
    @GuardedBy("this")
    private Set&lt;InternalNode&gt; <strong>resourceManagers</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L122C31-L122C43)

<pre><code class="java">
    @GuardedBy("this")
    private Set&lt;InternalNode&gt; <strong>coordinators</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L119C22-L119C30)

<pre><code class="java">
    @GuardedBy("this")
    private AllNodes <strong>allNodes</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L116C39-L116C44)

<pre><code class="java">
    @GuardedBy("this")
    private Map&lt;String, InternalNode&gt; <strong>nodes</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L113C46-L113C66)

<pre><code class="java">
    @GuardedBy("this")
    private SetMultimap&lt;String, ConnectorId&gt; <strong>connectorIdsByNodeId</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L110C52-L110C70)

<pre><code class="java">
    @GuardedBy("this")
    private SetMultimap&lt;ConnectorId, InternalNode&gt; <strong>nodesByConnectorId</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L107C52-L107C76)

<pre><code class="java">
    @GuardedBy("this")
    private SetMultimap&lt;ConnectorId, InternalNode&gt; <strong>activeNodesByConnectorId</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/DriverYieldSignal.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/DriverYieldSignal.java#L49C21-L49C39)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>terminationStarted</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/DriverYieldSignal.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/DriverYieldSignal.java#L46C18-L46C33)

<pre><code class="java">{
    @GuardedBy("this")
    private long <strong>runningSequence</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L115C18-L115C36)

<pre><code class="java">    private long maxBufferRetainedSizeInBytes;
    @GuardedBy("this")
    private long <strong>successfulRequests</strong>;
    @GuardedBy("this")
    private final ExponentialMovingAverage responseSizeExponentialMovingAverage;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L113C18-L113C46)

<pre><code class="java">    private long bufferRetainedSizeInBytes;
    @GuardedBy("this")
    private long <strong>maxBufferRetainedSizeInBytes</strong>;
    @GuardedBy("this")
    private long successfulRequests;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L111C18-L111C43)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>bufferRetainedSizeInBytes</strong>;
    @GuardedBy("this")
    private long maxBufferRetainedSizeInBytes;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L94C21-L94C36)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>noMoreLocations</strong>;

    private final ConcurrentMap&lt;URI, PageBufferClient&gt; allClients = new ConcurrentHashMap&lt;&gt;();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L554C24-L554C32)

<pre><code class="java">    {
        private final double alpha;
        private double <strong>oldValue</strong>;

        public ExponentialMovingAverage(double alpha, long initialValue)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L237C32-L237C50)

<pre><code class="java">    private OptionalLong lookupSourceChecksum = OptionalLong.empty();

    private Optional&lt;Runnable&gt; <strong>finishMemoryRevoke</strong> = Optional.empty();

    private final boolean enforceBroadcastMemoryLimit;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L235C26-L235C46)

<pre><code class="java">    @Nullable
    private LookupSourceSupplier lookupSourceSupplier;
    private OptionalLong <strong>lookupSourceChecksum</strong> = OptionalLong.empty();

    private Optional&lt;Runnable&gt; finishMemoryRevoke = Optional.empty();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L232C52-L232C69)

<pre><code class="java">    private Optional&lt;SingleStreamSpiller&gt; spiller = Optional.empty();
    private ListenableFuture&lt;?&gt; spillInProgress = NOT_BLOCKED;
    private Optional&lt;ListenableFuture&lt;List&lt;Page&gt;&gt;&gt; <strong>unspillInProgress</strong> = Optional.empty();
    @Nullable
    private LookupSourceSupplier lookupSourceSupplier;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L231C33-L231C48)

<pre><code class="java">    private final SpilledLookupSourceHandle spilledLookupSourceHandle = new SpilledLookupSourceHandle();
    private Optional&lt;SingleStreamSpiller&gt; spiller = Optional.empty();
    private ListenableFuture&lt;?&gt; <strong>spillInProgress</strong> = NOT_BLOCKED;
    private Optional&lt;ListenableFuture&lt;List&lt;Page&gt;&gt;&gt; unspillInProgress = Optional.empty();
    @Nullable
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L230C43-L230C50)

<pre><code class="java">    private Optional&lt;ListenableFuture&lt;?&gt;&gt; lookupSourceNotNeeded = Optional.empty();
    private final SpilledLookupSourceHandle spilledLookupSourceHandle = new SpilledLookupSourceHandle();
    private Optional&lt;SingleStreamSpiller&gt; <strong>spiller</strong> = Optional.empty();
    private ListenableFuture&lt;?&gt; spillInProgress = NOT_BLOCKED;
    private Optional&lt;ListenableFuture&lt;List&lt;Page&gt;&gt;&gt; unspillInProgress = Optional.empty();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L228C43-L228C64)

<pre><code class="java">
    private State state = State.CONSUMING_INPUT;
    private Optional&lt;ListenableFuture&lt;?&gt;&gt; <strong>lookupSourceNotNeeded</strong> = Optional.empty();
    private final SpilledLookupSourceHandle spilledLookupSourceHandle = new SpilledLookupSourceHandle();
    private Optional&lt;SingleStreamSpiller&gt; spiller = Optional.empty();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L227C19-L227C24)

<pre><code class="java">    private final HashCollisionsCounter hashCollisionsCounter;

    private State <strong>state</strong> = State.CONSUMING_INPUT;
    private Optional&lt;ListenableFuture&lt;?&gt;&gt; lookupSourceNotNeeded = Optional.empty();
    private final SpilledLookupSourceHandle spilledLookupSourceHandle = new SpilledLookupSourceHandle();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L82C25-L82C52)

<pre><code class="java">
        private boolean closed;
        private boolean <strong>enforceBroadcastMemoryLimit</strong>;

        public HashBuilderOperatorFactory(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L81C25-L81C31)

<pre><code class="java">        private final Map&lt;Lifespan, Integer&gt; partitionIndexManager = new HashMap&lt;&gt;();

        private boolean <strong>closed</strong>;
        private boolean enforceBroadcastMemoryLimit;

</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/OuterLookupSource.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/OuterLookupSource.java#L123C21-L123C36)

<pre><code class="java">
        @GuardedBy("this")
        private int <strong>currentPosition</strong>;

        public SharedLookupOuterPositionIterator(LookupSource lookupSource, boolean[] visitedPositions)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/OuterLookupSource.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/OuterLookupSource.java#L181C25-L181C33)

<pre><code class="java">
        @GuardedBy("this")
        private boolean <strong>finished</strong>;

        public OuterPositionTracker(Supplier&lt;LookupSource&gt; lookupSourceSupplier)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L106C20-L106C34)

<pre><code class="java">    private boolean completed;
    @GuardedBy("this")
    private String <strong>taskInstanceId</strong>;

    private final AtomicLong rowsReceived = new AtomicLong();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L104C21-L104C30)

<pre><code class="java">    private boolean scheduled;
    @GuardedBy("this")
    private boolean <strong>completed</strong>;
    @GuardedBy("this")
    private String taskInstanceId;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L100C18-L100C23)

<pre><code class="java">    private DateTime lastUpdate = DateTime.now();
    @GuardedBy("this")
    private long <strong>token</strong>;
    @GuardedBy("this")
    private boolean scheduled;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L98C22-L98C32)

<pre><code class="java">    private ListenableFuture&lt;?&gt; future;
    @GuardedBy("this")
    private DateTime <strong>lastUpdate</strong> = DateTime.now();
    @GuardedBy("this")
    private long token;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L94C21-L94C27)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>closed</strong>;
    @GuardedBy("this")
    private ListenableFuture&lt;?&gt; future;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java#L129C21-L129C36)

<pre><code class="java">
        @GuardedBy("this")
        private int <strong>pendingReleases</strong>;

        public Partition(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L544C21-L544C44)

<pre><code class="java">        // physically queued drivers: actual number of instantiated drivers whose execution hasn't started
        // conceptually queued drivers: includes assigned splits that haven't been turned into a driver
        private int <strong>physicallyQueuedDrivers</strong>;

        private PipelineStatusBuilder(int totalSplits, int completedDrivers, long activePartitionedSplitsWeight, boolean partitioned)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L536C22-L536C41)

<pre><code class="java">        private int blockedDrivers;
        private long runningSplitsWeight;
        private long <strong>blockedSplitsWeight</strong>;
        // When a split for a partitioned pipeline is delivered to a worker,
        // conceptually, the worker would have an additional driver.
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L535C22-L535C41)

<pre><code class="java">        private int runningDrivers;
        private int blockedDrivers;
        private long <strong>runningSplitsWeight</strong>;
        private long blockedSplitsWeight;
        // When a split for a partitioned pipeline is delivered to a worker,
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L534C21-L534C35)

<pre><code class="java">        private final boolean partitioned;
        private int runningDrivers;
        private int <strong>blockedDrivers</strong>;
        private long runningSplitsWeight;
        private long blockedSplitsWeight;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L533C21-L533C35)

<pre><code class="java">        private final long activePartitionedSplitsWeight;
        private final boolean partitioned;
        private int <strong>runningDrivers</strong>;
        private int blockedDrivers;
        private long runningSplitsWeight;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ReferenceCount.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ReferenceCount.java#L31C17-L31C22)

<pre><code class="java">
    @GuardedBy("this")
    private int <strong>count</strong>;

    public ReferenceCount(int initialCount)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L128C21-L128C29)

<pre><code class="java">    private final ChannelSetBuilder channelSetBuilder;

    private boolean <strong>finished</strong>;

    @Nullable
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L74C25-L74C31)

<pre><code class="java">        private final int setChannel;
        private final int expectedPositions;
        private boolean <strong>closed</strong>;
        private final JoinCompiler joinCompiler;

</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L43C19-L43C24)

<pre><code class="java">
    @GuardedBy("this")
    private State <strong>state</strong> = State.SPILLED;

    private final SettableFuture&lt;?&gt; unspillingRequested = SettableFuture.create();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java#L127C18-L127C39)

<pre><code class="java">
    @GuardedBy("cumulativeMemoryLock")
    private long <strong>lastTaskStatCallNanos</strong>;

    private final MemoryTrackingContext taskMemoryContext;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java#L124C18-L124C44)

<pre><code class="java">
    @GuardedBy("cumulativeMemoryLock")
    private long <strong>lastTotalMemoryReservation</strong>;

    @GuardedBy("cumulativeMemoryLock")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java#L121C18-L121C43)

<pre><code class="java">
    @GuardedBy("cumulativeMemoryLock")
    private long <strong>lastUserMemoryReservation</strong>;

    @GuardedBy("cumulativeMemoryLock")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L86C17-L86C32)

<pre><code class="java">
    @GuardedBy("this")
    private int <strong>nextSourceIndex</strong>;

    public LocalExchange(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L74C21-L74C40)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>noMoreSinkFactories</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L71C21-L71C39)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>allSourcesFinished</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L337C21-L337C37)

<pre><code class="java">        // so that the exact number of sink factory is known by the time execution starts.
        @GuardedBy("this")
        private int <strong>numSinkFactories</strong>;

        @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L333C25-L333C44)

<pre><code class="java">
        @GuardedBy("this")
        private boolean <strong>noMoreSinkFactories</strong>;
        // The number of total sink factories are tracked at planning time
        // so that the exact number of sink factory is known by the time execution starts.
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java#L51C30-L51C39)

<pre><code class="java">    private SettableFuture&lt;?&gt; notEmptyFuture; // null indicates no callback present

    private volatile boolean <strong>finishing</strong>;

    public LocalExchangeSource(Consumer&lt;LocalExchangeSource&gt; onFinish)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/PageReference.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/PageReference.java#L31C26-L31C40)

<pre><code class="java">    private static final AtomicIntegerFieldUpdater&lt;PageReference&gt; REFERENCE_COUNT_UPDATER = AtomicIntegerFieldUpdater.newUpdater(PageReference.class, "referenceCount");

    private volatile int <strong>referenceCount</strong>;
    private final Page page;
    private final PageReleasedListener onPageReleased;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java#L90C29-L90C44)

<pre><code class="java">
    @GuardedBy("this")
    private PipelineContext <strong>pipelineContext</strong>; // Lazily initialized

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java#L87C33-L87C52)

<pre><code class="java">
    @GuardedBy("this")
    private IndexSnapshotLoader <strong>indexSnapshotLoader</strong>; // Lazily initialized

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L74C21-L74C29)

<pre><code class="java">    private final IndexSnapshotBuilder indexSnapshotBuilder;

    private boolean <strong>finished</strong>;

    public PagesIndexBuilderOperator(OperatorContext operatorContext, IndexSnapshotBuilder indexSnapshotBuilder)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L39C25-L39C31)

<pre><code class="java">        private final IndexSnapshotBuilder indexSnapshotBuilder;
        private final String operatorType;
        private boolean <strong>closed</strong>;

        public PagesIndexBuilderOperatorFactory(int operatorId, PlanNodeId planNodeId, IndexSnapshotBuilder indexSnapshotBuilder, String operatorType)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/RequestErrorTracker.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/RequestErrorTracker.java#L58C20-L58C36)

<pre><code class="java">    private final URI uri;
    private ErrorCodeSupplier errorCode;
    private String <strong>nodeErrorMessage</strong>;
    private final ScheduledExecutorService scheduledExecutor;
    private final String jobDescription;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/RequestErrorTracker.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/RequestErrorTracker.java#L57C31-L57C40)

<pre><code class="java">    private final Object id;
    private final URI uri;
    private ErrorCodeSupplier <strong>errorCode</strong>;
    private String nodeErrorMessage;
    private final ScheduledExecutorService scheduledExecutor;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java#L68C33-L68C40)

<pre><code class="java">        private volatile long count;
        @GuardedBy("this")
        private volatile double <strong>average</strong>;

        public synchronized void add(long value)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java#L66C31-L66C36)

<pre><code class="java">    {
        @GuardedBy("this")
        private volatile long <strong>count</strong>;
        @GuardedBy("this")
        private volatile double average;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L169C32-L169C55)

<pre><code class="java">
    @GuardedBy("this")
    private Set&lt;SqlFunctionId&gt; <strong>removedSessionFunctions</strong> = ImmutableSet.of();

    public static Query create(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L166C52-L166C73)

<pre><code class="java">
    @GuardedBy("this")
    private Map&lt;SqlFunctionId, SqlInvokedFunction&gt; <strong>addedSessionFunctions</strong> = ImmutableMap.of();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L163C21-L163C38)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>hasProducedResult</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L160C18-L160C29)

<pre><code class="java">
    @GuardedBy("this")
    private Long <strong>updateCount</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L157C21-L157C39)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>clearTransactionId</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L154C37-L154C57)

<pre><code class="java">
    @GuardedBy("this")
    private Optional&lt;TransactionId&gt; <strong>startedTransactionId</strong> = Optional.empty();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L151C25-L151C54)

<pre><code class="java">
    @GuardedBy("this")
    private Set&lt;String&gt; <strong>deallocatedPreparedStatements</strong> = ImmutableSet.of();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L148C33-L148C56)

<pre><code class="java">
    @GuardedBy("this")
    private Map&lt;String, String&gt; <strong>addedPreparedStatements</strong> = ImmutableMap.of();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L145C39-L145C47)

<pre><code class="java">
    @GuardedBy("this")
    private Map&lt;String, SelectedRole&gt; <strong>setRoles</strong> = ImmutableMap.of();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L142C25-L142C47)

<pre><code class="java">
    @GuardedBy("this")
    private Set&lt;String&gt; <strong>resetSessionProperties</strong> = ImmutableSet.of();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L139C33-L139C53)

<pre><code class="java">
    @GuardedBy("this")
    private Map&lt;String, String&gt; <strong>setSessionProperties</strong> = ImmutableMap.of();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L136C30-L136C39)

<pre><code class="java">
    @GuardedBy("this")
    private Optional&lt;String&gt; <strong>setSchema</strong> = Optional.empty();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L133C30-L133C40)

<pre><code class="java">
    @GuardedBy("this")
    private Optional&lt;String&gt; <strong>setCatalog</strong> = Optional.empty();

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L130C24-L130C29)

<pre><code class="java">
    @GuardedBy("this")
    private List&lt;Type&gt; <strong>types</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L127C26-L127C33)

<pre><code class="java">
    @GuardedBy("this")
    private List&lt;Column&gt; <strong>columns</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L124C18-L124C27)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>lastToken</strong> = -1;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L121C26-L121C36)

<pre><code class="java">
    @GuardedBy("this")
    private QueryResults <strong>lastResult</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L118C26-L118C35)

<pre><code class="java">
    @GuardedBy("this")
    private OptionalLong <strong>nextToken</strong> = OptionalLong.of(0);

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L54C18-L54C34)

<pre><code class="java">    private long failureRequestTimeTotal;

    private long <strong>lastRequestStart</strong>;

    public Backoff(Duration maxFailureInterval)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L52C18-L52C41)

<pre><code class="java">    private long lastFailureTime;
    private long failureCount;
    private long <strong>failureRequestTimeTotal</strong>;

    private long lastRequestStart;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L51C18-L51C30)

<pre><code class="java">    private long firstFailureTime;
    private long lastFailureTime;
    private long <strong>failureCount</strong>;
    private long failureRequestTimeTotal;

</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L50C18-L50C33)

<pre><code class="java">
    private long firstFailureTime;
    private long <strong>lastFailureTime</strong>;
    private long failureCount;
    private long failureRequestTimeTotal;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L49C18-L49C34)

<pre><code class="java">    private final long[] backoffDelayIntervalsNanos;

    private long <strong>firstFailureTime</strong>;
    private long lastFailureTime;
    private long failureCount;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/spiller/FileHolder.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/FileHolder.java#L38C21-L38C28)

<pre><code class="java">
    @GuardedBy("this")
    private boolean <strong>deleted</strong>;

    public FileHolder(Path filePath)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/spiller/GenericPartitioningSpiller.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/GenericPartitioningSpiller.java#L60C21-L60C35)

<pre><code class="java">    private final Optional&lt;SingleStreamSpiller&gt;[] spillers;

    private boolean <strong>readingStarted</strong>;
    private final Set&lt;Integer&gt; spilledPartitions = new HashSet&lt;&gt;();

</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/spiller/LocalSpillContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/LocalSpillContext.java#L29C21-L29C27)

<pre><code class="java">    private final SpillContext parentSpillContext;
    private long spilledBytes;
    private boolean <strong>closed</strong>;

    public LocalSpillContext(SpillContext parentSpillContext)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/spiller/LocalSpillContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/LocalSpillContext.java#L28C18-L28C30)

<pre><code class="java">{
    private final SpillContext parentSpillContext;
    private long <strong>spilledBytes</strong>;
    private boolean closed;

</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/spiller/SpillSpaceTracker.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/SpillSpaceTracker.java#L37C18-L37C30)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>currentBytes</strong>;

    public SpillSpaceTracker(DataSize maxSize)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/sql/planner/LocalDynamicFiltersCollector.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/sql/planner/LocalDynamicFiltersCollector.java#L30C54-L30C63)

<pre><code class="java">     */
    @GuardedBy ("this")
    private TupleDomain&lt;VariableReferenceExpression&gt; <strong>predicate</strong>;

    public LocalDynamicFiltersCollector()
</code></pre>

*Is not safely published*

----------------------------------------

[presto-main/src/test/java/com/facebook/presto/execution/buffer/TestClientBuffer.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/test/java/com/facebook/presto/execution/buffer/TestClientBuffer.java#L495C25-L495C36)

<pre><code class="java">
        @GuardedBy("this")
        private boolean <strong>noMorePages</strong>;

        @Override
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L43C18-L43C30)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>currentBytes</strong>;

    private final Map&lt;Long, TableData&gt; tables = new HashMap&lt;&gt;();
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L150C22-L150C26)

<pre><code class="java">    {
        private final List&lt;Page&gt; pages = new ArrayList&lt;&gt;();
        private long <strong>rows</strong>;

        public void add(Page page)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java#L42C21-L42C27)

<pre><code class="java">    private long usedBytes;
    @GuardedBy("this")
    private boolean <strong>closed</strong>;

    @Override
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java#L40C18-L40C27)

<pre><code class="java">    private long broadcastUsedBytes;
    @GuardedBy("this")
    private long <strong>usedBytes</strong>;
    @GuardedBy("this")
    private boolean closed;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java#L38C18-L38C36)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>broadcastUsedBytes</strong>;
    @GuardedBy("this")
    private long usedBytes;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L55C32-L55C56)

<pre><code class="java">    private LocalMemoryContext userLocalMemoryContext;
    private LocalMemoryContext revocableLocalMemoryContext;
    private LocalMemoryContext <strong>systemLocalMemoryContext</strong>;

    public MemoryTrackingContext(
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L54C32-L54C59)

<pre><code class="java">
    private LocalMemoryContext userLocalMemoryContext;
    private LocalMemoryContext <strong>revocableLocalMemoryContext</strong>;
    private LocalMemoryContext systemLocalMemoryContext;

</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L53C32-L53C54)

<pre><code class="java">    private final AggregatedMemoryContext systemAggregateMemoryContext;

    private LocalMemoryContext <strong>userLocalMemoryContext</strong>;
    private LocalMemoryContext revocableLocalMemoryContext;
    private LocalMemoryContext systemLocalMemoryContext;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/SimpleLocalMemoryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/SimpleLocalMemoryContext.java#L40C21-L40C27)

<pre><code class="java">    private long usedBytes;
    @GuardedBy("this")
    private boolean <strong>closed</strong>;

    public SimpleLocalMemoryContext(AggregatedMemoryContext parentMemoryContext, String allocationTag)
</code></pre>

*Is not safely published*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/SimpleLocalMemoryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/SimpleLocalMemoryContext.java#L38C18-L38C27)

<pre><code class="java">
    @GuardedBy("this")
    private long <strong>usedBytes</strong>;
    @GuardedBy("this")
    private boolean closed;
</code></pre>

*Is not safely published*

----------------------------------------

[presto-pinot-toolkit/src/main/java/com/facebook/presto/pinot/PinotMetricsStats.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-pinot-toolkit/src/main/java/com/facebook/presto/pinot/PinotMetricsStats.java#L35C30-L35C42)

<pre><code class="java">    private final CounterStat requests = new CounterStat();
    private final CounterStat errorRequests = new CounterStat();
    private DistributionStat <strong>responseSize</strong>;

    public PinotMetricsStats(boolean withResponse)
</code></pre>

*Is not safely published*

----------------------------------------

| f |  |
| --- | --- |
| `_packetSize` | `Is not safely published` |
| `_queryTimeout` | `Is not safely published` |
| `_hasReturnedRowsAffected` | `Is not safely published` |
| `_hasRowCount` | `Is not safely published` |
| `_rowsAffected` | `Is not safely published` |
| `_commandInfoLine` | `Is not safely published` |
| `_commandInfoSource` | `Is not safely published` |
| `ticker` | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-cassandra/src/main/java/com/facebook/presto/cassandra/ReopeningCluster.java#L39C21-L39C26) | `Is not safely published` |
| [`distinctTypeLoader`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L51C67-L51C84) | `Is not safely published` |
| [`lazilyLoadedParentType`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L50C36-L50C57) | `Is not safely published` |
| [`borrowerCount`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L52C17-L52C29) | `Is not safely published` |
| [`finishing`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L50C21-L50C29) | `Is not safely published` |
| [`notEmptySignal`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L48C31-L48C44) | `Is not safely published` |
| [`notFullSignal`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L45C31-L45C43) | `Is not safely published` |
| [`elements`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive/src/main/java/com/facebook/presto/hive/util/AsyncQueue.java#L42C22-L42C29) | `Is not safely published` |
| [`currentLockId`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-hive-metastore/src/main/java/com/facebook/presto/hive/metastore/file/FileHiveMetastore.java#L141C18-L141C30) | `Is not safely published` |
| [`warningsSeen`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-jdbc/src/main/java/com/facebook/presto/jdbc/WarningsManager.java#L33C30-L33C41) | `Is not safely published` |
| [`previousValue`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L280C26-L280C38) | `Is not safely published` |
| [`previousTaskAge`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L279C26-L279C40) | `Is not safely published` |
| [`noMoreExchangeLocations`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java#L1198C25-L1198C47) | `Is not safely published` |
| [`columnTypes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java#L1194C28-L1194C38) | `Is not safely published` |
| [`columnNames`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/QueryStateMachine.java#L1192C30-L1192C40) | `Is not safely published` |
| [`backgroundTask`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/QueryTracker.java#L83C32-L83C45) | `Is not safely published` |
| [`stageTaskRecoveryCallback`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L141C49-L141C73) | `Is not safely published` |
| [`previousSystemMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L697C22-L697C41) | `Is not safely published` |
| [`previousUserMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L696C22-L696C39) | `Is not safely published` |
| [`frozen`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L756C25-L756C30) | `Is not safely published` |
| [`noMoreLifespans`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlTaskExecution.java#L1156C25-L1156C39) | `Is not safely published` |
| [`overallRemainingDriver`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlTaskExecution.java#L1153C21-L1153C42) | `Is not safely published` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/StateMachine.java#L54C24-L54C28) | `Is not safely published` |
| [`noMorePages`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/ArbitraryOutputBuffer.java#L445C25-L445C35) | `Is not safely published` |
| [`noMorePages`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/ClientBuffer.java#L65C21-L65C31) | `Is not safely published` |
| [`blockedOnMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/OutputBufferMemoryManager.java#L55C33-L55C47) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/OutputBufferMemoryManager.java#L50C21-L50C26) | `Is not safely published` |
| [`referenceCount`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/buffer/SerializedPageReference.java#L36C26-L36C39) | `Is not safely published` |
| [`lowMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L184C30-L184C38) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L182C30-L182C35) | `Is not safely published` |
| [`destroyed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java#L38C30-L38C38) | `Is not safely published` |
| [`isDirty`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L160C27-L160C33) | `Is not safely published` |
| [`lastRunningQueryStartTime`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L158C24-L158C48) | `Is not safely published` |
| [`lastStartMillis`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L153C18-L153C32) | `Is not safely published` |
| [`cpuUsageMillis`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L151C18-L151C31) | `Is not safely published` |
| [`cachedMemoryUsageBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L149C18-L149C39) | `Is not safely published` |
| [`descendantQueuedQueries`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L146C17-L146C39) | `Is not safely published` |
| [`descendantRunningQueries`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L144C17-L144C40) | `Is not safely published` |
| [`queuedQueries`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L140C48-L140C60) | `Is not safely published` |
| [`eligibleSubGroups`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L135C42-L135C58) | `Is not safely published` |
| [`perQueryLimits`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L126C38-L126C51) | `Is not safely published` |
| [`jmxExport`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L124C21-L124C29) | `Is not safely published` |
| [`schedulingPolicy`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L122C30-L122C45) | `Is not safely published` |
| [`schedulingWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L120C17-L120C32) | `Is not safely published` |
| [`cpuQuotaGenerationMillisPerSecond`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L118C18-L118C50) | `Is not safely published` |
| [`hardCpuLimitMillis`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L116C18-L116C35) | `Is not safely published` |
| [`softCpuLimitMillis`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L114C18-L114C35) | `Is not safely published` |
| [`maxQueuedQueries`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L112C17-L112C32) | `Is not safely published` |
| [`hardConcurrencyLimit`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L110C17-L110C36) | `Is not safely published` |
| [`workersPerQueryLimit`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L108C17-L108C36) | `Is not safely published` |
| [`softConcurrencyLimit`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L106C17-L106C36) | `Is not safely published` |
| [`softMemoryLimitBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L104C18-L104C37) | `Is not safely published` |
| [`taskLimitExceeded`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L1131C31-L1131C47) | `Is not safely published` |
| [`outputBuffers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/scheduler/BroadcastOutputBufferManager.java#L37C27-L37C39) | `Is not safely published` |
| [`leakedBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java#L49C18-L49C28) | `Is not safely published` |
| [`leakedQueries`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java#L46C26-L46C38) | `Is not safely published` |
| [`assignedQueries`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java#L58C17-L58C31) | `Is not safely published` |
| [`reservedRevocableDistributedBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java#L49C18-L49C50) | `Is not safely published` |
| [`reservedDistributedBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java#L46C18-L46C41) | `Is not safely published` |
| [`totalDistributedBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryPool.java#L43C18-L43C38) | `Is not safely published` |
| [`heapDumpFilePath`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L122C30-L122C45) | `Is not safely published` |
| [`heapDumpOnExceededMemoryLimitEnabled`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L119C21-L119C56) | `Is not safely published` |
| [`verboseExceededMemoryLimitErrorsEnabled`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L116C21-L116C59) | `Is not safely published` |
| [`spillUsed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L113C18-L113C26) | `Is not safely published` |
| [`memoryPool`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L110C24-L110C33) | `Is not safely published` |
| [`maxBroadcastUsedMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L105C18-L105C39) | `Is not safely published` |
| [`broadcastUsed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L103C18-L103C30) | `Is not safely published` |
| [`maxRevocableMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L100C18-L100C35) | `Is not safely published` |
| [`peakNodeTotalMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L98C18-L98C36) | `Is not safely published` |
| [`maxTotalMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L96C18-L96C31) | `Is not safely published` |
| [`maxUserMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L94C18-L94C30) | `Is not safely published` |
| [`memoryLimitsInitialized`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L90C30-L90C52) | `Is not safely published` |
| [`resourceOverCommit`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L89C21-L89C38) | `Is not safely published` |
| [`functions`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java#L547C34-L547C42) | `Is not safely published` |
| [`catalogServers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L128C31-L128C44) | `Is not safely published` |
| [`resourceManagers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L125C31-L125C46) | `Is not safely published` |
| [`coordinators`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L122C31-L122C42) | `Is not safely published` |
| [`allNodes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L119C22-L119C29) | `Is not safely published` |
| [`nodes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L116C39-L116C43) | `Is not safely published` |
| [`connectorIdsByNodeId`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L113C46-L113C65) | `Is not safely published` |
| [`nodesByConnectorId`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L110C52-L110C69) | `Is not safely published` |
| [`activeNodesByConnectorId`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/DiscoveryNodeManager.java#L107C52-L107C75) | `Is not safely published` |
| [`terminationStarted`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/DriverYieldSignal.java#L49C21-L49C38) | `Is not safely published` |
| [`runningSequence`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/DriverYieldSignal.java#L46C18-L46C32) | `Is not safely published` |
| [`successfulRequests`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L115C18-L115C35) | `Is not safely published` |
| [`maxBufferRetainedSizeInBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L113C18-L113C45) | `Is not safely published` |
| [`bufferRetainedSizeInBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L111C18-L111C42) | `Is not safely published` |
| [`noMoreLocations`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L94C21-L94C35) | `Is not safely published` |
| [`oldValue`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L554C24-L554C31) | `Is not safely published` |
| [`finishMemoryRevoke`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L237C32-L237C49) | `Is not safely published` |
| [`lookupSourceChecksum`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L235C26-L235C45) | `Is not safely published` |
| [`unspillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L232C52-L232C68) | `Is not safely published` |
| [`spillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L231C33-L231C47) | `Is not safely published` |
| [`spiller`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L230C43-L230C49) | `Is not safely published` |
| [`lookupSourceNotNeeded`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L228C43-L228C63) | `Is not safely published` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L227C19-L227C23) | `Is not safely published` |
| [`enforceBroadcastMemoryLimit`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L82C25-L82C51) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L81C25-L81C30) | `Is not safely published` |
| [`currentPosition`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/OuterLookupSource.java#L123C21-L123C35) | `Is not safely published` |
| [`finished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/OuterLookupSource.java#L181C25-L181C32) | `Is not safely published` |
| [`taskInstanceId`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L106C20-L106C33) | `Is not safely published` |
| [`completed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L104C21-L104C29) | `Is not safely published` |
| [`token`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L100C18-L100C22) | `Is not safely published` |
| [`lastUpdate`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L98C22-L98C31) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PageBufferClient.java#L94C21-L94C26) | `Is not safely published` |
| [`pendingReleases`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java#L129C21-L129C35) | `Is not safely published` |
| [`physicallyQueuedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L544C21-L544C43) | `Is not safely published` |
| [`blockedSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L536C22-L536C40) | `Is not safely published` |
| [`runningSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L535C22-L535C40) | `Is not safely published` |
| [`blockedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L534C21-L534C34) | `Is not safely published` |
| [`runningDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L533C21-L533C34) | `Is not safely published` |
| [`count`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ReferenceCount.java#L31C17-L31C21) | `Is not safely published` |
| [`finished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L128C21-L128C28) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L74C25-L74C30) | `Is not safely published` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L43C19-L43C23) | `Is not safely published` |
| [`lastTaskStatCallNanos`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java#L127C18-L127C38) | `Is not safely published` |
| [`lastTotalMemoryReservation`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java#L124C18-L124C43) | `Is not safely published` |
| [`lastUserMemoryReservation`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/TaskContext.java#L121C18-L121C42) | `Is not safely published` |
| [`nextSourceIndex`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L86C17-L86C31) | `Is not safely published` |
| [`noMoreSinkFactories`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L74C21-L74C39) | `Is not safely published` |
| [`allSourcesFinished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L71C21-L71C38) | `Is not safely published` |
| [`numSinkFactories`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L337C21-L337C36) | `Is not safely published` |
| [`noMoreSinkFactories`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L333C25-L333C43) | `Is not safely published` |
| [`finishing`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java#L51C30-L51C38) | `Is not safely published` |
| [`referenceCount`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/PageReference.java#L31C26-L31C39) | `Is not safely published` |
| [`pipelineContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java#L90C29-L90C43) | `Is not safely published` |
| [`indexSnapshotLoader`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java#L87C33-L87C51) | `Is not safely published` |
| [`finished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L74C21-L74C28) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L39C25-L39C30) | `Is not safely published` |
| [`nodeErrorMessage`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/RequestErrorTracker.java#L58C20-L58C35) | `Is not safely published` |
| [`errorCode`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/RequestErrorTracker.java#L57C31-L57C39) | `Is not safely published` |
| [`average`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java#L68C33-L68C39) | `Is not safely published` |
| [`count`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java#L66C31-L66C35) | `Is not safely published` |
| [`removedSessionFunctions`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L169C32-L169C54) | `Is not safely published` |
| [`addedSessionFunctions`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L166C52-L166C72) | `Is not safely published` |
| [`hasProducedResult`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L163C21-L163C37) | `Is not safely published` |
| [`updateCount`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L160C18-L160C28) | `Is not safely published` |
| [`clearTransactionId`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L157C21-L157C38) | `Is not safely published` |
| [`startedTransactionId`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L154C37-L154C56) | `Is not safely published` |
| [`deallocatedPreparedStatements`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L151C25-L151C53) | `Is not safely published` |
| [`addedPreparedStatements`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L148C33-L148C55) | `Is not safely published` |
| [`setRoles`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L145C39-L145C46) | `Is not safely published` |
| [`resetSessionProperties`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L142C25-L142C46) | `Is not safely published` |
| [`setSessionProperties`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L139C33-L139C52) | `Is not safely published` |
| [`setSchema`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L136C30-L136C38) | `Is not safely published` |
| [`setCatalog`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L133C30-L133C39) | `Is not safely published` |
| [`types`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L130C24-L130C28) | `Is not safely published` |
| [`columns`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L127C26-L127C32) | `Is not safely published` |
| [`lastToken`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L124C18-L124C26) | `Is not safely published` |
| [`lastResult`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L121C26-L121C35) | `Is not safely published` |
| [`nextToken`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/protocol/Query.java#L118C26-L118C34) | `Is not safely published` |
| [`lastRequestStart`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L54C18-L54C33) | `Is not safely published` |
| [`failureRequestTimeTotal`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L52C18-L52C40) | `Is not safely published` |
| [`failureCount`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L51C18-L51C29) | `Is not safely published` |
| [`lastFailureTime`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L50C18-L50C32) | `Is not safely published` |
| [`firstFailureTime`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/remotetask/Backoff.java#L49C18-L49C33) | `Is not safely published` |
| [`deleted`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/FileHolder.java#L38C21-L38C27) | `Is not safely published` |
| [`readingStarted`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/GenericPartitioningSpiller.java#L60C21-L60C34) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/LocalSpillContext.java#L29C21-L29C26) | `Is not safely published` |
| [`spilledBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/LocalSpillContext.java#L28C18-L28C29) | `Is not safely published` |
| [`currentBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/spiller/SpillSpaceTracker.java#L37C18-L37C29) | `Is not safely published` |
| [`predicate`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/sql/planner/LocalDynamicFiltersCollector.java#L30C54-L30C62) | `Is not safely published` |
| [`noMorePages`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/test/java/com/facebook/presto/execution/buffer/TestClientBuffer.java#L495C25-L495C35) | `Is not safely published` |
| [`currentBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L43C18-L43C29) | `Is not safely published` |
| [`rows`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L150C22-L150C25) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java#L42C21-L42C26) | `Is not safely published` |
| [`usedBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java#L40C18-L40C26) | `Is not safely published` |
| [`broadcastUsedBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/AbstractAggregatedMemoryContext.java#L38C18-L38C35) | `Is not safely published` |
| [`systemLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L55C32-L55C55) | `Is not safely published` |
| [`revocableLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L54C32-L54C58) | `Is not safely published` |
| [`userLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L53C32-L53C53) | `Is not safely published` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/SimpleLocalMemoryContext.java#L40C21-L40C26) | `Is not safely published` |
| [`usedBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/SimpleLocalMemoryContext.java#L38C18-L38C26) | `Is not safely published` |
| [`responseSize`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-pinot-toolkit/src/main/java/com/facebook/presto/pinot/PinotMetricsStats.java#L35C30-L35C41) | `Is not safely published` |