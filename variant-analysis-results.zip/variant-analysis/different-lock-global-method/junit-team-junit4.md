### junit-team/junit4

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L131C13-L131C54)

<pre><code class="java">        @Override
        public void testRunStarted(Description description) throws Exception {
            <strong>startTime.set(System.currentTimeMillis())</strong>;
        }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L131C27-L131C53)

<pre><code class="java">        @Override
        public void testRunStarted(Description description) throws Exception {
            startTime.set(<strong>System.currentTimeMillis()</strong>);
        }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L136C28-L136C54)

<pre><code class="java">        @Override
        public void testRunFinished(Result result) throws Exception {
            long endTime = <strong>System.currentTimeMillis()</strong>;
            runTime.addAndGet(endTime - startTime.get());
        }
</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L137C13-L137C57)

<pre><code class="java">        public void testRunFinished(Result result) throws Exception {
            long endTime = System.currentTimeMillis();
            <strong>runTime.addAndGet(endTime - startTime.get())</strong>;
        }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L137C41-L137C56)

<pre><code class="java">        public void testRunFinished(Result result) throws Exception {
            long endTime = System.currentTimeMillis();
            runTime.addAndGet(endTime - <strong>startTime.get()</strong>);
        }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L142C13-L142C36)

<pre><code class="java">        @Override
        public void testFinished(Description description) throws Exception {
            <strong>count.getAndIncrement()</strong>;
        }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L147C13-L147C34)

<pre><code class="java">        @Override
        public void testFailure(Failure failure) throws Exception {
            <strong>failures.add(failure)</strong>;
        }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L152C13-L152C42)

<pre><code class="java">        @Override
        public void testIgnored(Description description) throws Exception {
            <strong>ignoreCount.getAndIncrement()</strong>;
        }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/Result.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L157C13-L157C53)

<pre><code class="java">        @Override
        public void testAssumptionFailure(Failure failure) {
            <strong>assumptionFailureCount.getAndIncrement()</strong>;
        }
    }
</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/notification/SynchronizedRunListener.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L113C16-L113C35)

<pre><code class="java">    @Override
    public int hashCode() {
        return <strong>listener.hashCode()</strong>;
    }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/notification/SynchronizedRunListener.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L126C16-L126C46)

<pre><code class="java">        SynchronizedRunListener that = (SynchronizedRunListener) other;
        
        return <strong>listener.equals(that.listener)</strong>;
    }

</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

[src/main/java/org/junit/runner/notification/SynchronizedRunListener.java](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L131C16-L131C35)

<pre><code class="java">    @Override
    public String toString() {
        return <strong>listener.toString()</strong> + " (with synchronization wrapper)";
    }
}
</code></pre>

*An access of this method is on a different lock either in a synchronized statement or a lock type.*

----------------------------------------

| m |  |
| --- | --- |
| [`set(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L131C13-L131C53) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`currentTimeMillis(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L131C27-L131C52) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`currentTimeMillis(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L136C28-L136C53) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`addAndGet(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L137C13-L137C56) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`get(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L137C41-L137C55) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`getAndIncrement(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L142C13-L142C35) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`add(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L147C13-L147C33) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`getAndIncrement(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L152C13-L152C41) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`getAndIncrement(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L157C13-L157C52) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`hashCode(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L113C16-L113C34) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`equals(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L126C16-L126C45) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |
| [`toString(...)`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L131C16-L131C34) | `An access of this method is on a different lock either in a synchronized statement or a lock type.` |