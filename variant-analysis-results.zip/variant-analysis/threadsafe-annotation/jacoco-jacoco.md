### jacoco/jacoco

| c |
| --- |
| `StampedCommonCache` |