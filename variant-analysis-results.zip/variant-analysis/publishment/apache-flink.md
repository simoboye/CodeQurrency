### apache/flink

[flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L176C13-L176C21)

<pre><code class="java">    private static class Instance {
        final Object payload;
        int <strong>refcount</strong>;
        ScheduledFuture&lt;?&gt; destroyTask;

</code></pre>

*Is not safely published*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/BatchingStateChangeUploadScheduler.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/BatchingStateChangeUploadScheduler.java#L95C23-L95C34)

<pre><code class="java">    @Nullable
    @GuardedBy("this")
    private Throwable <strong>errorUnsafe</strong>;

    @GuardedBy("lock")
</code></pre>

*Is not safely published*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/BatchingStateChangeUploadScheduler.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/BatchingStateChangeUploadScheduler.java#L81C18-L81C39)

<pre><code class="java">
    @GuardedBy("lock")
    private long <strong>scheduledBytesCounter</strong>;

    private final AvailabilityHelper availabilityHelper;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/FsStateChangelogStorage.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/FsStateChangelogStorage.java#L72C46-L72C68)

<pre><code class="java">    private final TaskChangelogRegistry changelogRegistry;

    @Nullable private LocalChangelogRegistry <strong>localChangelogRegistry</strong> = LocalChangelogRegistry.NO_OP;

    /** The configuration for local recovery. */
</code></pre>

*Is not safely published*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L119C21-L119C27)

<pre><code class="java">    private final Set&lt;WrappedSdkHarnessClient&gt; evictedActiveClients;

    private boolean <strong>closed</strong>;

    public static DefaultJobBundleFactory create(JobInfo jobInfo) {
</code></pre>

*Is not safely published*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L446C41-L446C54)

<pre><code class="java">        private BundleProcessor processor;
        private ExecutableProcessBundleDescriptor processBundleDescriptor;
        private WrappedSdkHarnessClient <strong>wrappedClient</strong>;
    }

</code></pre>

*Is not safely published*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L445C51-L445C74)

<pre><code class="java">    private static class PreparedClient {
        private BundleProcessor processor;
        private ExecutableProcessBundleDescriptor <strong>processBundleDescriptor</strong>;
        private WrappedSdkHarnessClient wrappedClient;
    }
</code></pre>

*Is not safely published*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L444C33-L444C42)

<pre><code class="java">
    private static class PreparedClient {
        private BundleProcessor <strong>processor</strong>;
        private ExecutableProcessBundleDescriptor processBundleDescriptor;
        private WrappedSdkHarnessClient wrappedClient;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L488C41-L488C54)

<pre><code class="java">        private final IdentityHashMap&lt;WrappedSdkHarnessClient, PreparedClient&gt; preparedClients =
                new IdentityHashMap&lt;&gt;();
        private volatile PreparedClient <strong>currentClient</strong>;

        private SimpleStageBundleFactory(ExecutableStage executableStage) {
</code></pre>

*Is not safely published*

----------------------------------------

[flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L648C25-L648C31)

<pre><code class="java">        private final AtomicInteger bundleRefCount = new AtomicInteger();

        private boolean <strong>closed</strong>;

        static WrappedSdkHarnessClient wrapping(
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/checkpoint/CheckpointsCleaner.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/checkpoint/CheckpointsCleaner.java#L59C37-L59C50)

<pre><code class="java">    @GuardedBy("lock")
    @Nullable
    private CompletableFuture&lt;Void&gt; <strong>cleanUpFuture</strong>;

    /** All subsumed checkpoints. */
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/checkpoint/CheckpointsCleaner.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/checkpoint/CheckpointsCleaner.java#L55C17-L55C43)

<pre><code class="java">
    @GuardedBy("lock")
    private int <strong>numberOfCheckpointsToClean</strong>;

    @GuardedBy("lock")
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataManager.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataManager.java#L118C30-L118C40)

<pre><code class="java">    /** Whether this file data manager has been released or not. */
    @GuardedBy("lock")
    private volatile boolean <strong>isReleased</strong>;

    @GuardedBy("lock")
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataManager.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataManager.java#L114C26-L114C45)

<pre><code class="java">    /** Number of buffers already allocated and still not recycled by this partition reader. */
    @GuardedBy("lock")
    private volatile int <strong>numRequestedBuffers</strong>;

    /** Whether this file data manager has been released or not. */
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L80C29-L80C49)

<pre><code class="java">
    private AtomicLongArray receiveRatePerInterface;
    private AtomicLongArray <strong>sendRatePerInterface</strong>;

    public SystemResourcesCounter(Time probeInterval) {
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L79C29-L79C52)

<pre><code class="java">    private final String[] networkInterfaceNames;

    private AtomicLongArray <strong>receiveRatePerInterface</strong>;
    private AtomicLongArray sendRatePerInterface;

</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L75C42-L75C62)

<pre><code class="java">    private volatile double cpuLoad15;

    private AtomicReferenceArray&lt;Double&gt; <strong>cpuUsagePerProcessor</strong>;

    private final String[] networkInterfaceNames;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L73C29-L73C38)

<pre><code class="java">    private volatile double cpuLoad1;
    private volatile double cpuLoad5;
    private volatile double <strong>cpuLoad15</strong>;

    private AtomicReferenceArray&lt;Double&gt; cpuUsagePerProcessor;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L72C29-L72C37)

<pre><code class="java">
    private volatile double cpuLoad1;
    private volatile double <strong>cpuLoad5</strong>;
    private volatile double cpuLoad15;

</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L71C29-L71C37)

<pre><code class="java">    private volatile double cpuUsage;

    private volatile double <strong>cpuLoad1</strong>;
    private volatile double cpuLoad5;
    private volatile double cpuLoad15;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L69C29-L69C37)

<pre><code class="java">    private volatile double cpuSoftIrq;
    private volatile double cpuSteal;
    private volatile double <strong>cpuUsage</strong>;

    private volatile double cpuLoad1;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L68C29-L68C37)

<pre><code class="java">    private volatile double cpuIrq;
    private volatile double cpuSoftIrq;
    private volatile double <strong>cpuSteal</strong>;
    private volatile double cpuUsage;

</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L67C29-L67C39)

<pre><code class="java">    private volatile double cpuIOWait;
    private volatile double cpuIrq;
    private volatile double <strong>cpuSoftIrq</strong>;
    private volatile double cpuSteal;
    private volatile double cpuUsage;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L66C29-L66C35)

<pre><code class="java">    private volatile double cpuIdle;
    private volatile double cpuIOWait;
    private volatile double <strong>cpuIrq</strong>;
    private volatile double cpuSoftIrq;
    private volatile double cpuSteal;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L65C29-L65C38)

<pre><code class="java">    private volatile double cpuSys;
    private volatile double cpuIdle;
    private volatile double <strong>cpuIOWait</strong>;
    private volatile double cpuIrq;
    private volatile double cpuSoftIrq;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L64C29-L64C36)

<pre><code class="java">    private volatile double cpuNice;
    private volatile double cpuSys;
    private volatile double <strong>cpuIdle</strong>;
    private volatile double cpuIOWait;
    private volatile double cpuIrq;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L63C29-L63C35)

<pre><code class="java">    private volatile double cpuUser;
    private volatile double cpuNice;
    private volatile double <strong>cpuSys</strong>;
    private volatile double cpuIdle;
    private volatile double cpuIOWait;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L62C29-L62C36)

<pre><code class="java">
    private volatile double cpuUser;
    private volatile double <strong>cpuNice</strong>;
    private volatile double cpuSys;
    private volatile double cpuIdle;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L61C29-L61C36)

<pre><code class="java">    private long[] bytesSentPerInterface;

    private volatile double <strong>cpuUser</strong>;
    private volatile double cpuNice;
    private volatile double cpuSys;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L59C20-L59C41)

<pre><code class="java">    private long[][] previousProcCpuTicks;
    private long[] bytesReceivedPerInterface;
    private long[] <strong>bytesSentPerInterface</strong>;

    private volatile double cpuUser;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L58C20-L58C45)

<pre><code class="java">    private long[] previousCpuTicks;
    private long[][] previousProcCpuTicks;
    private long[] <strong>bytesReceivedPerInterface</strong>;
    private long[] bytesSentPerInterface;

</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L57C22-L57C42)

<pre><code class="java">
    private long[] previousCpuTicks;
    private long[][] <strong>previousProcCpuTicks</strong>;
    private long[] bytesReceivedPerInterface;
    private long[] bytesSentPerInterface;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L56C20-L56C36)

<pre><code class="java">    private volatile boolean running = true;

    private long[] <strong>previousCpuTicks</strong>;
    private long[][] previousProcCpuTicks;
    private long[] bytesReceivedPerInterface;
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/async/CompletedOperationCache.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/async/CompletedOperationCache.java#L75C22-L75C35)

<pre><code class="java">
    @Nullable private CompletableFuture&lt;Void&gt; terminationFuture;
    private Duration <strong>cacheDuration</strong>;

    public CompletedOperationCache(final Duration cacheDuration) {
</code></pre>

*Is not safely published*

----------------------------------------

[flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/async/CompletedOperationCache.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/async/CompletedOperationCache.java#L74C47-L74C64)

<pre><code class="java">    private final Object lock = new Object();

    @Nullable private CompletableFuture&lt;Void&gt; <strong>terminationFuture</strong>;
    private Duration cacheDuration;

</code></pre>

*Is not safely published*

----------------------------------------

[flink-streaming-java/src/main/java/org/apache/flink/streaming/runtime/tasks/mailbox/TaskMailboxImpl.java](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-streaming-java/src/main/java/org/apache/flink/streaming/runtime/tasks/mailbox/TaskMailboxImpl.java#L62C19-L62C24)

<pre><code class="java">    /** The state of the mailbox in the lifecycle of open, quiesced, and closed. */
    @GuardedBy("lock")
    private State <strong>state</strong> = OPEN;

    /** Reference to the thread that executes the mailbox mails. */
</code></pre>

*Is not safely published*

----------------------------------------

| f |  |
| --- | --- |
| `shutdownHook` | `Is not safely published` |
| [`refcount`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/vendor/grpc/v1p48p1/io/grpc/internal/SharedResourceHolder.java#L176C13-L176C20) | `Is not safely published` |
| [`errorUnsafe`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/BatchingStateChangeUploadScheduler.java#L95C23-L95C33) | `Is not safely published` |
| [`scheduledBytesCounter`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/BatchingStateChangeUploadScheduler.java#L81C18-L81C38) | `Is not safely published` |
| [`localChangelogRegistry`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-dstl/flink-dstl-dfs/src/main/java/org/apache/flink/changelog/fs/FsStateChangelogStorage.java#L72C46-L72C67) | `Is not safely published` |
| [`closed`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L119C21-L119C26) | `Is not safely published` |
| [`wrappedClient`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L446C41-L446C53) | `Is not safely published` |
| [`processBundleDescriptor`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L445C51-L445C73) | `Is not safely published` |
| [`processor`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L444C33-L444C41) | `Is not safely published` |
| [`currentClient`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L488C41-L488C53) | `Is not safely published` |
| [`closed`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-python/src/main/java/org/apache/beam/runners/fnexecution/control/DefaultJobBundleFactory.java#L648C25-L648C30) | `Is not safely published` |
| [`cleanUpFuture`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/checkpoint/CheckpointsCleaner.java#L59C37-L59C49) | `Is not safely published` |
| [`numberOfCheckpointsToClean`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/checkpoint/CheckpointsCleaner.java#L55C17-L55C42) | `Is not safely published` |
| [`isReleased`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataManager.java#L118C30-L118C39) | `Is not safely published` |
| [`numRequestedBuffers`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/io/network/partition/hybrid/HsFileDataManager.java#L114C26-L114C44) | `Is not safely published` |
| [`sendRatePerInterface`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L80C29-L80C48) | `Is not safely published` |
| [`receiveRatePerInterface`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L79C29-L79C51) | `Is not safely published` |
| [`cpuUsagePerProcessor`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L75C42-L75C61) | `Is not safely published` |
| [`cpuLoad15`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L73C29-L73C37) | `Is not safely published` |
| [`cpuLoad5`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L72C29-L72C36) | `Is not safely published` |
| [`cpuLoad1`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L71C29-L71C36) | `Is not safely published` |
| [`cpuUsage`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L69C29-L69C36) | `Is not safely published` |
| [`cpuSteal`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L68C29-L68C36) | `Is not safely published` |
| [`cpuSoftIrq`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L67C29-L67C38) | `Is not safely published` |
| [`cpuIrq`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L66C29-L66C34) | `Is not safely published` |
| [`cpuIOWait`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L65C29-L65C37) | `Is not safely published` |
| [`cpuIdle`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L64C29-L64C35) | `Is not safely published` |
| [`cpuSys`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L63C29-L63C34) | `Is not safely published` |
| [`cpuNice`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L62C29-L62C35) | `Is not safely published` |
| [`cpuUser`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L61C29-L61C35) | `Is not safely published` |
| [`bytesSentPerInterface`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L59C20-L59C40) | `Is not safely published` |
| [`bytesReceivedPerInterface`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L58C20-L58C44) | `Is not safely published` |
| [`previousProcCpuTicks`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L57C22-L57C41) | `Is not safely published` |
| [`previousCpuTicks`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/metrics/util/SystemResourcesCounter.java#L56C20-L56C35) | `Is not safely published` |
| [`cacheDuration`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/async/CompletedOperationCache.java#L75C22-L75C34) | `Is not safely published` |
| [`terminationFuture`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-runtime/src/main/java/org/apache/flink/runtime/rest/handler/async/CompletedOperationCache.java#L74C47-L74C63) | `Is not safely published` |
| [`state`](https://github.com/apache/flink/blob/34a7734c489b080d34ff2194a29d3c1d25d3ab45/flink-streaming-java/src/main/java/org/apache/flink/streaming/runtime/tasks/mailbox/TaskMailboxImpl.java#L62C19-L62C23) | `Is not safely published` |