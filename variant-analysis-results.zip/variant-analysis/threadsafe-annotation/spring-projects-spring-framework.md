### spring-projects/spring-framework

| c |
| --- |
| `StampedCommonCache` |
| `ModelType` |
| `ModelPath` |
| `ExecutionNodeAccessHierarchy` |
| `ModelReference` |
| `UnboundRule` |
| `UnboundRuleInput` |