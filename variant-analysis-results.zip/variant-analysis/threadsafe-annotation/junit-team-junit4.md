### junit-team/junit4

| c |
| --- |
| [`Listener`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/Result.java#L128C19-L128C26) |
| [`ThreadSafeListener`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/test/java/org/junit/runner/notification/RunNotifierTest.java#L128C26-L128C43) |
| [`SynchronizedRunListener`](https://github.com/junit-team/junit4/blob/28fa2cae48b365c949935b28967ffb3f388e77ef/src/main/java/org/junit/runner/notification/SynchronizedRunListener.java#L23C13-L23C35) |