### grpc/grpc-java

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L195C9-L195C83)

<pre><code class="java">       */
      public Builder setCallOptions(CallOptions callOptions) {
        <strong>this.callOptions = checkNotNull(callOptions, "callOptions cannot be null")</strong>;
        return this;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L205C9-L205C49)

<pre><code class="java">       */
      public Builder setPreviousAttempts(int previousAttempts) {
        <strong>this.previousAttempts = previousAttempts</strong>;
        return this;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L215C9-L215C53)

<pre><code class="java">       */
      public Builder setIsTransparentRetry(boolean isTransparentRetry) {
        <strong>this.isTransparentRetry = isTransparentRetry</strong>;
        return this;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L223C31-L223C42)

<pre><code class="java">       */
      public StreamInfo build() {
        return new StreamInfo(<strong>callOptions</strong>, previousAttempts, isTransparentRetry);
      }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L223C44-L223C60)

<pre><code class="java">       */
      public StreamInfo build() {
        return new StreamInfo(callOptions, <strong>previousAttempts</strong>, isTransparentRetry);
      }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L223C62-L223C80)

<pre><code class="java">       */
      public StreamInfo build() {
        return new StreamInfo(callOptions, previousAttempts, <strong>isTransparentRetry</strong>);
      }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L211C12-L211C23)

<pre><code class="java">      // but before the runnable is actually run.  We must guarantee that the task will not be run
      // in this case.
      if (!<strong>isCancelled</strong>) {
        hasStarted = true;
        task.run();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L212C9-L212C26)

<pre><code class="java">      // in this case.
      if (!isCancelled) {
        <strong>hasStarted = true</strong>;
        task.run();
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L237C7-L237C34)

<pre><code class="java">     */
    public void cancel() {
      <strong>runnable.isCancelled = true</strong>;
      future.cancel(false);
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L246C16-L246C35)

<pre><code class="java">     */
    public boolean isPending() {
      return !(<strong>runnable.hasStarted</strong> || runnable.isCancelled);
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L246C39-L246C59)

<pre><code class="java">     */
    public boolean isPending() {
      return !(runnable.hasStarted || <strong>runnable.isCancelled</strong>);
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L273C12-L273C31)

<pre><code class="java">  @GuardedBy("this")
  boolean inState(TransportState transportState) {
    return <strong>this.transportState</strong> == transportState;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L283C21-L283C35)

<pre><code class="java">  @GuardedBy("this")
  final void setState(TransportState newState) {
    checkTransition(<strong>transportState</strong>, newState);
    transportState = newState;
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L284C5-L284C30)

<pre><code class="java">  final void setState(TransportState newState) {
    checkTransition(transportState, newState);
    <strong>transportState = newState</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L290C5-L290C33)

<pre><code class="java">  protected boolean setOutgoingBinder(OneWayBinderProxy binder) {
    binder = binderDecorator.decorate(binder);
    <strong>this.outgoingBinder = binder</strong>;
    try {
      binder.getDelegate().linkToDeath(this, 0);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L307C7-L307C43)

<pre><code class="java">  final void shutdownInternal(Status shutdownStatus, boolean forceTerminate) {
    if (!isShutdown()) {
      <strong>this.shutdownStatus = shutdownStatus</strong>;
      setState(TransportState.SHUTDOWN);
      notifyShutdown(shutdownStatus);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L333C39-L333C53)

<pre><code class="java">  @GuardedBy("this")
  final void sendSetupTransaction() {
    sendSetupTransaction(checkNotNull(<strong>outgoingBinder</strong>));
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L349C9-L349C23)

<pre><code class="java">  @GuardedBy("this")
  private final void sendShutdownTransaction() {
    if (<strong>outgoingBinder</strong> != null) {
      try {
        outgoingBinder.getDelegate().unlinkToDeath(this, 0);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L351C9-L351C23)

<pre><code class="java">    if (outgoingBinder != null) {
      try {
        <strong>outgoingBinder</strong>.getDelegate().unlinkToDeath(this, 0);
      } catch (NoSuchElementException e) {
        // Ignore.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L358C9-L358C23)

<pre><code class="java">        // Send empty flags to avoid a memory leak linked to empty parcels (b/207778694).
        parcel.get().writeInt(0);
        <strong>outgoingBinder</strong>.transact(SHUTDOWN_TRANSPORT, parcel);
      } catch (RemoteException re) {
        // Ignore.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L403C7-L403C21)

<pre><code class="java">    int dataSize = parcel.get().dataSize();
    try {
      <strong>outgoingBinder</strong>.transact(callId, parcel);
    } catch (RemoteException re) {
      throw statusFromRemoteException(re).asException();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L484C18-L484C43)

<pre><code class="java">      }
      long nib = numIncomingBytes.addAndGet(size);
      if ((nib - <strong>acknowledgedIncomingBytes</strong>) &gt; TRANSACTION_BYTES_WINDOW_FORCE_ACK) {
        synchronized (this) {
          sendAcknowledgeBytes(checkNotNull(outgoingBinder));
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L505C9-L505C23)

<pre><code class="java">  private final void handlePing(Parcel requestParcel) {
    int id = requestParcel.readInt();
    if (<strong>transportState</strong> == TransportState.READY) {
      try (ParcelHolder replyParcel = ParcelHolder.obtain()) {
        replyParcel.get().writeInt(id);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L508C9-L508C23)

<pre><code class="java">      try (ParcelHolder replyParcel = ParcelHolder.obtain()) {
        replyParcel.get().writeInt(id);
        <strong>outgoingBinder</strong>.transact(PING_RESPONSE, replyParcel);
      } catch (RemoteException re) {
        // Ignore.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L522C5-L522C34)

<pre><code class="java">    // Send a transaction to acknowledge reception of incoming data.
    long n = numIncomingBytes.get();
    <strong>acknowledgedIncomingBytes = n</strong>;
    try (ParcelHolder parcel = ParcelHolder.obtain()) {
      parcel.get().writeLong(n);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L690C9-L690C32)

<pre><code class="java">    protected void unregisterInbound(Inbound&lt;?&gt; inbound) {
      if (inbound.countsForInUse() &amp;&amp; numInUseStreams.decrementAndGet() == 0) {
        <strong>clientTransportListener</strong>.transportInUse(false);
      }
      super.unregisterInbound(inbound);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L715C7-L715C30)

<pre><code class="java">    @GuardedBy("this")
    public void notifyShutdown(Status status) {
      <strong>clientTransportListener</strong>.transportShutdown(status);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L722C9-L722C32)

<pre><code class="java">    public void notifyTerminated() {
      if (numInUseStreams.getAndSet(0) &gt; 0) {
        <strong>clientTransportListener</strong>.transportInUse(false);
      }
      serviceBinding.unbind();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L725C7-L725C30)

<pre><code class="java">      }
      serviceBinding.unbind();
      <strong>clientTransportListener</strong>.transportTerminated();
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L732C7-L732C72)

<pre><code class="java">    protected void handleSetupTransport(Parcel parcel) {
      // Add the remote uid to our attributes.
      <strong>attributes = setSecurityAttrs(attributes, Binder.getCallingUid())</strong>;
      if (inState(TransportState.SETUP)) {
        int version = parcel.readInt();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L732C37-L732C47)

<pre><code class="java">    protected void handleSetupTransport(Parcel parcel) {
      // Add the remote uid to our attributes.
      attributes = setSecurityAttrs(<strong>attributes</strong>, Binder.getCallingUid());
      if (inState(TransportState.SETUP)) {
        int version = parcel.readInt();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L890C11-L890C34)

<pre><code class="java">    @GuardedBy("this")
    public void notifyTerminated() {
      if (<strong>serverTransportListener</strong> != null) {
        serverTransportListener.transportTerminated();
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L891C9-L891C32)

<pre><code class="java">    public void notifyTerminated() {
      if (serverTransportListener != null) {
        <strong>serverTransportListener</strong>.transportTerminated();
      }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L909C46-L909C56)

<pre><code class="java">    @GuardedBy("this")
    protected Inbound&lt;?&gt; createInbound(int callId) {
      return new Inbound.ServerInbound(this, <strong>attributes</strong>, callId);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L125C9-L125C22)

<pre><code class="java">  @MainThread
  private void notifyBound(IBinder binder) {
    if (<strong>reportedState</strong> == State.NOT_BINDING) {
      reportedState = State.BOUND;
      logger.log(Level.FINEST, "notify bound - notifying");
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L126C7-L126C34)

<pre><code class="java">  private void notifyBound(IBinder binder) {
    if (reportedState == State.NOT_BINDING) {
      <strong>reportedState = State.BOUND</strong>;
      logger.log(Level.FINEST, "notify bound - notifying");
      observer.onBound(binder);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L136C9-L136C22)

<pre><code class="java">    logger.log(Level.FINEST, "notify unbound ", reason);
    clearReferences();
    if (<strong>reportedState</strong> != State.UNBOUND) {
      reportedState = State.UNBOUND;
      logger.log(Level.FINEST, "notify unbound - notifying");
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L137C7-L137C36)

<pre><code class="java">    clearReferences();
    if (reportedState != State.UNBOUND) {
      <strong>reportedState = State.UNBOUND</strong>;
      logger.log(Level.FINEST, "notify unbound - notifying");
      observer.onUnbound(reason);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L255C5-L255C25)

<pre><code class="java">  @MainThread
  private void clearReferences() {
    <strong>sourceContext = null</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L196C38-L196C53)

<pre><code class="java">  @Override
  public ClientTransport obtainActiveTransport() {
    ClientTransport savedTransport = <strong>activeTransport</strong>;
    if (savedTransport != null) {
      return savedTransport;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L203C13-L203C18)

<pre><code class="java">      @Override
      public void run() {
        if (<strong>state</strong>.getState() == IDLE) {
          channelLogger.log(ChannelLogLevel.INFO, "CONNECTING as requested");
          gotoNonErrorState(CONNECTING);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L218C12-L218C27)

<pre><code class="java">  @Nullable
  ClientTransport getTransport() {
    return <strong>activeTransport</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L231C30-L231C43)

<pre><code class="java">    syncContext.throwIfNotInThisSynchronizationContext();

    Preconditions.checkState(<strong>reconnectTask</strong> == null, "Should have no reconnectTask scheduled");

    if (addressIndex.isAtBeginning()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L255C5-L255C39)

<pre><code class="java">    TransportLogger transportLogger = new TransportLogger();
    // In case the transport logs in the constructor, use the subchannel logId
    <strong>transportLogger.logId = getLogId()</strong>;
    ConnectionClientTransport transport =
        new CallTracingTransport(
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L260C5-L260C49)

<pre><code class="java">            transportFactory
                .newClientTransport(address, options, transportLogger), callsTracer);
    <strong>transportLogger.logId = transport.getLogId()</strong>;
    channelz.addClientSocket(transport);
    pendingTransport = transport;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L262C5-L262C33)

<pre><code class="java">    transportLogger.logId = transport.getLogId();
    channelz.addClientSocket(transport);
    <strong>pendingTransport = transport</strong>;
    transports.add(transport);
    Runnable runnable = transport.start(new TransportListener(transport));
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L268C70-L268C91)

<pre><code class="java">      syncContext.executeLater(runnable);
    }
    channelLogger.log(ChannelLogLevel.INFO, "Started transport {0}", <strong>transportLogger.logId</strong>);
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L294C9-L294C24)

<pre><code class="java">    }
    long delayNanos =
        <strong>reconnectPolicy</strong>.nextBackoffNanos() - connectingTimer.elapsed(TimeUnit.NANOSECONDS);
    channelLogger.log(
        ChannelLogLevel.INFO,
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L282C9-L282C29)

<pre><code class="java">      @Override
      public void run() {
        <strong>reconnectTask = null</strong>;
        channelLogger.log(ChannelLogLevel.INFO, "CONNECTING after backoff");
        gotoNonErrorState(CONNECTING);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L290C9-L290C24)

<pre><code class="java">
    gotoState(ConnectivityStateInfo.forTransientFailure(status));
    if (<strong>reconnectPolicy</strong> == null) {
      reconnectPolicy = backoffPolicyProvider.get();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L291C7-L291C52)

<pre><code class="java">    gotoState(ConnectivityStateInfo.forTransientFailure(status));
    if (reconnectPolicy == null) {
      <strong>reconnectPolicy = backoffPolicyProvider.get()</strong>;
    }
    long delayNanos =
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L299C30-L299C43)

<pre><code class="java">        "TRANSIENT_FAILURE ({0}). Will reconnect after {1} ns",
        printShortStatus(status), delayNanos);
    Preconditions.checkState(<strong>reconnectTask</strong> == null, "previous reconnectTask is not done");
    reconnectTask = syncContext.schedule(
        new EndOfCurrentBackoff(),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L300C5-L304C27)

<pre><code class="java">        printShortStatus(status), delayNanos);
    Preconditions.checkState(reconnectTask == null, "previous reconnectTask is not done");
    <strong>reconnectTask = syncContext.schedule(</strong>
<strong>        new EndOfCurrentBackoff(),</strong>
<strong>        delayNanos,</strong>
<strong>        TimeUnit.NANOSECONDS,</strong>
<strong>        scheduledExecutor)</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L315C13-L315C18)

<pre><code class="java">      @Override
      public void run() {
        if (<strong>state</strong>.getState() != TRANSIENT_FAILURE) {
          return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L335C9-L335C14)

<pre><code class="java">    syncContext.throwIfNotInThisSynchronizationContext();

    if (<strong>state</strong>.getState() != newState.getState()) {
      Preconditions.checkState(state.getState() != SHUTDOWN,
          "Cannot transition out of SHUTDOWN to " + newState);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L336C32-L336C37)

<pre><code class="java">
    if (state.getState() != newState.getState()) {
      Preconditions.checkState(<strong>state</strong>.getState() != SHUTDOWN,
          "Cannot transition out of SHUTDOWN to " + newState);
      state = newState;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L338C7-L338C23)

<pre><code class="java">      Preconditions.checkState(state.getState() != SHUTDOWN,
          "Cannot transition out of SHUTDOWN to " + newState);
      <strong>state = newState</strong>;
      callback.onStateChange(InternalSubchannel.this, newState);
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L357C9-L357C50)

<pre><code class="java">        SocketAddress previousAddress = addressIndex.getCurrentAddress();
        addressIndex.updateGroups(newImmutableAddressGroups);
        <strong>addressGroups = newImmutableAddressGroups</strong>;
        if (state.getState() == READY || state.getState() == CONNECTING) {
          if (!addressIndex.seekTo(previousAddress)) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L358C13-L358C18)

<pre><code class="java">        addressIndex.updateGroups(newImmutableAddressGroups);
        addressGroups = newImmutableAddressGroups;
        if (<strong>state</strong>.getState() == READY || state.getState() == CONNECTING) {
          if (!addressIndex.seekTo(previousAddress)) {
            // Forced to drop the connection
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L358C42-L358C47)

<pre><code class="java">        addressIndex.updateGroups(newImmutableAddressGroups);
        addressGroups = newImmutableAddressGroups;
        if (state.getState() == READY || <strong>state</strong>.getState() == CONNECTING) {
          if (!addressIndex.seekTo(previousAddress)) {
            // Forced to drop the connection
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L361C17-L361C22)

<pre><code class="java">          if (!addressIndex.seekTo(previousAddress)) {
            // Forced to drop the connection
            if (<strong>state</strong>.getState() == READY) {
              savedTransport = activeTransport;
              activeTransport = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L362C32-L362C47)

<pre><code class="java">            // Forced to drop the connection
            if (state.getState() == READY) {
              savedTransport = <strong>activeTransport</strong>;
              activeTransport = null;
              addressIndex.reset();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L363C15-L363C37)

<pre><code class="java">            if (state.getState() == READY) {
              savedTransport = activeTransport;
              <strong>activeTransport = null</strong>;
              addressIndex.reset();
              gotoNonErrorState(IDLE);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L367C15-L367C31)

<pre><code class="java">              gotoNonErrorState(IDLE);
            } else {
              <strong>pendingTransport</strong>.shutdown(
                  Status.UNAVAILABLE.withDescription(
                    "InternalSubchannel closed pending transport due to address change"));
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L370C15-L370C38)

<pre><code class="java">                  Status.UNAVAILABLE.withDescription(
                    "InternalSubchannel closed pending transport due to address change"));
              <strong>pendingTransport = null</strong>;
              addressIndex.reset();
              startNewTransport();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L377C15-L377C38)

<pre><code class="java">        }
        if (savedTransport != null) {
          if (<strong>shutdownDueToUpdateTask</strong> != null) {
            // Keeping track of multiple shutdown tasks adds complexity, and shouldn't generally be
            // necessary. This transport has probably already had plenty of time.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L380C13-L380C41)

<pre><code class="java">            // Keeping track of multiple shutdown tasks adds complexity, and shouldn't generally be
            // necessary. This transport has probably already had plenty of time.
            <strong>shutdownDueToUpdateTransport</strong>.shutdown(
                Status.UNAVAILABLE.withDescription(
                    "InternalSubchannel closed transport early due to address change"));
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L383C13-L383C36)

<pre><code class="java">                Status.UNAVAILABLE.withDescription(
                    "InternalSubchannel closed transport early due to address change"));
            <strong>shutdownDueToUpdateTask</strong>.cancel();
            shutdownDueToUpdateTask = null;
            shutdownDueToUpdateTransport = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L384C13-L384C43)

<pre><code class="java">                    "InternalSubchannel closed transport early due to address change"));
            shutdownDueToUpdateTask.cancel();
            <strong>shutdownDueToUpdateTask = null</strong>;
            shutdownDueToUpdateTransport = null;
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L385C13-L385C48)

<pre><code class="java">            shutdownDueToUpdateTask.cancel();
            shutdownDueToUpdateTask = null;
            <strong>shutdownDueToUpdateTransport = null</strong>;
          }
          // Avoid needless RPC failures by delaying the shutdown. See
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L389C11-L389C56)

<pre><code class="java">          // Avoid needless RPC failures by delaying the shutdown. See
          // https://github.com/grpc/grpc-java/issues/2562
          <strong>shutdownDueToUpdateTransport = savedTransport</strong>;
          shutdownDueToUpdateTask = syncContext.schedule(
              new Runnable() {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L390C11-L403C33)

<pre><code class="java">          // https://github.com/grpc/grpc-java/issues/2562
          shutdownDueToUpdateTransport = savedTransport;
          <strong>shutdownDueToUpdateTask = syncContext.schedule(</strong>
<strong>              new Runnable() {</strong>
<strong>                @Override public void run() {</strong>
<strong>                  ManagedClientTransport transport = shutdownDueToUpdateTransport;</strong>
<strong>                  shutdownDueToUpdateTask = null;</strong>
<strong>                  shutdownDueToUpdateTransport = null;</strong>
<strong>                  transport.shutdown(</strong>
<strong>                      Status.UNAVAILABLE.withDescription(</strong>
<strong>                          "InternalSubchannel closed transport due to address change"));</strong>
<strong>                }</strong>
<strong>              },</strong>
<strong>              ManagedChannelImpl.SUBCHANNEL_SHUTDOWN_DELAY_SECONDS,</strong>
<strong>              TimeUnit.SECONDS,</strong>
<strong>              scheduledExecutor)</strong>;
        }
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L393C54-L393C82)

<pre><code class="java">              new Runnable() {
                @Override public void run() {
                  ManagedClientTransport transport = <strong>shutdownDueToUpdateTransport</strong>;
                  shutdownDueToUpdateTask = null;
                  shutdownDueToUpdateTransport = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L394C19-L394C49)

<pre><code class="java">                @Override public void run() {
                  ManagedClientTransport transport = shutdownDueToUpdateTransport;
                  <strong>shutdownDueToUpdateTask = null</strong>;
                  shutdownDueToUpdateTransport = null;
                  transport.shutdown(
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L395C19-L395C54)

<pre><code class="java">                  ManagedClientTransport transport = shutdownDueToUpdateTransport;
                  shutdownDueToUpdateTask = null;
                  <strong>shutdownDueToUpdateTransport = null</strong>;
                  transport.shutdown(
                      Status.UNAVAILABLE.withDescription(
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L415C13-L415C18)

<pre><code class="java">        ManagedClientTransport savedActiveTransport;
        ConnectionClientTransport savedPendingTransport;
        if (<strong>state</strong>.getState() == SHUTDOWN) {
          return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L418C9-L418C32)

<pre><code class="java">          return;
        }
        <strong>shutdownReason = reason</strong>;
        savedActiveTransport = activeTransport;
        savedPendingTransport = pendingTransport;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L419C32-L419C47)

<pre><code class="java">        }
        shutdownReason = reason;
        savedActiveTransport = <strong>activeTransport</strong>;
        savedPendingTransport = pendingTransport;
        activeTransport = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L420C33-L420C49)

<pre><code class="java">        shutdownReason = reason;
        savedActiveTransport = activeTransport;
        savedPendingTransport = <strong>pendingTransport</strong>;
        activeTransport = null;
        pendingTransport = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L421C9-L421C31)

<pre><code class="java">        savedActiveTransport = activeTransport;
        savedPendingTransport = pendingTransport;
        <strong>activeTransport = null</strong>;
        pendingTransport = null;
        gotoNonErrorState(SHUTDOWN);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L422C9-L422C32)

<pre><code class="java">        savedPendingTransport = pendingTransport;
        activeTransport = null;
        <strong>pendingTransport = null</strong>;
        gotoNonErrorState(SHUTDOWN);
        addressIndex.reset();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L429C13-L429C36)

<pre><code class="java">        }  // else: the callback will be run once all transports have been terminated
        cancelReconnectTask();
        if (<strong>shutdownDueToUpdateTask</strong> != null) {
          shutdownDueToUpdateTask.cancel();
          shutdownDueToUpdateTransport.shutdown(reason);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L430C11-L430C34)

<pre><code class="java">        cancelReconnectTask();
        if (shutdownDueToUpdateTask != null) {
          <strong>shutdownDueToUpdateTask</strong>.cancel();
          shutdownDueToUpdateTransport.shutdown(reason);
          shutdownDueToUpdateTask = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L431C11-L431C39)

<pre><code class="java">        if (shutdownDueToUpdateTask != null) {
          shutdownDueToUpdateTask.cancel();
          <strong>shutdownDueToUpdateTransport</strong>.shutdown(reason);
          shutdownDueToUpdateTask = null;
          shutdownDueToUpdateTransport = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L432C11-L432C41)

<pre><code class="java">          shutdownDueToUpdateTask.cancel();
          shutdownDueToUpdateTransport.shutdown(reason);
          <strong>shutdownDueToUpdateTask = null</strong>;
          shutdownDueToUpdateTransport = null;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L433C11-L433C46)

<pre><code class="java">          shutdownDueToUpdateTransport.shutdown(reason);
          shutdownDueToUpdateTask = null;
          <strong>shutdownDueToUpdateTransport = null</strong>;
        }
        if (savedActiveTransport != null) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L451C31-L451C44)

<pre><code class="java">    return MoreObjects.toStringHelper(this)
        .add("logId", logId.getId())
        .add("addressGroups", <strong>addressGroups</strong>)
        .toString();
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L491C12-L491C25)

<pre><code class="java">
  List&lt;EquivalentAddressGroup&gt; getAddressGroups() {
    return <strong>addressGroups</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L497C9-L497C22)

<pre><code class="java">    syncContext.throwIfNotInThisSynchronizationContext();

    if (<strong>reconnectTask</strong> != null) {
      reconnectTask.cancel();
      reconnectTask = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L498C7-L498C20)

<pre><code class="java">
    if (reconnectTask != null) {
      <strong>reconnectTask</strong>.cancel();
      reconnectTask = null;
      reconnectPolicy = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L499C7-L499C27)

<pre><code class="java">    if (reconnectTask != null) {
      reconnectTask.cancel();
      <strong>reconnectTask = null</strong>;
      reconnectPolicy = null;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L500C7-L500C29)

<pre><code class="java">      reconnectTask.cancel();
      reconnectTask = null;
      <strong>reconnectPolicy = null</strong>;
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L529C12-L529C17)

<pre><code class="java">
  ConnectivityState getState() {
    return <strong>state</strong>.getState();
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L562C11-L562C33)

<pre><code class="java">        @Override
        public void run() {
          <strong>reconnectPolicy = null</strong>;
          if (shutdownReason != null) {
            // activeTransport should have already been set to null by shutdown(). We keep it null.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L563C15-L563C29)

<pre><code class="java">        public void run() {
          reconnectPolicy = null;
          if (<strong>shutdownReason</strong> != null) {
            // activeTransport should have already been set to null by shutdown(). We keep it null.
            Preconditions.checkState(activeTransport == null,
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L565C38-L565C53)

<pre><code class="java">          if (shutdownReason != null) {
            // activeTransport should have already been set to null by shutdown(). We keep it null.
            Preconditions.checkState(<strong>activeTransport</strong> == null,
                "Unexpected non-null activeTransport");
            transport.shutdown(shutdownReason);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L567C32-L567C46)

<pre><code class="java">            Preconditions.checkState(activeTransport == null,
                "Unexpected non-null activeTransport");
            transport.shutdown(<strong>shutdownReason</strong>);
          } else if (pendingTransport == transport) {
            activeTransport = transport;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L568C22-L568C38)

<pre><code class="java">                "Unexpected non-null activeTransport");
            transport.shutdown(shutdownReason);
          } else if (<strong>pendingTransport</strong> == transport) {
            activeTransport = transport;
            pendingTransport = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L569C13-L569C40)

<pre><code class="java">            transport.shutdown(shutdownReason);
          } else if (pendingTransport == transport) {
            <strong>activeTransport = transport</strong>;
            pendingTransport = null;
            gotoNonErrorState(READY);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L570C13-L570C36)

<pre><code class="java">          } else if (pendingTransport == transport) {
            activeTransport = transport;
            <strong>pendingTransport = null</strong>;
            gotoNonErrorState(READY);
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L586C7-L586C31)

<pre><code class="java">      channelLogger.log(
          ChannelLogLevel.INFO, "{0} SHUTDOWN with {1}", transport.getLogId(), printShortStatus(s));
      <strong>shutdownInitiated = true</strong>;
      syncContext.execute(new Runnable() {
        @Override
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L590C15-L590C20)

<pre><code class="java">        @Override
        public void run() {
          if (<strong>state</strong>.getState() == SHUTDOWN) {
            return;
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L593C15-L593C30)

<pre><code class="java">            return;
          }
          if (<strong>activeTransport</strong> == transport) {
            activeTransport = null;
            addressIndex.reset();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L594C13-L594C35)

<pre><code class="java">          }
          if (activeTransport == transport) {
            <strong>activeTransport = null</strong>;
            addressIndex.reset();
            gotoNonErrorState(IDLE);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L597C22-L597C38)

<pre><code class="java">            addressIndex.reset();
            gotoNonErrorState(IDLE);
          } else if (<strong>pendingTransport</strong> == transport) {
            Preconditions.checkState(state.getState() == CONNECTING,
                "Expected state is CONNECTING, actual state is %s", state.getState());
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L598C38-L598C43)

<pre><code class="java">            gotoNonErrorState(IDLE);
          } else if (pendingTransport == transport) {
            Preconditions.checkState(<strong>state</strong>.getState() == CONNECTING,
                "Expected state is CONNECTING, actual state is %s", state.getState());
            addressIndex.increment();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L599C69-L599C74)

<pre><code class="java">          } else if (pendingTransport == transport) {
            Preconditions.checkState(state.getState() == CONNECTING,
                "Expected state is CONNECTING, actual state is %s", <strong>state</strong>.getState());
            addressIndex.increment();
            // Continue reconnect if there are still addresses to try.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L603C15-L603C38)

<pre><code class="java">            // Continue reconnect if there are still addresses to try.
            if (!addressIndex.isValid()) {
              <strong>pendingTransport = null</strong>;
              addressIndex.reset();
              // Initiate backoff
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L619C11-L619C28)

<pre><code class="java">    public void transportTerminated() {
      Preconditions.checkState(
          <strong>shutdownInitiated</strong>, "transportShutdown() must be called before transportTerminated().");

      channelLogger.log(ChannelLogLevel.INFO, "{0} Terminated", transport.getLogId());
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L631C15-L631C20)

<pre><code class="java">        public void run() {
          transports.remove(transport);
          if (<strong>state</strong>.getState() == SHUTDOWN &amp;&amp; transports.isEmpty()) {
            handleTermination();
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L729C14-L729C24)

<pre><code class="java">    public boolean isValid() {
      // addressIndex will never be invalid
      return <strong>groupIndex</strong> &lt; addressGroups.size();
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L729C27-L729C40)

<pre><code class="java">    public boolean isValid() {
      // addressIndex will never be invalid
      return groupIndex &lt; <strong>addressGroups</strong>.size();
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L733C14-L733C24)

<pre><code class="java">
    public boolean isAtBeginning() {
      return <strong>groupIndex</strong> == 0 &amp;&amp; addressIndex == 0;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L733C33-L733C45)

<pre><code class="java">
    public boolean isAtBeginning() {
      return groupIndex == 0 &amp;&amp; <strong>addressIndex</strong> == 0;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L737C38-L737C51)

<pre><code class="java">
    public void increment() {
      EquivalentAddressGroup group = <strong>addressGroups</strong>.get(groupIndex);
      addressIndex++;
      if (addressIndex &gt;= group.getAddresses().size()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L737C56-L737C66)

<pre><code class="java">
    public void increment() {
      EquivalentAddressGroup group = addressGroups.get(<strong>groupIndex</strong>);
      addressIndex++;
      if (addressIndex &gt;= group.getAddresses().size()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L738C7-L738C21)

<pre><code class="java">    public void increment() {
      EquivalentAddressGroup group = addressGroups.get(groupIndex);
      <strong>addressIndex++</strong>;
      if (addressIndex &gt;= group.getAddresses().size()) {
        groupIndex++;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L738C7-L738C19)

<pre><code class="java">    public void increment() {
      EquivalentAddressGroup group = addressGroups.get(groupIndex);
      <strong>addressIndex</strong>++;
      if (addressIndex &gt;= group.getAddresses().size()) {
        groupIndex++;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L739C11-L739C23)

<pre><code class="java">      EquivalentAddressGroup group = addressGroups.get(groupIndex);
      addressIndex++;
      if (<strong>addressIndex</strong> &gt;= group.getAddresses().size()) {
        groupIndex++;
        addressIndex = 0;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L740C9-L740C21)

<pre><code class="java">      addressIndex++;
      if (addressIndex &gt;= group.getAddresses().size()) {
        <strong>groupIndex++</strong>;
        addressIndex = 0;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L740C9-L740C19)

<pre><code class="java">      addressIndex++;
      if (addressIndex &gt;= group.getAddresses().size()) {
        <strong>groupIndex</strong>++;
        addressIndex = 0;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L741C9-L741C25)

<pre><code class="java">      if (addressIndex &gt;= group.getAddresses().size()) {
        groupIndex++;
        <strong>addressIndex = 0</strong>;
      }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L746C7-L746C21)

<pre><code class="java">
    public void reset() {
      <strong>groupIndex = 0</strong>;
      addressIndex = 0;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L747C7-L747C23)

<pre><code class="java">    public void reset() {
      groupIndex = 0;
      <strong>addressIndex = 0</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L751C63-L751C75)

<pre><code class="java">
    public SocketAddress getCurrentAddress() {
      return addressGroups.get(groupIndex).getAddresses().get(<strong>addressIndex</strong>);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L751C14-L751C27)

<pre><code class="java">
    public SocketAddress getCurrentAddress() {
      return <strong>addressGroups</strong>.get(groupIndex).getAddresses().get(addressIndex);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L751C32-L751C42)

<pre><code class="java">
    public SocketAddress getCurrentAddress() {
      return addressGroups.get(<strong>groupIndex</strong>).getAddresses().get(addressIndex);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L755C14-L755C27)

<pre><code class="java">
    public Attributes getCurrentEagAttributes() {
      return <strong>addressGroups</strong>.get(groupIndex).getAttributes();
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L755C32-L755C42)

<pre><code class="java">
    public Attributes getCurrentEagAttributes() {
      return addressGroups.get(<strong>groupIndex</strong>).getAttributes();
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L759C14-L759C27)

<pre><code class="java">
    public List&lt;EquivalentAddressGroup&gt; getGroups() {
      return <strong>addressGroups</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L764C7-L764C32)

<pre><code class="java">    /** Update to new groups, resetting the current index. */
    public void updateGroups(List&lt;EquivalentAddressGroup&gt; newGroups) {
      <strong>addressGroups = newGroups</strong>;
      reset();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L770C27-L770C40)

<pre><code class="java">    /** Returns false if the needle was not found and the current index was left unchanged. */
    public boolean seekTo(SocketAddress needle) {
      for (int i = 0; i &lt; <strong>addressGroups</strong>.size(); i++) {
        EquivalentAddressGroup group = addressGroups.get(i);
        int j = group.getAddresses().indexOf(needle);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L771C40-L771C53)

<pre><code class="java">    public boolean seekTo(SocketAddress needle) {
      for (int i = 0; i &lt; addressGroups.size(); i++) {
        EquivalentAddressGroup group = <strong>addressGroups</strong>.get(i);
        int j = group.getAddresses().indexOf(needle);
        if (j == -1) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L776C9-L776C28)

<pre><code class="java">          continue;
        }
        <strong>this.groupIndex = i</strong>;
        this.addressIndex = j;
        return true;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L777C9-L777C30)

<pre><code class="java">        }
        this.groupIndex = i;
        <strong>this.addressIndex = j</strong>;
        return true;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L803C33-L803C38)

<pre><code class="java">    @Override
    public void log(ChannelLogLevel level, String message) {
      ChannelLoggerImpl.logOnly(<strong>logId</strong>, level, message);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L808C33-L808C38)

<pre><code class="java">    @Override
    public void log(ChannelLogLevel level, String messageFormat, Object... args) {
      ChannelLoggerImpl.logOnly(<strong>logId</strong>, level, messageFormat, args);
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L315C9-L315C22)

<pre><code class="java">  // Must be called from syncContext
  private void maybeShutdownNowSubchannels() {
    if (<strong>shutdownNowed</strong>) {
      for (InternalSubchannel subchannel : subchannels) {
        subchannel.shutdownNow(SHUTDOWN_NOW_STATUS);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L365C11-L365C19)

<pre><code class="java">      // an explicit enterIdleMode() by the user. Protecting here as other locations are a bit too
      // subtle to change rapidly to resolve the channel panic. See #8714
      if (<strong>lbHelper</strong> == null) {
        return;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L376C18-L376C37)

<pre><code class="java">    syncContext.throwIfNotInThisSynchronizationContext();
    if (channelIsActive) {
      checkState(<strong>nameResolverStarted</strong>, "nameResolver is not started");
      checkState(lbHelper != null, "lbHelper is null");
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L377C18-L377C26)

<pre><code class="java">    if (channelIsActive) {
      checkState(nameResolverStarted, "nameResolver is not started");
      checkState(<strong>lbHelper</strong> != null, "lbHelper is null");
    }
    if (nameResolver != null) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L379C9-L379C21)

<pre><code class="java">      checkState(lbHelper != null, "lbHelper is null");
    }
    if (<strong>nameResolver</strong> != null) {
      nameResolver.shutdown();
      nameResolverStarted = false;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L380C7-L380C19)

<pre><code class="java">    }
    if (nameResolver != null) {
      <strong>nameResolver</strong>.shutdown();
      nameResolverStarted = false;
      if (channelIsActive) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L381C7-L381C34)

<pre><code class="java">    if (nameResolver != null) {
      nameResolver.shutdown();
      <strong>nameResolverStarted = false</strong>;
      if (channelIsActive) {
        nameResolver = getNameResolver(
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L383C9-L385C63)

<pre><code class="java">      nameResolverStarted = false;
      if (channelIsActive) {
        <strong>nameResolver = getNameResolver(</strong>
<strong>            target, authorityOverride, nameResolverRegistry, nameResolverArgs,</strong>
<strong>            transportFactory.getSupportedSocketAddressTypes())</strong>;
      } else {
        nameResolver = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L387C9-L387C28)

<pre><code class="java">            transportFactory.getSupportedSocketAddressTypes());
      } else {
        <strong>nameResolver = null</strong>;
      }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L390C9-L390C17)

<pre><code class="java">      }
    }
    if (<strong>lbHelper</strong> != null) {
      lbHelper.lb.shutdown();
      lbHelper = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L391C7-L391C18)

<pre><code class="java">    }
    if (lbHelper != null) {
      <strong>lbHelper.lb</strong>.shutdown();
      lbHelper = null;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L391C7-L391C15)

<pre><code class="java">    }
    if (lbHelper != null) {
      <strong>lbHelper</strong>.lb.shutdown();
      lbHelper = null;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L392C7-L392C22)

<pre><code class="java">    if (lbHelper != null) {
      lbHelper.lb.shutdown();
      <strong>lbHelper = null</strong>;
    }
    subchannelPicker = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L394C5-L394C28)

<pre><code class="java">      lbHelper = null;
    }
    <strong>subchannelPicker = null</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L428C72-L428C84)

<pre><code class="java">
    channelStateManager.gotoState(CONNECTING);
    NameResolverListener listener = new NameResolverListener(lbHelper, <strong>nameResolver</strong>);
    nameResolver.start(listener);
    nameResolverStarted = true;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L405C27-L405C36)

<pre><code class="java">  void exitIdleMode() {
    syncContext.throwIfNotInThisSynchronizationContext();
    if (shutdown.get() || <strong>panicMode</strong>) {
      return;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L417C9-L417C17)

<pre><code class="java">      rescheduleIdleTimer();
    }
    if (<strong>lbHelper</strong> != null) {
      return;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L422C5-L422C64)

<pre><code class="java">    channelLogger.log(ChannelLogLevel.INFO, "Exiting idle mode");
    LbHelperImpl lbHelper = new LbHelperImpl();
    <strong>lbHelper.lb = loadBalancerFactory.newLoadBalancer(lbHelper)</strong>;
    // Delay setting lbHelper until fully initialized, since loadBalancerFactory is user code and
    // may throw. We don't want to confuse our state, even if we will enter panic mode.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L425C5-L425C29)

<pre><code class="java">    // Delay setting lbHelper until fully initialized, since loadBalancerFactory is user code and
    // may throw. We don't want to confuse our state, even if we will enter panic mode.
    <strong>this.lbHelper = lbHelper</strong>;

    channelStateManager.gotoState(CONNECTING);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L429C5-L429C17)

<pre><code class="java">    channelStateManager.gotoState(CONNECTING);
    NameResolverListener listener = new NameResolverListener(lbHelper, nameResolver);
    <strong>nameResolver</strong>.start(listener);
    nameResolverStarted = true;
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L430C5-L430C31)

<pre><code class="java">    NameResolverListener listener = new NameResolverListener(lbHelper, nameResolver);
    nameResolver.start(listener);
    <strong>nameResolverStarted = true</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L470C9-L470C28)

<pre><code class="java">  private void refreshNameResolution() {
    syncContext.throwIfNotInThisSynchronizationContext();
    if (<strong>nameResolverStarted</strong>) {
      nameResolver.refresh();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L471C7-L471C19)

<pre><code class="java">    syncContext.throwIfNotInThisSynchronizationContext();
    if (nameResolverStarted) {
      <strong>nameResolver</strong>.refresh();
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L479C37-L479C53)

<pre><code class="java">
    private ClientTransport getTransport(PickSubchannelArgs args) {
      SubchannelPicker pickerCopy = <strong>subchannelPicker</strong>;
      if (shutdown.get()) {
        // If channel is shut down, delayedTransport is also shut down which will fail the stream
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L850C13-L850C26)

<pre><code class="java">      @Override
      public void run() {
        if (<strong>shutdownNowed</strong>) {
          return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L853C9-L853C29)

<pre><code class="java">          return;
        }
        <strong>shutdownNowed = true</strong>;
        maybeShutdownNowSubchannels();
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L865C9-L865C18)

<pre><code class="java">  @VisibleForTesting
  void panic(final Throwable t) {
    if (<strong>panicMode</strong>) {
      // Preserve the first panic information
      return;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L869C5-L869C21)

<pre><code class="java">      return;
    }
    <strong>panicMode = true</strong>;
    cancelIdleTimer(/* permanent= */ true);
    shutdownNameResolverAndLoadBalancer(false);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L898C12-L898C21)

<pre><code class="java">  @VisibleForTesting
  boolean isInPanicMode() {
    return <strong>panicMode</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L903C5-L903C33)

<pre><code class="java">  // Called from syncContext
  private void updateSubchannelPicker(SubchannelPicker newPicker) {
    <strong>subchannelPicker = newPicker</strong>;
    delayedTransport.reprocess(newPicker);
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L919C12-L919C22)

<pre><code class="java">  @Override
  public boolean isTerminated() {
    return <strong>terminated</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L962C13-L962C23)

<pre><code class="java">            callOptions,
            transportProvider,
            <strong>terminated</strong> ? null : transportFactory.getScheduledExecutorService(),
            channelCallTracer,
            null)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1021C17-L1021C29)

<pre><code class="java">        public void run() {
          if (configSelector.get() == INITIAL_PENDING_SELECTOR) {
            if (<strong>pendingCalls</strong> == null) {
              pendingCalls = new LinkedHashSet&lt;&gt;();
              inUseStateAggregator.updateObjectInUse(pendingCallsInUseObject, true);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1022C15-L1022C51)

<pre><code class="java">          if (configSelector.get() == INITIAL_PENDING_SELECTOR) {
            if (pendingCalls == null) {
              <strong>pendingCalls = new LinkedHashSet&lt;&gt;()</strong>;
              inUseStateAggregator.updateObjectInUse(pendingCallsInUseObject, true);
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1025C13-L1025C25)

<pre><code class="java">              inUseStateAggregator.updateObjectInUse(pendingCallsInUseObject, true);
            }
            <strong>pendingCalls</strong>.add(pendingCall);
          } else {
            pendingCall.reprocess();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1038C53-L1038C65)

<pre><code class="java">      InternalConfigSelector prevConfig = configSelector.get();
      configSelector.set(config);
      if (prevConfig == INITIAL_PENDING_SELECTOR &amp;&amp; <strong>pendingCalls</strong> != null) {
        for (RealChannel.PendingCall&lt;?, ?&gt; pendingCall : pendingCalls) {
          pendingCall.reprocess();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1039C58-L1039C70)

<pre><code class="java">      configSelector.set(config);
      if (prevConfig == INITIAL_PENDING_SELECTOR &amp;&amp; pendingCalls != null) {
        for (RealChannel.PendingCall&lt;?, ?&gt; pendingCall : <strong>pendingCalls</strong>) {
          pendingCall.reprocess();
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1056C15-L1056C27)

<pre><code class="java">        @Override
        public void run() {
          if (<strong>pendingCalls</strong> == null) {
            if (configSelector.get() == INITIAL_PENDING_SELECTOR) {
              configSelector.set(null);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1075C15-L1075C27)

<pre><code class="java">            configSelector.set(null);
          }
          if (<strong>pendingCalls</strong> != null) {
            for (RealChannel.PendingCall&lt;?, ?&gt; pendingCall : pendingCalls) {
              pendingCall.cancel("Channel is forcefully shutdown", null);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1076C62-L1076C74)

<pre><code class="java">          }
          if (pendingCalls != null) {
            for (RealChannel.PendingCall&lt;?, ?&gt; pendingCall : <strong>pendingCalls</strong>) {
              pendingCall.cancel("Channel is forcefully shutdown", null);
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1141C15-L1141C27)

<pre><code class="java">        @Override
        public void run() {
          if (<strong>pendingCalls</strong> != null) {
            pendingCalls.remove(PendingCall.this);
            if (pendingCalls.isEmpty()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1142C13-L1142C25)

<pre><code class="java">        public void run() {
          if (pendingCalls != null) {
            <strong>pendingCalls</strong>.remove(PendingCall.this);
            if (pendingCalls.isEmpty()) {
              inUseStateAggregator.updateObjectInUse(pendingCallsInUseObject, false);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1143C17-L1143C29)

<pre><code class="java">          if (pendingCalls != null) {
            pendingCalls.remove(PendingCall.this);
            if (<strong>pendingCalls</strong>.isEmpty()) {
              inUseStateAggregator.updateObjectInUse(pendingCallsInUseObject, false);
              pendingCalls = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1145C15-L1145C34)

<pre><code class="java">            if (pendingCalls.isEmpty()) {
              inUseStateAggregator.updateObjectInUse(pendingCallsInUseObject, false);
              <strong>pendingCalls = null</strong>;
              if (shutdown.get()) {
                uncommittedRetriableStreamsRegistry.onShutdown(SHUTDOWN_STATUS);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1204C14-L1204C22)

<pre><code class="java">    @Override
    protected ClientCall&lt;ReqT, RespT&gt; delegate() {
      return <strong>delegate</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1210C77-L1210C88)

<pre><code class="java">    @Override
    public void start(Listener&lt;RespT&gt; observer, Metadata headers) {
      PickSubchannelArgs args = new PickSubchannelArgsImpl(method, headers, <strong>callOptions</strong>);
      InternalConfigSelector.Result result = configSelector.selectConfig(args);
      Status status = result.getStatus();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1216C9-L1216C55)

<pre><code class="java">        executeCloseObserverInContext(observer,
            GrpcUtil.replaceInappropriateControlPlaneStatus(status));
        <strong>delegate = (ClientCall&lt;ReqT, RespT&gt;) NOOP_CALL</strong>;
        return;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1223C9-L1223C73)

<pre><code class="java">      MethodInfo methodInfo = config.getMethodConfig(method);
      if (methodInfo != null) {
        <strong>callOptions = callOptions.withOption(MethodInfo.KEY, methodInfo)</strong>;
      }
      if (interceptor != null) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1223C23-L1223C34)

<pre><code class="java">      MethodInfo methodInfo = config.getMethodConfig(method);
      if (methodInfo != null) {
        callOptions = <strong>callOptions</strong>.withOption(MethodInfo.KEY, methodInfo);
      }
      if (interceptor != null) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1226C9-L1226C75)

<pre><code class="java">      }
      if (interceptor != null) {
        <strong>delegate = interceptor.interceptCall(method, callOptions, channel)</strong>;
      } else {
        delegate = channel.newCall(method, callOptions);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1226C54-L1226C65)

<pre><code class="java">      }
      if (interceptor != null) {
        delegate = interceptor.interceptCall(method, <strong>callOptions</strong>, channel);
      } else {
        delegate = channel.newCall(method, callOptions);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1228C9-L1228C56)

<pre><code class="java">        delegate = interceptor.interceptCall(method, callOptions, channel);
      } else {
        <strong>delegate = channel.newCall(method, callOptions)</strong>;
      }
      delegate.start(observer, headers);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1228C44-L1228C55)

<pre><code class="java">        delegate = interceptor.interceptCall(method, callOptions, channel);
      } else {
        delegate = channel.newCall(method, <strong>callOptions</strong>);
      }
      delegate.start(observer, headers);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1230C7-L1230C15)

<pre><code class="java">        delegate = channel.newCall(method, callOptions);
      }
      <strong>delegate</strong>.start(observer, headers);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1251C11-L1251C19)

<pre><code class="java">    @Override
    public void cancel(@Nullable String message, @Nullable Throwable cause) {
      if (<strong>delegate</strong> != null) {
        delegate.cancel(message, cause);
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1252C9-L1252C17)

<pre><code class="java">    public void cancel(@Nullable String message, @Nullable Throwable cause) {
      if (delegate != null) {
        <strong>delegate</strong>.cancel(message, cause);
      }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1285C9-L1285C19)

<pre><code class="java">  // Must be run from syncContext
  private void maybeTerminateChannel() {
    if (<strong>terminated</strong>) {
      return;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1297C7-L1297C24)

<pre><code class="java">      transportFactory.close();

      <strong>terminated = true</strong>;
      terminatedLatch.countDown();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1318C15-L1318C31)

<pre><code class="java">        public void run() {
          exitIdleMode();
          if (<strong>subchannelPicker</strong> != null) {
            subchannelPicker.requestConnection();
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1319C13-L1319C29)

<pre><code class="java">          exitIdleMode();
          if (subchannelPicker != null) {
            <strong>subchannelPicker</strong>.requestConnection();
          }
          if (lbHelper != null) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1321C15-L1321C23)

<pre><code class="java">            subchannelPicker.requestConnection();
          }
          if (<strong>lbHelper</strong> != null) {
            lbHelper.lb.requestConnection();
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1322C13-L1322C24)

<pre><code class="java">          }
          if (lbHelper != null) {
            <strong>lbHelper.lb</strong>.requestConnection();
          }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1322C13-L1322C21)

<pre><code class="java">          }
          if (lbHelper != null) {
            <strong>lbHelper</strong>.lb.requestConnection();
          }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1352C13-L1352C32)

<pre><code class="java">          return;
        }
        if (<strong>nameResolverStarted</strong>) {
          refreshNameResolution();
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1372C31-L1372C39)

<pre><code class="java">      @Override
      public void run() {
        if (shutdown.get() || <strong>lbHelper</strong> == null) {
          return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1473C19-L1473C30)

<pre><code class="java">      syncContext.throwIfNotInThisSynchronizationContext();
      // No new subchannel should be created after load balancer has been shutdown.
      checkState(!<strong>terminating</strong>, "Channel is being terminated");
      return new SubchannelImpl(args);
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1486C36-L1486C44)

<pre><code class="java">        @Override
        public void run() {
          if (LbHelperImpl.this != <strong>lbHelper</strong>) {
            return;
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1525C19-L1525C29)

<pre><code class="java">        String authority) {
      // TODO(ejona): can we be even stricter? Like terminating?
      checkState(!<strong>terminated</strong>, "Channel is terminated");
      long oobChannelCreationTime = timeProvider.currentTimeNanos();
      InternalLogId oobLogId = InternalLogId.allocate("OobChannel", /*details=*/ null);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1589C15-L1589C26)

<pre><code class="java">        @Override
        public void run() {
          if (<strong>terminating</strong>) {
            oobChannel.shutdown();
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1592C16-L1592C26)

<pre><code class="java">            oobChannel.shutdown();
          }
          if (!<strong>terminated</strong>) {
            // If channel has not terminated, it will track the subchannel and block termination
            // for it.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1663C19-L1663C29)

<pre><code class="java">      }

      checkState(!<strong>terminated</strong>, "Channel is terminated");

      @SuppressWarnings("deprecation")
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1757C15-L1757C51)

<pre><code class="java">        @Override
        public void run() {
          if (<strong>ManagedChannelImpl.this.nameResolver</strong> != resolver) {
            return;
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1768C15-L1768C34)

<pre><code class="java">              resolutionResult.getAttributes());

          if (<strong>lastResolutionState</strong> != ResolutionState.SUCCESS) {
            channelLogger.log(ChannelLogLevel.INFO, "Address resolved: {0}", servers);
            lastResolutionState = ResolutionState.SUCCESS;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1770C13-L1770C58)

<pre><code class="java">          if (lastResolutionState != ResolutionState.SUCCESS) {
            channelLogger.log(ChannelLogLevel.INFO, "Address resolved: {0}", servers);
            <strong>lastResolutionState = ResolutionState.SUCCESS</strong>;
          }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1822C20-L1822C40)

<pre><code class="java">                  "Received no service config, using default service config");
            } else if (serviceConfigError != null) {
              if (!<strong>serviceConfigUpdated</strong>) {
                // First DNS lookup has invalid service config, and cannot fall back to default
                channelLogger.log(
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1837C42-L1837C59)

<pre><code class="java">                return;
              } else {
                effectiveServiceConfig = <strong>lastServiceConfig</strong>;
              }
            } else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1843C48-L1843C65)

<pre><code class="java">              realChannel.updateConfigSelector(null);
            }
            if (!effectiveServiceConfig.equals(<strong>lastServiceConfig</strong>)) {
              channelLogger.log(
                  ChannelLogLevel.INFO,
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1848C15-L1848C57)

<pre><code class="java">                  "Service config changed{0}",
                  effectiveServiceConfig == EMPTY_SERVICE_CONFIG ? " to empty" : "");
              <strong>lastServiceConfig = effectiveServiceConfig</strong>;
              transportProvider.throttle = effectiveServiceConfig.getRetryThrottling();
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1849C15-L1849C87)

<pre><code class="java">                  effectiveServiceConfig == EMPTY_SERVICE_CONFIG ? " to empty" : "");
              lastServiceConfig = effectiveServiceConfig;
              <strong>transportProvider.throttle = effectiveServiceConfig.getRetryThrottling()</strong>;
            }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1856C15-L1856C42)

<pre><code class="java">              //  and lbNeedAddress, it shouldn't call the handleServiceConfigUpdate. But,
              //  lbNeedAddress is not deterministic
              <strong>serviceConfigUpdated = true</strong>;
            } catch (RuntimeException re) {
              logger.log(
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1867C51-L1867C83)

<pre><code class="java">          Attributes effectiveAttrs = resolutionResult.getAttributes();
          // Call LB only if it's not shutdown.  If LB is shutdown, lbHelper won't match.
          if (NameResolverListener.this.helper == <strong>ManagedChannelImpl.this.lbHelper</strong>) {
            Attributes.Builder attrBuilder =
                effectiveAttrs.toBuilder().discard(InternalConfigSelector.KEY);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1879C46-L1879C55)

<pre><code class="java">            Attributes attributes = attrBuilder.build();

            Status addressAcceptanceStatus = <strong>helper.lb</strong>.tryAcceptResolvedAddresses(
                ResolvedAddresses.newBuilder()
                    .setAddresses(servers)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1913C11-L1913C30)

<pre><code class="java">          new Object[] {getLogId(), error});
      realChannel.onConfigError();
      if (<strong>lastResolutionState</strong> != ResolutionState.ERROR) {
        channelLogger.log(ChannelLogLevel.WARNING, "Failed to resolve name: {0}", error);
        lastResolutionState = ResolutionState.ERROR;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1915C9-L1915C52)

<pre><code class="java">      if (lastResolutionState != ResolutionState.ERROR) {
        channelLogger.log(ChannelLogLevel.WARNING, "Failed to resolve name: {0}", error);
        <strong>lastResolutionState = ResolutionState.ERROR</strong>;
      }
      // Call LB only if it's not shutdown.  If LB is shutdown, lbHelper won't match.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1918C47-L1918C79)

<pre><code class="java">      }
      // Call LB only if it's not shutdown.  If LB is shutdown, lbHelper won't match.
      if (NameResolverListener.this.helper != <strong>ManagedChannelImpl.this.lbHelper</strong>) {
        return;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1922C7-L1922C16)

<pre><code class="java">      }

      <strong>helper.lb</strong>.handleNameResolutionError(error);
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1956C19-L1956C26)

<pre><code class="java">    public void start(final SubchannelStateListener listener) {
      syncContext.throwIfNotInThisSynchronizationContext();
      checkState(!<strong>started</strong>, "already started");
      checkState(!shutdown, "already shutdown");
      checkState(!terminating, "Channel is being terminated");
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1957C19-L1957C27)

<pre><code class="java">      syncContext.throwIfNotInThisSynchronizationContext();
      checkState(!started, "already started");
      checkState(!<strong>shutdown</strong>, "already shutdown");
      checkState(!terminating, "Channel is being terminated");
      started = true;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1958C19-L1958C30)

<pre><code class="java">      checkState(!started, "already started");
      checkState(!shutdown, "already shutdown");
      checkState(!<strong>terminating</strong>, "Channel is being terminated");
      started = true;
      final class ManagedInternalSubchannelCallback extends InternalSubchannel.Callback {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1959C7-L1959C21)

<pre><code class="java">      checkState(!shutdown, "already shutdown");
      checkState(!terminating, "Channel is being terminated");
      <strong>started = true</strong>;
      final class ManagedInternalSubchannelCallback extends InternalSubchannel.Callback {
        // All callbacks are run in syncContext
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2010C7-L2010C43)

<pre><code class="java">          .build());

      <strong>this.subchannel = internalSubchannel</strong>;
      channelz.addSubchannel(internalSubchannel);
      subchannels.add(internalSubchannel);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2017C18-L2017C25)

<pre><code class="java">    @Override
    InternalInstrumented&lt;ChannelStats&gt; getInstrumentedInternalSubchannel() {
      checkState(<strong>started</strong>, "not started");
      return subchannel;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2018C14-L2018C24)

<pre><code class="java">    InternalInstrumented&lt;ChannelStats&gt; getInstrumentedInternalSubchannel() {
      checkState(started, "not started");
      return <strong>subchannel</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2024C11-L2024C21)

<pre><code class="java">    public void shutdown() {
      syncContext.throwIfNotInThisSynchronizationContext();
      if (<strong>subchannel</strong> == null) {
        // start() was not successful
        shutdown = true;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2026C9-L2026C24)

<pre><code class="java">      if (subchannel == null) {
        // start() was not successful
        <strong>shutdown = true</strong>;
        return;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2029C11-L2029C19)

<pre><code class="java">        return;
      }
      if (<strong>shutdown</strong>) {
        if (terminating &amp;&amp; delayedShutdownTask != null) {
          // shutdown() was previously called when terminating == false, thus a delayed shutdown()
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2030C13-L2030C24)

<pre><code class="java">      }
      if (shutdown) {
        if (<strong>terminating</strong> &amp;&amp; delayedShutdownTask != null) {
          // shutdown() was previously called when terminating == false, thus a delayed shutdown()
          // was scheduled.  Now since terminating == true, We should expedite the shutdown.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2030C28-L2030C47)

<pre><code class="java">      }
      if (shutdown) {
        if (terminating &amp;&amp; <strong>delayedShutdownTask</strong> != null) {
          // shutdown() was previously called when terminating == false, thus a delayed shutdown()
          // was scheduled.  Now since terminating == true, We should expedite the shutdown.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2033C11-L2033C30)

<pre><code class="java">          // shutdown() was previously called when terminating == false, thus a delayed shutdown()
          // was scheduled.  Now since terminating == true, We should expedite the shutdown.
          <strong>delayedShutdownTask</strong>.cancel();
          delayedShutdownTask = null;
          // Will fall through to the subchannel.shutdown() at the end.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2034C11-L2034C37)

<pre><code class="java">          // was scheduled.  Now since terminating == true, We should expedite the shutdown.
          delayedShutdownTask.cancel();
          <strong>delayedShutdownTask = null</strong>;
          // Will fall through to the subchannel.shutdown() at the end.
        } else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2040C9-L2040C24)

<pre><code class="java">        }
      } else {
        <strong>shutdown = true</strong>;
      }
      // Add a delay to shutdown to deal with the race between 1) a transport being picked and
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2050C12-L2050C23)

<pre><code class="java">      // TODO(zhangkun83): consider a better approach
      // (https://github.com/grpc/grpc-java/issues/2562).
      if (!<strong>terminating</strong>) {
        final class ShutdownSubchannel implements Runnable {
          @Override
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2054C13-L2054C23)

<pre><code class="java">          @Override
          public void run() {
            <strong>subchannel</strong>.shutdown(SUBCHANNEL_SHUTDOWN_STATUS);
          }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2058C9-L2061C60)

<pre><code class="java">        }

        <strong>delayedShutdownTask = syncContext.schedule(</strong>
<strong>            new LogExceptionRunnable(new ShutdownSubchannel()),</strong>
<strong>            SUBCHANNEL_SHUTDOWN_DELAY_SECONDS, TimeUnit.SECONDS,</strong>
<strong>            transportFactory.getScheduledExecutorService())</strong>;
        return;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2066C7-L2066C17)

<pre><code class="java">      // When terminating == true, no more real streams will be created. It's safe and also
      // desirable to shutdown timely.
      <strong>subchannel</strong>.shutdown(SHUTDOWN_STATUS);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2072C18-L2072C25)

<pre><code class="java">    public void requestConnection() {
      syncContext.throwIfNotInThisSynchronizationContext();
      checkState(<strong>started</strong>, "not started");
      subchannel.obtainActiveTransport();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2073C7-L2073C17)

<pre><code class="java">      syncContext.throwIfNotInThisSynchronizationContext();
      checkState(started, "not started");
      <strong>subchannel</strong>.obtainActiveTransport();
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2079C18-L2079C25)

<pre><code class="java">    public List&lt;EquivalentAddressGroup&gt; getAllAddresses() {
      syncContext.throwIfNotInThisSynchronizationContext();
      checkState(<strong>started</strong>, "not started");
      return addressGroups;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2080C14-L2080C27)

<pre><code class="java">      syncContext.throwIfNotInThisSynchronizationContext();
      checkState(started, "not started");
      return <strong>addressGroups</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2095C18-L2095C25)

<pre><code class="java">    @Override
    public Channel asChannel() {
      checkState(<strong>started</strong>, "not started");
      return new SubchannelChannel(
          subchannel, balancerRpcExecutorHolder.getExecutor(),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2097C11-L2097C21)

<pre><code class="java">      checkState(started, "not started");
      return new SubchannelChannel(
          <strong>subchannel</strong>, balancerRpcExecutorHolder.getExecutor(),
          transportFactory.getScheduledExecutorService(),
          callTracerFactory.create(),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2105C18-L2105C25)

<pre><code class="java">    @Override
    public Object getInternalSubchannel() {
      checkState(<strong>started</strong>, "Subchannel is not started");
      return subchannel;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2106C14-L2106C24)

<pre><code class="java">    public Object getInternalSubchannel() {
      checkState(started, "Subchannel is not started");
      return <strong>subchannel</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2117C7-L2117C28)

<pre><code class="java">    public void updateAddresses(List&lt;EquivalentAddressGroup&gt; addrs) {
      syncContext.throwIfNotInThisSynchronizationContext();
      <strong>addressGroups = addrs</strong>;
      if (authorityOverride != null) {
        addrs = stripOverrideAuthorityAttributes(addrs);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2121C7-L2121C17)

<pre><code class="java">        addrs = stripOverrideAuthorityAttributes(addrs);
      }
      <strong>subchannel</strong>.updateAddresses(addrs);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2172C7-L2172C25)

<pre><code class="java">    public void transportTerminated() {
      checkState(shutdown.get(), "Channel must have been shut down");
      <strong>terminating = true</strong>;
      shutdownNameResolverAndLoadBalancer(false);
      // No need to call channelStateManager since we are already in SHUTDOWN state.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L125C11-L125C25)

<pre><code class="java">        @Override
        public void transportTerminated() {
          <strong>subchannelImpl</strong>.shutdown();
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L151C5-L151C33)

<pre><code class="java">  void setSubchannel(final InternalSubchannel subchannel) {
    log.log(Level.FINE, "[{0}] Created with [{1}]", new Object[] {this, subchannel});
    <strong>this.subchannel = subchannel</strong>;
    subchannelImpl = new AbstractSubchannel() {
        @Override
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L152C5-L182C6)

<pre><code class="java">    log.log(Level.FINE, "[{0}] Created with [{1}]", new Object[] {this, subchannel});
    this.subchannel = subchannel;
    <strong>subchannelImpl = new AbstractSubchannel() {</strong>
<strong>        @Override</strong>
<strong>        public void shutdown() {</strong>
<strong>          subchannel.shutdown(Status.UNAVAILABLE.withDescription("OobChannel is shutdown"));</strong>
<strong>        }</strong>
<strong></strong>
<strong>        @Override</strong>
<strong>        InternalInstrumented&lt;ChannelStats&gt; getInstrumentedInternalSubchannel() {</strong>
<strong>          return subchannel;</strong>
<strong>        }</strong>
<strong></strong>
<strong>        @Override</strong>
<strong>        public void requestConnection() {</strong>
<strong>          subchannel.obtainActiveTransport();</strong>
<strong>        }</strong>
<strong></strong>
<strong>        @Override</strong>
<strong>        public List&lt;EquivalentAddressGroup&gt; getAllAddresses() {</strong>
<strong>          return subchannel.getAddressGroups();</strong>
<strong>        }</strong>
<strong></strong>
<strong>        @Override</strong>
<strong>        public Attributes getAttributes() {</strong>
<strong>          return Attributes.EMPTY;</strong>
<strong>        }</strong>
<strong></strong>
<strong>        @Override</strong>
<strong>        public Object getInternalSubchannel() {</strong>
<strong>          return subchannel;</strong>
<strong>        }</strong>
<strong>    }</strong>;

    final class OobSubchannelPicker extends SubchannelPicker {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L200C5-L200C49)

<pre><code class="java">    }

    <strong>subchannelPicker = new OobSubchannelPicker()</strong>;
    delayedTransport.reprocess(subchannelPicker);
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L201C32-L201C48)

<pre><code class="java">
    subchannelPicker = new OobSubchannelPicker();
    delayedTransport.reprocess(<strong>subchannelPicker</strong>);
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L205C5-L205C15)

<pre><code class="java">
  void updateAddresses(List&lt;EquivalentAddressGroup&gt; eag) {
    <strong>subchannel</strong>.updateAddresses(eag);
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L233C9-L233C19)

<pre><code class="java">  @Override
  public ConnectivityState getState(boolean requestConnectionIgnored) {
    if (<strong>subchannel</strong> == null) {
      return ConnectivityState.IDLE;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L236C12-L236C22)

<pre><code class="java">      return ConnectivityState.IDLE;
    }
    return <strong>subchannel</strong>.getState();
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L241C5-L241C20)

<pre><code class="java">  @Override
  public ManagedChannel shutdown() {
    <strong>shutdown = true</strong>;
    delayedTransport.shutdown(Status.UNAVAILABLE.withDescription("OobChannel.shutdown() called"));
    return this;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L248C12-L248C20)

<pre><code class="java">  @Override
  public boolean isShutdown() {
    return <strong>shutdown</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L253C5-L253C20)

<pre><code class="java">  @Override
  public ManagedChannel shutdownNow() {
    <strong>shutdown = true</strong>;
    delayedTransport.shutdownNow(
        Status.UNAVAILABLE.withDescription("OobChannel.shutdownNow() called"));
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L269C36-L269C52)

<pre><code class="java">      case READY:
      case IDLE:
        delayedTransport.reprocess(<strong>subchannelPicker</strong>);
        break;
      case TRANSIENT_FAILURE:
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L306C12-L306C26)

<pre><code class="java">  @VisibleForTesting
  Subchannel getSubchannel() {
    return <strong>subchannelImpl</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L310C12-L310C22)

<pre><code class="java">
  InternalSubchannel getInternalSubchannel() {
    return <strong>subchannel</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L321C19-L321C29)

<pre><code class="java">    builder
        .setTarget(authority)
        .setState(<strong>subchannel</strong>.getState())
        .setSubchannels(Collections.&lt;InternalWithLogId&gt;singletonList(subchannel));
    ret.set(builder.build());
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L322C70-L322C80)

<pre><code class="java">        .setTarget(authority)
        .setState(subchannel.getState())
        .setSubchannels(Collections.&lt;InternalWithLogId&gt;singletonList(<strong>subchannel</strong>));
    ret.set(builder.build());
    return ret;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L342C5-L342C15)

<pre><code class="java">  @Override
  public void resetConnectBackoff() {
    <strong>subchannel</strong>.resetConnectBackoff();
  }
}
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L121C28-L121C48)

<pre><code class="java">          ClientStatsPerToken.newBuilder()
              .setLoadBalanceToken(entry.getKey())
              .setNumCalls(<strong>entry.getValue().num</strong>)
              .build());
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L133C7-L133C25)

<pre><code class="java">    @Override
    public void outboundHeaders() {
      <strong>headersSent = true</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L138C7-L138C30)

<pre><code class="java">    @Override
    public void inboundHeaders() {
      <strong>anythingReceived = true</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L143C7-L143C30)

<pre><code class="java">    @Override
    public void inboundMessage(int seqNo) {
      <strong>anythingReceived = true</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L149C12-L149C23)

<pre><code class="java">    public void streamClosed(Status status) {
      callsFinishedUpdater.getAndIncrement(GrpclbClientLoadRecorder.this);
      if (!<strong>headersSent</strong>) {
        callsFailedToSendUpdater.getAndIncrement(GrpclbClientLoadRecorder.this);
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L152C11-L152C27)

<pre><code class="java">        callsFailedToSendUpdater.getAndIncrement(GrpclbClientLoadRecorder.this);
      }
      if (<strong>anythingReceived</strong>) {
        callsFinishedKnownReceivedUpdater.getAndIncrement(GrpclbClientLoadRecorder.this);
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L77C5-L77C35)

<pre><code class="java">  @Override
  public void start(ServerListener serverListener) throws IOException {
    <strong>this.listener = serverListener</strong>;
    this.scheduler = schedulerPool.getObject();
    // Must be last, as channels can start connecting after this point.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L78C5-L78C47)

<pre><code class="java">  public void start(ServerListener serverListener) throws IOException {
    this.listener = serverListener;
    <strong>this.scheduler = schedulerPool.getObject()</strong>;
    // Must be last, as channels can start connecting after this point.
    registerInstance();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L119C5-L119C54)

<pre><code class="java">  public void shutdown() {
    unregisterInstance();
    <strong>scheduler = schedulerPool.returnObject(scheduler)</strong>;
    synchronized (this) {
      shutdown = true;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L119C44-L119C53)

<pre><code class="java">  public void shutdown() {
    unregisterInstance();
    scheduler = schedulerPool.returnObject(<strong>scheduler</strong>);
    synchronized (this) {
      shutdown = true;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L128C11-L128C34)

<pre><code class="java">        @Override
        protected void handleInUse() {
          <strong>clientTransportListener</strong>.transportInUse(true);
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L133C11-L133C34)

<pre><code class="java">        @Override
        protected void handleNotInUse() {
          <strong>clientTransportListener</strong>.transportInUse(false);
        }
      };
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L338C12-L338C22)

<pre><code class="java">  @Override
  public Attributes getAttributes() {
    return <strong>attributes</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L343C12-L343C27)

<pre><code class="java">  @Override
  public ScheduledExecutorService getScheduledExecutorService() {
    return <strong>serverScheduler</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L465C46-L465C66)

<pre><code class="java">          synchronized (this) {
            if (!closed) {
              syncContext.executeLater(() -&gt; <strong>clientStreamListener</strong>.onReady());
            }
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L491C44-L491C64)

<pre><code class="java">            clientRequested--;
            StreamListener.MessageProducer producer = clientReceiveQueue.poll();
            syncContext.executeLater(() -&gt; <strong>clientStreamListener</strong>.messagesAvailable(producer));
          }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L501C17-L501C37)

<pre><code class="java">            Metadata notifyTrailers = this.clientNotifyTrailers;
            syncContext.executeLater(() -&gt;
                <strong>clientStreamListener</strong>.closed(notifyStatus, RpcProgress.PROCESSED, notifyTrailers));
          }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L529C44-L529C64)

<pre><code class="java">          if (clientRequested &gt; 0) {
            clientRequested--;
            syncContext.executeLater(() -&gt; <strong>clientStreamListener</strong>.messagesAvailable(producer));
          } else {
            clientReceiveQueue.add(producer);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L575C42-L575C62)

<pre><code class="java">
          clientStream.statsTraceCtx.clientInboundHeaders();
          syncContext.executeLater(() -&gt; <strong>clientStreamListener</strong>.headersRead(headers));
        }
        syncContext.drain();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L623C23-L623C43)

<pre><code class="java">            clientStream.statsTraceCtx.streamClosed(clientStatus);
            syncContext.executeLater(
                () -&gt; <strong>clientStreamListener</strong>.closed(clientStatus, RpcProgress.PROCESSED, trailers));
          } else {
            clientNotifyStatus = clientStatus;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L662C19-L662C39)

<pre><code class="java">          syncContext.executeLater(
              () -&gt;
                  <strong>clientStreamListener</strong>.closed(clientStatus, RpcProgress.PROCESSED, new Metadata()));
        }
        syncContext.drain();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L683C16-L683C38)

<pre><code class="java">
      @Override public Attributes getAttributes() {
        return <strong>serverStreamAttributes</strong>;
      }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L688C16-L688C46)

<pre><code class="java">      @Override
      public String getAuthority() {
        return <strong>InProcessStream.this.authority</strong>;
      }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L743C46-L743C66)

<pre><code class="java">          synchronized (this) {
            if (!closed) {
              syncContext.executeLater(() -&gt; <strong>serverStreamListener</strong>.onReady());
            }
          }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L769C44-L769C64)

<pre><code class="java">            serverRequested--;
            StreamListener.MessageProducer producer = serverReceiveQueue.poll();
            syncContext.executeLater(() -&gt; <strong>serverStreamListener</strong>.messagesAvailable(producer));
          }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L774C44-L774C64)

<pre><code class="java">          if (serverReceiveQueue.isEmpty() &amp;&amp; serverNotifyHalfClose) {
            serverNotifyHalfClose = false;
            syncContext.executeLater(() -&gt; <strong>serverStreamListener</strong>.halfClosed());
          }
          nowReady = serverRequested &gt; 0;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L800C44-L800C64)

<pre><code class="java">          if (serverRequested &gt; 0) {
            serverRequested--;
            syncContext.executeLater(() -&gt; <strong>serverStreamListener</strong>.messagesAvailable(producer));
          } else {
            serverReceiveQueue.add(producer);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L850C42-L850C62)

<pre><code class="java">          }
          serverStream.statsTraceCtx.streamClosed(serverTracerStatus);
          syncContext.executeLater(() -&gt; <strong>serverStreamListener</strong>.closed(serverListenerStatus));
        }
        syncContext.drain();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L863C44-L863C64)

<pre><code class="java">          }
          if (serverReceiveQueue.isEmpty()) {
            syncContext.executeLater(() -&gt; <strong>serverStreamListener</strong>.halfClosed());
          } else {
            serverNotifyHalfClose = true;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L876C9-L876C48)

<pre><code class="java">      @Override
      public void setAuthority(String string) {
        <strong>InProcessStream.this.authority = string</strong>;
      }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L895C16-L895C26)

<pre><code class="java">      @Override
      public Attributes getAttributes() {
        return <strong>attributes</strong>;
      }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L961C37-L961C44)

<pre><code class="java">    @Override
    public InputStream next() {
      InputStream messageToReturn = <strong>message</strong>;
      message = null;
      return messageToReturn;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L962C7-L962C21)

<pre><code class="java">    public InputStream next() {
      InputStream messageToReturn = message;
      <strong>message = null</strong>;
      return messageToReturn;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L348C5-L349C76)

<pre><code class="java">    BackoffCacheEntry entry = new BackoffCacheEntry(request, status, backoffPolicy);
    // Lock is held, so the task can't execute before the assignment
    <strong>entry.scheduledFuture = scheduledExecutorService.schedule(</strong>
<strong>        () -&gt; refreshBackoffEntry(entry), delayNanos, TimeUnit.NANOSECONDS)</strong>;
    linkedHashLruCache.cacheAndClean(request, entry);
    logger.log(ChannelLogLevel.DEBUG, "BackoffCacheEntry created with a delay of {0} nanos",
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L386C7-L386C23)

<pre><code class="java">    @Override
    public void updateBalancingState(ConnectivityState newState, SubchannelPicker newPicker) {
      <strong>state = newState</strong>;
      picker = newPicker;
      super.updateBalancingState(newState, newPicker);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L387C7-L387C25)

<pre><code class="java">    public void updateBalancingState(ConnectivityState newState, SubchannelPicker newPicker) {
      state = newState;
      <strong>picker = newPicker</strong>;
      super.updateBalancingState(newState, newPicker);
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L395C15-L395C21)

<pre><code class="java">        @Override
        public void run() {
          if (<strong>picker</strong> != null) {
            // Refresh the channel state and let pending RPCs reprocess the picker.
            updateBalancingState(state, picker);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L397C34-L397C39)

<pre><code class="java">          if (picker != null) {
            // Refresh the channel state and let pending RPCs reprocess the picker.
            updateBalancingState(<strong>state</strong>, picker);
          }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L397C41-L397C47)

<pre><code class="java">          if (picker != null) {
            // Refresh the channel state and let pending RPCs reprocess the picker.
            updateBalancingState(state, <strong>picker</strong>);
          }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L405C44-L405C49)

<pre><code class="java">    void triggerPendingRpcProcessing() {
      helper.getSynchronizationContext().execute(
          () -&gt; super.updateBalancingState(<strong>state</strong>, picker));
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L405C51-L405C57)

<pre><code class="java">    void triggerPendingRpcProcessing() {
      helper.getSynchronizationContext().execute(
          () -&gt; super.updateBalancingState(state, <strong>picker</strong>));
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L700C14-L700C29)

<pre><code class="java">    @Override
    boolean isExpired(long now) {
      return <strong>scheduledFuture</strong>.isDone();
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L705C7-L705C22)

<pre><code class="java">    @Override
    void cleanup() {
      <strong>scheduledFuture</strong>.cancel(false);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L734C7-L734C51)

<pre><code class="java">
    Builder setHelper(Helper helper) {
      <strong>this.helper = checkNotNull(helper, "helper")</strong>;
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L739C7-L739C75)

<pre><code class="java">
    Builder setLbPolicyConfig(LbPolicyConfiguration lbPolicyConfig) {
      <strong>this.lbPolicyConfig = checkNotNull(lbPolicyConfig, "lbPolicyConfig")</strong>;
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L744C7-L744C60)

<pre><code class="java">
    Builder setThrottler(Throttler throttler) {
      <strong>this.throttler = checkNotNull(throttler, "throttler")</strong>;
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L753C7-L754C73)

<pre><code class="java">    Builder setResolvedAddressesFactory(
        ResolvedAddressFactory resolvedAddressFactory) {
      <strong>this.resolvedAddressFactory =</strong>
<strong>          checkNotNull(resolvedAddressFactory, "resolvedAddressFactory")</strong>;
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L759C7-L759C51)

<pre><code class="java">
    Builder setTicker(Ticker ticker) {
      <strong>this.ticker = checkNotNull(ticker, "ticker")</strong>;
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L765C7-L765C47)

<pre><code class="java">    Builder setEvictionListener(
        @Nullable EvictionListener&lt;RouteLookupRequest, CacheEntry&gt; evictionListener) {
      <strong>this.evictionListener = evictionListener</strong>;
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L770C7-L770C64)

<pre><code class="java">
    Builder setBackoffProvider(BackoffPolicy.Provider provider) {
      <strong>this.backoffProvider = checkNotNull(provider, "provider")</strong>;
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L776C7-L776C13)

<pre><code class="java">    CachingRlsLbClient build() {
      CachingRlsLbClient client = new CachingRlsLbClient(this);
      <strong>helper</strong>.updateBalancingState(ConnectivityState.CONNECTING, client.rlsPicker);
      return client;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L882C11-L882C20)

<pre><code class="java">    public void onStatusChanged(ConnectivityState newState) {
      logger.log(ChannelLogLevel.DEBUG, "LB status changed to: {0}", newState);
      if (<strong>prevState</strong> == ConnectivityState.TRANSIENT_FAILURE
          &amp;&amp; newState == ConnectivityState.READY) {
        logger.log(ChannelLogLevel.DEBUG, "Transitioning from TRANSIENT_FAILURE to READY");
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L895C7-L895C27)

<pre><code class="java">        }
      }
      <strong>prevState = newState</strong>;
    }
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L968C33-L968C59)

<pre><code class="java">      // TODO(creamsoup) wait until lb is ready
      startFallbackChildPolicy();
      SubchannelPicker picker = <strong>fallbackChildPolicyWrapper</strong>.getPicker();
      if (picker == null) {
        return PickResult.withNoResult();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L81C41-L81C86)

<pre><code class="java">      @Override
      protected boolean removeEldestEntry(Map.Entry&lt;K, SizedValue&gt; eldest) {
        if (estimatedSizeBytes.get() &lt;= <strong>LinkedHashLruCache.this.estimatedMaxSizeBytes</strong>) {
          return false;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L122C12-L122C33)

<pre><code class="java">
  protected long estimatedMaxSizeBytes() {
    return <strong>estimatedMaxSizeBytes</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L337C18-L337C33)

<pre><code class="java">
    PeriodicCleaner start() {
      checkState(<strong>scheduledFuture</strong> == null, "cleaning task can be started only once");
      this.scheduledFuture =
          ses.scheduleAtFixedRate(new CleaningTask(), interval, interval, intervalUnit);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L338C7-L339C88)

<pre><code class="java">    PeriodicCleaner start() {
      checkState(scheduledFuture == null, "cleaning task can be started only once");
      <strong>this.scheduledFuture =</strong>
<strong>          ses.scheduleAtFixedRate(new CleaningTask(), interval, interval, intervalUnit)</strong>;
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L344C11-L344C26)

<pre><code class="java">
    void stop() {
      if (<strong>scheduledFuture</strong> != null) {
        scheduledFuture.cancel(false);
        scheduledFuture = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L345C9-L345C24)

<pre><code class="java">    void stop() {
      if (scheduledFuture != null) {
        <strong>scheduledFuture</strong>.cancel(false);
        scheduledFuture = null;
      }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L346C9-L346C31)

<pre><code class="java">      if (scheduledFuture != null) {
        scheduledFuture.cancel(false);
        <strong>scheduledFuture = null</strong>;
      }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L370C42-L370C52)

<pre><code class="java">    @Override
    public void onEviction(K key, SizedValue value, EvictionType cause) {
      estimatedSizeBytes.addAndGet(-1L * <strong>value.size</strong>);
      if (delegate != null) {
        delegate.onEviction(key, value.value, cause);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L408C24-L408C28)

<pre><code class="java">    public String toString() {
      return MoreObjects.toStringHelper(this)
          .add("size", <strong>size</strong>)
          .add("value", value)
          .toString();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L116C25-L116C37)

<pre><code class="java">
    GrpcLogEntry.Builder newTimestampedBuilder() {
      long epochNanos = <strong>timeProvider</strong>.currentTimeNanos();
      return GrpcLogEntry.newBuilder().setTimestamp(Timestamps.fromNanos(epochNanos));
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L145C24-L145C34)

<pre><code class="java">      io.grpc.binarylog.v1.ClientHeader.Builder clientHeaderBuilder
          = io.grpc.binarylog.v1.ClientHeader.newBuilder()
          .setMetadata(<strong>pair.proto</strong>)
          .setMethodName("/" + methodName);
      if (timeout != null) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L158C32-L158C46)

<pre><code class="java">          .setType(EventType.EVENT_TYPE_CLIENT_HEADER)
          .setClientHeader(clientHeaderBuilder)
          .setPayloadTruncated(<strong>pair.truncated</strong>)
          .setLogger(logger)
          .setCallId(callId);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L187C32-L187C46)

<pre><code class="java">              io.grpc.binarylog.v1.ServerHeader.newBuilder()
                  .setMetadata(pair.proto))
          .setPayloadTruncated(<strong>pair.truncated</strong>)
          .setLogger(logger)
          .setCallId(callId);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L186C32-L186C42)

<pre><code class="java">          .setServerHeader(
              io.grpc.binarylog.v1.ServerHeader.newBuilder()
                  .setMetadata(<strong>pair.proto</strong>))
          .setPayloadTruncated(pair.truncated)
          .setLogger(logger)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L214C24-L214C34)

<pre><code class="java">          = io.grpc.binarylog.v1.Trailer.newBuilder()
          .setStatusCode(status.getCode().value())
          .setMetadata(<strong>pair.proto</strong>);
      String statusDescription = status.getDescription();
      if (statusDescription != null) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L228C32-L228C46)

<pre><code class="java">          .setType(EventType.EVENT_TYPE_SERVER_TRAILER)
          .setTrailer(trailerBuilder)
          .setPayloadTruncated(<strong>pair.truncated</strong>)
          .setLogger(logger)
          .setCallId(callId);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L257C32-L257C46)

<pre><code class="java">          .setType(eventType)
          .setMessage(pair.proto)
          .setPayloadTruncated(<strong>pair.truncated</strong>)
          .setLogger(logger)
          .setCallId(callId);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L256C23-L256C33)

<pre><code class="java">          .setSequenceIdWithinCall(seq)
          .setType(eventType)
          .setMessage(<strong>pair.proto</strong>)
          .setPayloadTruncated(pair.truncated)
          .setLogger(logger)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L438C21-L438C49)

<pre><code class="java">                  @Override
                  public void onHeaders(Metadata headers) {
                    <strong>trailersOnlyResponse = false</strong>;
                    writer.logServerHeader(
                        seq.getAndIncrement(),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L450C42-L450C62)

<pre><code class="java">                  @Override
                  public void onClose(Status status, Metadata trailers) {
                    SocketAddress peer = <strong>trailersOnlyResponse</strong>
                        ? getPeerSocket(getAttributes()) : null;
                    writer.logTrailer(
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L81C9-L81C17)

<pre><code class="java">   */
  public CallMetricRecorder recordUtilizationMetric(String name, double value) {
    if (<strong>disabled</strong> || !MetricRecorderHelper.isUtilizationValid(value)) {
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L120C9-L120C17)

<pre><code class="java">   */
  public CallMetricRecorder recordRequestCostMetric(String name, double value) {
    if (<strong>disabled</strong>) {
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L141C9-L141C17)

<pre><code class="java">   */
  public CallMetricRecorder recordNamedMetric(String name, double value) {
    if (<strong>disabled</strong>) {
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L163C9-L163C17)

<pre><code class="java">   */
  public CallMetricRecorder recordCpuUtilizationMetric(double value) {
    if (<strong>disabled</strong> || !MetricRecorderHelper.isCpuOrApplicationUtilizationValid(value)) {
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L166C5-L166C33)

<pre><code class="java">      return this;
    }
    <strong>cpuUtilizationMetric = value</strong>;
    return this;
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L179C9-L179C17)

<pre><code class="java">   */
  public CallMetricRecorder recordApplicationUtilizationMetric(double value) {
    if (<strong>disabled</strong> || !MetricRecorderHelper.isCpuOrApplicationUtilizationValid(value)) {
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L182C5-L182C41)

<pre><code class="java">      return this;
    }
    <strong>applicationUtilizationMetric = value</strong>;
    return this;
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L196C9-L196C17)

<pre><code class="java">   */
  public CallMetricRecorder recordMemoryUtilizationMetric(double value) {
    if (<strong>disabled</strong> || !MetricRecorderHelper.isUtilizationValid(value)) {
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L199C5-L199C36)

<pre><code class="java">      return this;
    }
    <strong>memoryUtilizationMetric = value</strong>;
    return this;
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L213C9-L213C17)

<pre><code class="java">   */
  public CallMetricRecorder recordQpsMetric(double value) {
    if (<strong>disabled</strong> || !MetricRecorderHelper.isRateValid(value)) {
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L216C5-L216C16)

<pre><code class="java">      return this;
    }
    <strong>qps = value</strong>;
    return this;
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L229C9-L229C17)

<pre><code class="java">   */
  public CallMetricRecorder recordEpsMetric(double value) {
    if (<strong>disabled</strong> || !MetricRecorderHelper.isRateValid(value)) {
      return this;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L232C5-L232C16)

<pre><code class="java">      return this;
    }
    <strong>eps = value</strong>;
    return this;
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L244C5-L244C20)

<pre><code class="java">   */
  Map&lt;String, Double&gt; finalizeAndDump() {
    <strong>disabled = true</strong>;
    Map&lt;String, Double&gt; savedMetrics = requestCostMetrics.get();
    if (savedMetrics == null) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L268C29-L268C49)

<pre><code class="java">      savedNamedMetrics = Collections.emptyMap();
    }
    return new MetricReport(<strong>cpuUtilizationMetric</strong>, applicationUtilizationMetric,
        memoryUtilizationMetric, qps, eps, Collections.unmodifiableMap(savedRequestCostMetrics),
        Collections.unmodifiableMap(savedUtilizationMetrics),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L268C51-L268C79)

<pre><code class="java">      savedNamedMetrics = Collections.emptyMap();
    }
    return new MetricReport(cpuUtilizationMetric, <strong>applicationUtilizationMetric</strong>,
        memoryUtilizationMetric, qps, eps, Collections.unmodifiableMap(savedRequestCostMetrics),
        Collections.unmodifiableMap(savedUtilizationMetrics),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L269C9-L269C32)

<pre><code class="java">    }
    return new MetricReport(cpuUtilizationMetric, applicationUtilizationMetric,
        <strong>memoryUtilizationMetric</strong>, qps, eps, Collections.unmodifiableMap(savedRequestCostMetrics),
        Collections.unmodifiableMap(savedUtilizationMetrics),
        Collections.unmodifiableMap(savedNamedMetrics)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L269C34-L269C37)

<pre><code class="java">    }
    return new MetricReport(cpuUtilizationMetric, applicationUtilizationMetric,
        memoryUtilizationMetric, <strong>qps</strong>, eps, Collections.unmodifiableMap(savedRequestCostMetrics),
        Collections.unmodifiableMap(savedUtilizationMetrics),
        Collections.unmodifiableMap(savedNamedMetrics)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L269C39-L269C42)

<pre><code class="java">    }
    return new MetricReport(cpuUtilizationMetric, applicationUtilizationMetric,
        memoryUtilizationMetric, qps, <strong>eps</strong>, Collections.unmodifiableMap(savedRequestCostMetrics),
        Collections.unmodifiableMap(savedUtilizationMetrics),
        Collections.unmodifiableMap(savedNamedMetrics)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L277C12-L277C20)

<pre><code class="java">  @VisibleForTesting
  boolean isDisabled() {
    return <strong>disabled</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L284C5-L284C20)

<pre><code class="java">   */
  private CallMetricRecorder disable() {
    <strong>disabled = true</strong>;
    return this;
  }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L79C12-L79C25)

<pre><code class="java">  @Nullable
  public ObjectPool&lt;XdsClient&gt; get() {
    return <strong>xdsClientPool</strong>;
  }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L84C33-L84C46)

<pre><code class="java">  @Override
  public ObjectPool&lt;XdsClient&gt; getOrCreate() throws XdsInitializationException {
    ObjectPool&lt;XdsClient&gt; ref = <strong>xdsClientPool</strong>;
    if (ref == null) {
      synchronized (lock) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java#L373C14-L373C32)

<pre><code class="java">    public synchronized void recordBackendLoadMetricStats(Map&lt;String, Double&gt; namedMetrics) {
      namedMetrics.forEach((name, value) -&gt; {
        if (!<strong>loadMetricStatsMap</strong>.containsKey(name)) {
          loadMetricStatsMap.put(name, new BackendLoadMetricStats(1, value));
        } else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java#L374C11-L374C29)

<pre><code class="java">      namedMetrics.forEach((name, value) -&gt; {
        if (!loadMetricStatsMap.containsKey(name)) {
          <strong>loadMetricStatsMap</strong>.put(name, new BackendLoadMetricStats(1, value));
        } else {
          loadMetricStatsMap.get(name).addMetricValueAndIncrementRequestsFinished(value);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java#L376C11-L376C29)

<pre><code class="java">          loadMetricStatsMap.put(name, new BackendLoadMetricStats(1, value));
        } else {
          <strong>loadMetricStatsMap</strong>.get(name).addMetricValueAndIncrementRequestsFinished(value);
        }
      });
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L115C7-L115C17)

<pre><code class="java">    /** Increment refCount and acquire a reference to value. */
    V acquire() {
      <strong>refCount++</strong>;
      return value;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L115C7-L115C15)

<pre><code class="java">    /** Increment refCount and acquire a reference to value. */
    V acquire() {
      <strong>refCount</strong>++;
      return value;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L121C18-L121C26)

<pre><code class="java">    /** Decrement refCount and return true if it has reached 0. */
    boolean release() {
      checkState(<strong>refCount</strong> &gt; 0, "refCount has to be &gt; 0");
      return --refCount == 0;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L122C14-L122C24)

<pre><code class="java">    boolean release() {
      checkState(refCount &gt; 0, "refCount has to be &gt; 0");
      return <strong>--refCount</strong> == 0;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L122C16-L122C24)

<pre><code class="java">    boolean release() {
      checkState(refCount &gt; 0, "refCount has to be &gt; 0");
      return --<strong>refCount</strong> == 0;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

| e |  |
| --- | --- |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L195C9-L195C82) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L205C9-L205C48) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L215C9-L215C52) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L223C31-L223C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`previousAttempts`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L223C44-L223C59) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`isTransparentRetry`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L223C62-L223C79) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`isCancelled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L211C12-L211C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L212C9-L212C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L237C7-L237C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runnable.hasStarted`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L246C16-L246C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runnable.isCancelled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L246C39-L246C58) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`this.transportState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L273C12-L273C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`transportState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L283C21-L283C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L284C5-L284C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L290C5-L290C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L307C7-L307C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`outgoingBinder`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L333C39-L333C52) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`outgoingBinder`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L349C9-L349C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`outgoingBinder`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L351C9-L351C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`outgoingBinder`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L358C9-L358C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`outgoingBinder`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L403C7-L403C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`acknowledgedIncomingBytes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L484C18-L484C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`transportState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L505C9-L505C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`outgoingBinder`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L508C9-L508C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L522C5-L522C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L690C9-L690C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L715C7-L715C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L722C9-L722C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L725C7-L725C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L732C7-L732C71) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`attributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L732C37-L732C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L890C11-L890C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L891C9-L891C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`attributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L909C46-L909C55) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`reportedState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L125C9-L125C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L126C7-L126C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`reportedState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L136C9-L136C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L137C7-L137C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L255C5-L255C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`activeTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L196C38-L196C52) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L203C13-L203C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`activeTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L218C12-L218C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`reconnectTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L231C30-L231C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L255C5-L255C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L260C5-L260C48) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L262C5-L262C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`transportLogger.logId`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L268C70-L268C90) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`reconnectPolicy`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L294C9-L294C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L282C9-L282C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`reconnectPolicy`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L290C9-L290C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L291C7-L291C51) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`reconnectTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L299C30-L299C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L300C5-L304C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L315C13-L315C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L335C9-L335C13) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L336C32-L336C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L338C7-L338C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L357C9-L357C49) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L358C13-L358C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L358C42-L358C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L361C17-L361C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`activeTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L362C32-L362C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L363C15-L363C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L367C15-L367C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L370C15-L370C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownDueToUpdateTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L377C15-L377C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownDueToUpdateTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L380C13-L380C40) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownDueToUpdateTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L383C13-L383C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L384C13-L384C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L385C13-L385C47) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L389C11-L389C55) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L390C11-L403C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownDueToUpdateTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L393C54-L393C81) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L394C19-L394C48) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L395C19-L395C53) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L415C13-L415C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L418C9-L418C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`activeTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L419C32-L419C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L420C33-L420C48) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L421C9-L421C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L422C9-L422C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownDueToUpdateTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L429C13-L429C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownDueToUpdateTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L430C11-L430C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownDueToUpdateTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L431C11-L431C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L432C11-L432C40) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L433C11-L433C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L451C31-L451C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L491C12-L491C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`reconnectTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L497C9-L497C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`reconnectTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L498C7-L498C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L499C7-L499C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L500C7-L500C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L529C12-L529C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L562C11-L562C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownReason`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L563C15-L563C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`activeTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L565C38-L565C52) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownReason`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L567C32-L567C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L568C22-L568C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L569C13-L569C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L570C13-L570C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L586C7-L586C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L590C15-L590C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`activeTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L593C15-L593C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L594C13-L594C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingTransport`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L597C22-L597C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L598C38-L598C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L599C69-L599C73) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L603C15-L603C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownInitiated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L619C11-L619C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L631C15-L631C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`groupIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L729C14-L729C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L729C27-L729C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`groupIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L733C14-L733C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L733C33-L733C44) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L737C38-L737C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`groupIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L737C56-L737C65) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L738C7-L738C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L738C7-L738C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L739C11-L739C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L740C9-L740C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`groupIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L740C9-L740C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L741C9-L741C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L746C7-L746C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L747C7-L747C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L751C63-L751C74) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L751C14-L751C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`groupIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L751C32-L751C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L755C14-L755C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`groupIndex`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L755C32-L755C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L759C14-L759C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L764C7-L764C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L770C27-L770C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L771C40-L771C52) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L776C9-L776C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L777C9-L777C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`logId`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L803C33-L803C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`logId`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L808C33-L808C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownNowed`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L315C9-L315C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L365C11-L365C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`nameResolverStarted`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L376C18-L376C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L377C18-L377C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`nameResolver`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L379C9-L379C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`nameResolver`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L380C7-L380C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L381C7-L381C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L383C9-L385C62) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L387C9-L387C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L390C9-L390C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper.lb`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L391C7-L391C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L391C7-L391C14) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L392C7-L392C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L394C5-L394C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`nameResolver`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L428C72-L428C83) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`panicMode`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L405C27-L405C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L417C9-L417C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L422C5-L422C63) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L425C5-L425C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`nameResolver`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L429C5-L429C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L430C5-L430C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`nameResolverStarted`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L470C9-L470C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`nameResolver`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L471C7-L471C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannelPicker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L479C37-L479C52) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdownNowed`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L850C13-L850C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L853C9-L853C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`panicMode`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L865C9-L865C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L869C5-L869C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`panicMode`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L898C12-L898C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L903C5-L903C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L919C12-L919C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L962C13-L962C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1021C17-L1021C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1022C15-L1022C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1025C13-L1025C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1038C53-L1038C64) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1039C58-L1039C69) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1056C15-L1056C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1075C15-L1075C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1076C62-L1076C73) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1141C15-L1141C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1142C13-L1142C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pendingCalls`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1143C17-L1143C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1145C15-L1145C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`delegate`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1204C14-L1204C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1210C77-L1210C87) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1216C9-L1216C54) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1223C9-L1223C72) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1223C23-L1223C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1226C9-L1226C74) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1226C54-L1226C64) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1228C9-L1228C55) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1228C44-L1228C54) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`delegate`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1230C7-L1230C14) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`delegate`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1251C11-L1251C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`delegate`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1252C9-L1252C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1285C9-L1285C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1297C7-L1297C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannelPicker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1318C15-L1318C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannelPicker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1319C13-L1319C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1321C15-L1321C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper.lb`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1322C13-L1322C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1322C13-L1322C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`nameResolverStarted`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1352C13-L1352C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1372C31-L1372C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminating`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1473C19-L1473C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1486C36-L1486C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1525C19-L1525C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminating`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1589C15-L1589C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1592C16-L1592C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1663C19-L1663C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`ManagedChannelImpl.this.nameResolver`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1757C15-L1757C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lastResolutionState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1768C15-L1768C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1770C13-L1770C57) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serviceConfigUpdated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1822C20-L1822C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lastServiceConfig`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1837C42-L1837C58) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lastServiceConfig`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1843C48-L1843C64) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1848C15-L1848C56) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1849C15-L1849C86) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1856C15-L1856C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`ManagedChannelImpl.this.lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1867C51-L1867C82) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`helper.lb`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1879C46-L1879C54) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lastResolutionState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1913C11-L1913C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1915C9-L1915C51) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`ManagedChannelImpl.this.lbHelper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1918C47-L1918C78) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`helper.lb`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1922C7-L1922C15) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`started`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1956C19-L1956C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1957C19-L1957C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminating`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1958C19-L1958C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1959C7-L1959C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2010C7-L2010C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`started`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2017C18-L2017C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2018C14-L2018C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2024C11-L2024C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2026C9-L2026C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2029C11-L2029C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminating`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2030C13-L2030C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`delayedShutdownTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2030C28-L2030C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`delayedShutdownTask`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2033C11-L2033C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2034C11-L2034C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2040C9-L2040C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`terminating`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2050C12-L2050C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2054C13-L2054C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2058C9-L2061C59) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2066C7-L2066C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`started`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2072C18-L2072C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2073C7-L2073C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`started`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2079C18-L2079C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2080C14-L2080C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`started`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2095C18-L2095C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2097C11-L2097C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`started`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2105C18-L2105C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2106C14-L2106C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2117C7-L2117C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2121C7-L2121C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2172C7-L2172C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannelImpl`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L125C11-L125C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L151C5-L151C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L152C5-L182C5) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L200C5-L200C48) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannelPicker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L201C32-L201C47) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L205C5-L205C14) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L233C9-L233C18) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L236C12-L236C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L241C5-L241C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L248C12-L248C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L253C5-L253C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannelPicker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L269C36-L269C51) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannelImpl`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L306C12-L306C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L310C12-L310C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L321C19-L321C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L322C70-L322C79) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L342C5-L342C14) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getValue(...).num`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L121C28-L121C47) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L133C7-L133C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L138C7-L138C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L143C7-L143C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`headersSent`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L149C12-L149C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`anythingReceived`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L152C11-L152C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L77C5-L77C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L78C5-L78C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L119C5-L119C53) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`scheduler`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L119C44-L119C52) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L128C11-L128C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L133C11-L133C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`attributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L338C12-L338C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverScheduler`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L343C12-L343C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L465C46-L465C65) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L491C44-L491C63) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L501C17-L501C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L529C44-L529C63) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L575C42-L575C61) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L623C23-L623C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`clientStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L662C19-L662C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverStreamAttributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L683C16-L683C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`InProcessStream.this.authority`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L688C16-L688C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L743C46-L743C65) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L769C44-L769C63) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L774C44-L774C63) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L800C44-L800C63) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L850C42-L850C61) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`serverStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L863C44-L863C63) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L876C9-L876C47) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`attributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L895C16-L895C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`message`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L961C37-L961C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L962C7-L962C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L348C5-L349C75) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L386C7-L386C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L387C7-L387C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`picker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L395C15-L395C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L397C34-L397C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`picker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L397C41-L397C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L405C44-L405C48) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`picker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L405C51-L405C56) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`scheduledFuture`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L700C14-L700C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`scheduledFuture`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L705C7-L705C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L734C7-L734C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L739C7-L739C74) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L744C7-L744C59) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L753C7-L754C72) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L759C7-L759C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L765C7-L765C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L770C7-L770C63) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`helper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L776C7-L776C12) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`prevState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L882C11-L882C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L895C7-L895C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`fallbackChildPolicyWrapper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L968C33-L968C58) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`LinkedHashLruCache<>.this.estimatedMaxSizeBytes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L81C41-L81C85) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`estimatedMaxSizeBytes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L122C12-L122C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`scheduledFuture`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L337C18-L337C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L338C7-L339C87) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`scheduledFuture`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L344C11-L344C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`scheduledFuture`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L345C9-L345C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L346C9-L346C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`value.size`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L370C42-L370C51) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`size`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L408C24-L408C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`timeProvider`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L116C25-L116C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pair.proto`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L145C24-L145C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pair.truncated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L158C32-L158C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pair.truncated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L187C32-L187C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pair.proto`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L186C32-L186C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pair.proto`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L214C24-L214C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pair.truncated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L228C32-L228C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pair.truncated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L257C32-L257C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pair.proto`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L256C23-L256C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L438C21-L438C48) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`trailersOnlyResponse`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L450C42-L450C61) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L81C9-L81C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L120C9-L120C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L141C9-L141C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L163C9-L163C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L166C5-L166C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L179C9-L179C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L182C5-L182C40) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L196C9-L196C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L199C5-L199C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L213C9-L213C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L216C5-L216C15) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L229C9-L229C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L232C5-L232C15) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L244C5-L244C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`cpuUtilizationMetric`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L268C29-L268C48) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`applicationUtilizationMetric`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L268C51-L268C78) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`memoryUtilizationMetric`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L269C9-L269C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`qps`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L269C34-L269C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`eps`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L269C39-L269C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L277C12-L277C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L284C5-L284C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`xdsClientPool`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L79C12-L79C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`xdsClientPool`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L84C33-L84C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`loadMetricStatsMap`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java#L373C14-L373C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`loadMetricStatsMap`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java#L374C11-L374C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`loadMetricStatsMap`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java#L376C11-L376C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L115C7-L115C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`refCount`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L115C7-L115C14) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`refCount`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L121C18-L121C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`--...`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L122C14-L122C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`refCount`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L122C16-L122C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |