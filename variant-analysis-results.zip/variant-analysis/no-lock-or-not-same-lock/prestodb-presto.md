### prestodb/presto

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L89C16-L89C38)

<pre><code class="java">    {
        assureLoaded();
        return <strong>lazilyLoadedParentType</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L118C16-L118C58)

<pre><code class="java">        // This way, we can avoid loading of parents which are not needed.
        seenTypes.put(firstAncestor.get().getName(), firstAncestor.get());
        while (<strong>firstAncestor.get().lazilyLoadedParentType</strong>.isPresent()) {
            firstAncestor = firstAncestor.get().lazilyLoadedParentType;
            seenTypes.put(firstAncestor.get().getName(), firstAncestor.get());
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L119C29-L119C71)

<pre><code class="java">        seenTypes.put(firstAncestor.get().getName(), firstAncestor.get());
        while (firstAncestor.get().lazilyLoadedParentType.isPresent()) {
            firstAncestor = <strong>firstAncestor.get().lazilyLoadedParentType</strong>;
            seenTypes.put(firstAncestor.get().getName(), firstAncestor.get());
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L128C16-L128C59)

<pre><code class="java">        seenTypes.put(secondAncestor.get().getName(), secondAncestor.get());

        while (<strong>secondAncestor.get().lazilyLoadedParentType</strong>.isPresent()) {
            secondAncestor = secondAncestor.get().lazilyLoadedParentType;
            if (seenTypes.containsKey(secondAncestor.get().getName())) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L129C30-L129C73)

<pre><code class="java">
        while (secondAncestor.get().lazilyLoadedParentType.isPresent()) {
            secondAncestor = <strong>secondAncestor.get().lazilyLoadedParentType</strong>;
            if (seenTypes.containsKey(secondAncestor.get().getName())) {
                return secondAncestor;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L190C18-L190C45)

<pre><code class="java">            // We only populate type signature with already loaded parent types, this helps avoid
            // loading information about all ancestors.
            if (!<strong>type.lazilyLoadedParentType</strong>.isPresent()) {
                lastAncestor = parentTypeName;
                break;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L195C24-L195C51)

<pre><code class="java">            }
            else {
                type = <strong>type.lazilyLoadedParentType</strong>.get();
                checkState(parentTypeName.isPresent(), "parentTypeName is empty");
                ancestors.add(parentTypeName.get());
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L368C14-L368C32)

<pre><code class="java">    {
        // If type has no parent, or the parent type is already loaded, we don't need to do anything.
        if (!<strong>distinctTypeLoader</strong>.isPresent()) {
            return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L291C21-L291C36)

<pre><code class="java">            private double getDeltaPerSecond(long taskAgeInMillis, long value)
            {
                if (<strong>previousTaskAge</strong> == 0 &amp;&amp; value &gt; 0) {
                    previousTaskAge = taskAgeInMillis;
                    previousValue = value;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L292C21-L292C54)

<pre><code class="java">            {
                if (previousTaskAge == 0 &amp;&amp; value &gt; 0) {
                    <strong>previousTaskAge = taskAgeInMillis</strong>;
                    previousValue = value;
                    return 0;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L293C21-L293C42)

<pre><code class="java">                if (previousTaskAge == 0 &amp;&amp; value &gt; 0) {
                    previousTaskAge = taskAgeInMillis;
                    <strong>previousValue = value</strong>;
                    return 0;
                }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L297C40-L297C55)

<pre><code class="java">                }

                if (taskAgeInMillis &lt;= <strong>previousTaskAge</strong>) {
                    return 0;
                }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L302C50-L302C63)

<pre><code class="java">
                if (value &gt; 0) {
                    double deltaValue = (value - <strong>previousValue</strong>) * 100;
                    long deltaDuration = taskAgeInMillis - previousTaskAge;
                    previousTaskAge = taskAgeInMillis;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L303C60-L303C75)

<pre><code class="java">                if (value &gt; 0) {
                    double deltaValue = (value - previousValue) * 100;
                    long deltaDuration = taskAgeInMillis - <strong>previousTaskAge</strong>;
                    previousTaskAge = taskAgeInMillis;
                    previousValue = value;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L304C21-L304C54)

<pre><code class="java">                    double deltaValue = (value - previousValue) * 100;
                    long deltaDuration = taskAgeInMillis - previousTaskAge;
                    <strong>previousTaskAge = taskAgeInMillis</strong>;
                    previousValue = value;
                    return deltaValue &gt; 0 ? deltaValue / deltaDuration : 0;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L305C21-L305C42)

<pre><code class="java">                    long deltaDuration = taskAgeInMillis - previousTaskAge;
                    previousTaskAge = taskAgeInMillis;
                    <strong>previousValue = value</strong>;
                    return deltaValue &gt; 0 ? deltaValue / deltaDuration : 0;
                }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L598C21-L598C46)

<pre><code class="java">            if (isRecoverable(taskStatus.getFailures())) {
                try {
                    <strong>stageTaskRecoveryCallback</strong>.get().recover(taskId);
                    finishedTasks.add(taskId);
                }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L640C16-L640C41)

<pre><code class="java">            }
        }
        return <strong>stageTaskRecoveryCallback</strong>.isPresent() &amp;&amp;
                failedTasks.size() &lt; allTasks.size() * maxFailedTaskPercentage;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/StateMachine.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/StateMachine.java#L93C16-L93C21)

<pre><code class="java">    public T get()
    {
        return <strong>state</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L602C25-L602C31)

<pre><code class="java">        {
            try (SetThreadName runnerName = new SetThreadName("SplitRunner-%s", runnerId)) {
                while (!<strong>closed</strong> &amp;&amp; !Thread.currentThread().isInterrupted()) {
                    // select next worker
                    final PrioritizedSplitRunner split;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L667C33-L667C39)

<pre><code class="java">                        // without TaskExecutor being shut down
                        if (Thread.interrupted()) {
                            if (<strong>closed</strong>) {
                                // reset interrupted flag if TaskExecutor was closed, since that interrupt may have been the
                                // shutdown signal to this TaskRunner thread
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L678C22-L678C28)

<pre><code class="java">            finally {
                // unless we have been closed, we need to replace this thread
                if (!<strong>closed</strong>) {
                    addRunnerThread();
                }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L1026C20-L1026C27)

<pre><code class="java">        public boolean isPrinted()
        {
            return <strong>printed</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L1031C13-L1031C27)

<pre><code class="java">        public void setPrinted()
        {
            <strong>printed = true</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L1063C9-L1063C35)

<pre><code class="java">    public void setLowMemory(boolean lowMemory)
    {
        <strong>this.lowMemory = lowMemory</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L1068C16-L1068C30)

<pre><code class="java">    public boolean isLowMemory()
    {
        return <strong>this.lowMemory</strong>;
    }
}
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java#L85C16-L85C25)

<pre><code class="java">    public boolean isDestroyed()
    {
        return <strong>destroyed</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L863C72-L863C136)

<pre><code class="java">                }
                Optional&lt;ResourceGroupRuntimeInfo&gt; resourceGroupRuntimeInfo = getAdditionalRuntimeInfo();
                resourceGroupRuntimeInfo.ifPresent(groupRuntimeInfo -&gt; <strong>cachedMemoryUsageBytes += groupRuntimeInfo.getMemoryUsageBytes()</strong>);
            }
            else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L863C72-L863C94)

<pre><code class="java">                }
                Optional&lt;ResourceGroupRuntimeInfo&gt; resourceGroupRuntimeInfo = getAdditionalRuntimeInfo();
                resourceGroupRuntimeInfo.ifPresent(groupRuntimeInfo -&gt; <strong>cachedMemoryUsageBytes</strong> += groupRuntimeInfo.getMemoryUsageBytes());
            }
            else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L944C13-L944C29)

<pre><code class="java">    private void addOrUpdateSubGroup(Queue&lt;InternalResourceGroup&gt; queue, InternalResourceGroup group)
    {
        if (<strong>schedulingPolicy</strong> == WEIGHTED_FAIR) {
            ((WeightedFairQueue&lt;InternalResourceGroup&gt;) queue).addOrUpdate(group, new Usage(group.getSchedulingWeight(), group.getAggregatedRunningQueries()));
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L948C119-L948C135)

<pre><code class="java">        }
        else {
            ((UpdateablePriorityQueue&lt;InternalResourceGroup&gt;) queue).addOrUpdate(group, getSubGroupSchedulingPriority(<strong>schedulingPolicy</strong>, group));
        }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L954C29-L954C46)

<pre><code class="java">    private void addOrUpdateSubGroup(InternalResourceGroup group)
    {
        addOrUpdateSubGroup(<strong>eligibleSubGroups</strong>, group);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L969C46-L969C66)

<pre><code class="java">    private long computeSchedulingWeight()
    {
        if (getAggregatedRunningQueries() &gt;= <strong>softConcurrencyLimit</strong>) {
            return schedulingWeight;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L970C20-L970C36)

<pre><code class="java">    {
        if (getAggregatedRunningQueries() &gt;= softConcurrencyLimit) {
            return <strong>schedulingWeight</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L973C43-L973C59)

<pre><code class="java">        }

        return (long) Integer.MAX_VALUE * <strong>schedulingWeight</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java#L67C44-L67C55)

<pre><code class="java">            log.warn("Memory leak of %s detected. The following queries are already finished, " +
                    "but they have memory reservations on some worker node(s): %s",
                    DataSize.succinctBytes(<strong>leakedBytes</strong>), leakedQueryReservations);
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L158C16-L158C39)

<pre><code class="java">    public boolean isMemoryLimitsInitialized()
    {
        return <strong>memoryLimitsInitialized</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L337C16-L337C29)

<pre><code class="java">    public long getMaxUserMemory()
    {
        return <strong>maxUserMemory</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L342C16-L342C30)

<pre><code class="java">    public long getMaxTotalMemory()
    {
        return <strong>maxTotalMemory</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L502C21-L502C57)

<pre><code class="java">            throw exceededLocalUserMemoryLimit(succinctBytes(maxMemory),
                    getAdditionalFailureInfo(allocated, delta, allocationTag),
                    <strong>heapDumpOnExceededMemoryLimitEnabled</strong>,
                    heapDumpFilePath,
                    getErrorCause());
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L503C21-L503C37)

<pre><code class="java">                    getAdditionalFailureInfo(allocated, delta, allocationTag),
                    heapDumpOnExceededMemoryLimitEnabled,
                    <strong>heapDumpFilePath</strong>,
                    getErrorCause());
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L523C9-L523C73)

<pre><code class="java">    {
        long totalMemory = allocated + delta;
        <strong>peakNodeTotalMemory = Math.max(totalMemory, peakNodeTotalMemory)</strong>;
        if (totalMemory &gt; maxMemory) {
            throw exceededLocalTotalMemoryLimit(succinctBytes(maxMemory),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L523C53-L523C72)

<pre><code class="java">    {
        long totalMemory = allocated + delta;
        peakNodeTotalMemory = Math.max(totalMemory, <strong>peakNodeTotalMemory</strong>);
        if (totalMemory &gt; maxMemory) {
            throw exceededLocalTotalMemoryLimit(succinctBytes(maxMemory),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L527C21-L527C57)

<pre><code class="java">            throw exceededLocalTotalMemoryLimit(succinctBytes(maxMemory),
                    getAdditionalFailureInfo(allocated, delta, allocationTag),
                    <strong>heapDumpOnExceededMemoryLimitEnabled</strong>,
                    heapDumpFilePath,
                    getErrorCause());
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L528C21-L528C37)

<pre><code class="java">                    getAdditionalFailureInfo(allocated, delta, allocationTag),
                    heapDumpOnExceededMemoryLimitEnabled,
                    <strong>heapDumpFilePath</strong>,
                    getErrorCause());
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L537C138-L537C174)

<pre><code class="java">    {
        if (allocated + delta &gt; maxMemory) {
            throw exceededLocalRevocableMemoryLimit(succinctBytes(maxMemory), getAdditionalFailureInfo(allocated, delta, allocationTag), <strong>heapDumpOnExceededMemoryLimitEnabled</strong>, heapDumpFilePath);
        }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L537C176-L537C192)

<pre><code class="java">    {
        if (allocated + delta &gt; maxMemory) {
            throw exceededLocalRevocableMemoryLimit(succinctBytes(maxMemory), getAdditionalFailureInfo(allocated, delta, allocationTag), heapDumpOnExceededMemoryLimitEnabled, <strong>heapDumpFilePath</strong>);
        }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L544C46-L544C56)

<pre><code class="java">    public String getAdditionalFailureInfo(long allocated, long delta, String allocationTag)
    {
        Map&lt;String, Long&gt; queryAllocations = <strong>memoryPool</strong>.getTaggedMemoryAllocations(queryId);

        String additionalInfo;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L568C13-L568C52)

<pre><code class="java">        String message = format("%s, Top Consumers: %s", additionalInfo, topConsumers);

        if (<strong>verboseExceededMemoryLimitErrorsEnabled</strong>) {
            List&lt;TaskMemoryReservationSummary&gt; memoryReservationSummaries = getTaskMemoryReservationSummaries();
            message += ", Details: " + memoryReservationSummaryJsonCodec.toJson(memoryReservationSummaries);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java#L1101C16-L1101C25)

<pre><code class="java">    public Collection&lt;SqlFunction&gt; listFunctions(Optional&lt;String&gt; likePattern, Optional&lt;String&gt; escape)
    {
        return <strong>functions</strong>.list();
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java#L1107C16-L1107C25)

<pre><code class="java">    public Collection&lt;SqlFunction&gt; getFunctions(Optional&lt;? extends FunctionNamespaceTransactionHandle&gt; transactionHandle, QualifiedObjectName functionName)
    {
        return <strong>functions</strong>.get(functionName);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L564C31-L564C39)

<pre><code class="java">        public void update(long value)
        {
            double newValue = <strong>oldValue</strong> + (alpha * (value - oldValue));
            oldValue = newValue;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L564C60-L564C68)

<pre><code class="java">        public void update(long value)
        {
            double newValue = oldValue + (alpha * (value - <strong>oldValue</strong>));
            oldValue = newValue;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L565C13-L565C32)

<pre><code class="java">        {
            double newValue = oldValue + (alpha * (value - oldValue));
            <strong>oldValue = newValue</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L570C27-L570C35)

<pre><code class="java">        public long get()
        {
            return (long) <strong>oldValue</strong>;
        }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L124C25-L124C31)

<pre><code class="java">        public HashBuilderOperator createOperator(DriverContext driverContext)
        {
            checkState(!<strong>closed</strong>, "Factory is already closed");
            OperatorContext operatorContext = driverContext.addOperatorContext(operatorId, planNodeId, HashBuilderOperator.class.getSimpleName());

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L144C21-L144C48)

<pre><code class="java">                    spillEnabled,
                    singleStreamSpillerFactory,
                    <strong>enforceBroadcastMemoryLimit</strong>);
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L150C13-L150C26)

<pre><code class="java">        public void noMoreOperators()
        {
            <strong>closed = true</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L292C16-L292C21)

<pre><code class="java">    public State getState()
    {
        return <strong>state</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L298C17-L298C22)

<pre><code class="java">    public ListenableFuture&lt;?&gt; isBlocked()
    {
        switch (<strong>state</strong>) {
            case CONSUMING_INPUT:
                return NOT_BLOCKED;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L303C24-L303C39)

<pre><code class="java">
            case SPILLING_INPUT:
                return <strong>spillInProgress</strong>;

            case LOOKUP_SOURCE_BUILT:
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L306C24-L306C45)

<pre><code class="java">
            case LOOKUP_SOURCE_BUILT:
                return <strong>lookupSourceNotNeeded</strong>.orElseThrow(() -&gt; new IllegalStateException("Lookup source built, but disposal future not set"));

            case INPUT_SPILLED:
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L312C24-L312C41)

<pre><code class="java">
            case INPUT_UNSPILLING:
                return <strong>unspillInProgress</strong>.orElseThrow(() -&gt; new IllegalStateException("Unspilling in progress, but unspilling future not set"));

            case INPUT_UNSPILLED_AND_BUILT:
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L320C63-L320C68)

<pre><code class="java">                return NOT_BLOCKED;
        }
        throw new IllegalStateException("Unhandled state: " + <strong>state</strong>);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L326C36-L326C41)

<pre><code class="java">    public boolean needsInput()
    {
        boolean stateNeedsInput = (<strong>state</strong> == State.CONSUMING_INPUT)
                || (state == State.SPILLING_INPUT &amp;&amp; spillInProgress.isDone());

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L327C21-L327C26)

<pre><code class="java">    {
        boolean stateNeedsInput = (state == State.CONSUMING_INPUT)
                || (<strong>state</strong> == State.SPILLING_INPUT &amp;&amp; spillInProgress.isDone());

        return stateNeedsInput &amp;&amp; !lookupSourceFactoryDestroyed.isDone();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L327C54-L327C69)

<pre><code class="java">    {
        boolean stateNeedsInput = (state == State.CONSUMING_INPUT)
                || (state == State.SPILLING_INPUT &amp;&amp; <strong>spillInProgress</strong>.isDone());

        return stateNeedsInput &amp;&amp; !lookupSourceFactoryDestroyed.isDone();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L342C13-L342C18)

<pre><code class="java">        }

        if (<strong>state</strong> == State.SPILLING_INPUT) {
            spillInput(page);
            return;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L347C20-L347C25)

<pre><code class="java">        }

        checkState(<strong>state</strong> == State.CONSUMING_INPUT);
        updateIndex(page);
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L369C20-L369C35)

<pre><code class="java">    private void spillInput(Page page)
    {
        checkState(<strong>spillInProgress</strong>.isDone(), "Previous spill still in progress");
        checkSpillSucceeded(spillInProgress);
        long sizeOfPage = page.getSizeInBytes();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L370C29-L370C44)

<pre><code class="java">    {
        checkState(spillInProgress.isDone(), "Previous spill still in progress");
        checkSpillSucceeded(<strong>spillInProgress</strong>);
        long sizeOfPage = page.getSizeInBytes();

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L382C9-L382C51)

<pre><code class="java">        }

        <strong>spillInProgress = getSpiller().spill(page)</strong>;
        long retainedSizeOfPage = page.getRetainedSizeInBytes();
        log.debug("Spilling for operator %s, sizeOfPage %s, retainedSizeOfPage %s, totalSpilledBytes %s", operatorContext, sizeOfPage, retainedSizeOfPage, totalSpilledBytes);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L392C13-L392C18)

<pre><code class="java">        checkState(spillEnabled, "Spill not enabled, no revokable memory should be reserved");

        if (<strong>state</strong> == State.CONSUMING_INPUT) {
            long indexSizeBeforeCompaction = index.getEstimatedSize().toBytes();
            index.compact();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L397C17-L397C59)

<pre><code class="java">            long indexSizeAfterCompaction = index.getEstimatedSize().toBytes();
            if (indexSizeAfterCompaction &lt; indexSizeBeforeCompaction * INDEX_COMPACTION_ON_REVOCATION_TARGET) {
                <strong>finishMemoryRevoke = Optional.of(() -&gt; {})</strong>;
                return immediateFuture(null);
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L400C201-L400C206)

<pre><code class="java">                return immediateFuture(null);
            }
            log.debug("Memory Revoke started for operator %s, estimatedSizeIndex: %s, spilled bytes: %s ", operatorContext, index.getEstimatedSize().toBytes(), localRevocableMemoryContext.getBytes(), <strong>state</strong>);

            finishMemoryRevoke = Optional.of(() -&gt; {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L402C13-L410C15)

<pre><code class="java">            log.debug("Memory Revoke started for operator %s, estimatedSizeIndex: %s, spilled bytes: %s ", operatorContext, index.getEstimatedSize().toBytes(), localRevocableMemoryContext.getBytes(), state);

            <strong>finishMemoryRevoke = Optional.of(() -&gt; {</strong>
<strong>                index.clear();</strong>
<strong>                long estimatedIndexSize = index.getEstimatedSize().toBytes();</strong>
<strong>                log.debug("Done Revoking Memory for operator %s, estimatedIndexSize: %s, spilled bytes: %s, state: %s", operatorContext, estimatedIndexSize, localRevocableMemoryContext.getBytes(), state);</strong>
<strong>                localUserMemoryContext.setBytes(index.getEstimatedSize().toBytes(), enforceBroadcastMemoryLimit);</strong>
<strong>                localRevocableMemoryContext.setBytes(0);</strong>
<strong>                lookupSourceFactory.setPartitionSpilledLookupSourceHandle(partitionIndex, spilledLookupSourceHandle);</strong>
<strong>                state = State.SPILLING_INPUT;</strong>
<strong>            })</strong>;
            return spillIndex();
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L405C198-L405C203)

<pre><code class="java">                index.clear();
                long estimatedIndexSize = index.getEstimatedSize().toBytes();
                log.debug("Done Revoking Memory for operator %s, estimatedIndexSize: %s, spilled bytes: %s, state: %s", operatorContext, estimatedIndexSize, localRevocableMemoryContext.getBytes(), <strong>state</strong>);
                localUserMemoryContext.setBytes(index.getEstimatedSize().toBytes(), enforceBroadcastMemoryLimit);
                localRevocableMemoryContext.setBytes(0);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L409C17-L409C45)

<pre><code class="java">                localRevocableMemoryContext.setBytes(0);
                lookupSourceFactory.setPartitionSpilledLookupSourceHandle(partitionIndex, spilledLookupSourceHandle);
                <strong>state = State.SPILLING_INPUT</strong>;
            });
            return spillIndex();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L413C18-L413C23)

<pre><code class="java">            return spillIndex();
        }
        else if (<strong>state</strong> == State.LOOKUP_SOURCE_BUILT) {
            finishMemoryRevoke = Optional.of(() -&gt; {
                lookupSourceFactory.setPartitionSpilledLookupSourceHandle(partitionIndex, spilledLookupSourceHandle);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L414C13-L425C15)

<pre><code class="java">        }
        else if (state == State.LOOKUP_SOURCE_BUILT) {
            <strong>finishMemoryRevoke = Optional.of(() -&gt; {</strong>
<strong>                lookupSourceFactory.setPartitionSpilledLookupSourceHandle(partitionIndex, spilledLookupSourceHandle);</strong>
<strong>                lookupSourceNotNeeded = Optional.empty();</strong>
<strong>                index.clear();</strong>
<strong>                long estimatedIndexSize = index.getEstimatedSize().toBytes();</strong>
<strong>                log.debug("Done Revoking Memory for operator %s, estimatedIndexSize: %s, spilled bytes: %s, state %s", operatorContext, estimatedIndexSize, localRevocableMemoryContext.getBytes(), state);</strong>
<strong>                localUserMemoryContext.setBytes(index.getEstimatedSize().toBytes(), enforceBroadcastMemoryLimit);</strong>
<strong>                localRevocableMemoryContext.setBytes(0);</strong>
<strong>                lookupSourceChecksum = OptionalLong.of(lookupSourceSupplier.checksum());</strong>
<strong>                lookupSourceSupplier = null;</strong>
<strong>                state = State.INPUT_SPILLED;</strong>
<strong>            })</strong>;
            return spillIndex();
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L416C17-L416C57)

<pre><code class="java">            finishMemoryRevoke = Optional.of(() -&gt; {
                lookupSourceFactory.setPartitionSpilledLookupSourceHandle(partitionIndex, spilledLookupSourceHandle);
                <strong>lookupSourceNotNeeded = Optional.empty()</strong>;
                index.clear();
                long estimatedIndexSize = index.getEstimatedSize().toBytes();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L419C197-L419C202)

<pre><code class="java">                index.clear();
                long estimatedIndexSize = index.getEstimatedSize().toBytes();
                log.debug("Done Revoking Memory for operator %s, estimatedIndexSize: %s, spilled bytes: %s, state %s", operatorContext, estimatedIndexSize, localRevocableMemoryContext.getBytes(), <strong>state</strong>);
                localUserMemoryContext.setBytes(index.getEstimatedSize().toBytes(), enforceBroadcastMemoryLimit);
                localRevocableMemoryContext.setBytes(0);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L422C17-L422C88)

<pre><code class="java">                localUserMemoryContext.setBytes(index.getEstimatedSize().toBytes(), enforceBroadcastMemoryLimit);
                localRevocableMemoryContext.setBytes(0);
                <strong>lookupSourceChecksum = OptionalLong.of(lookupSourceSupplier.checksum())</strong>;
                lookupSourceSupplier = null;
                state = State.INPUT_SPILLED;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L422C56-L422C76)

<pre><code class="java">                localUserMemoryContext.setBytes(index.getEstimatedSize().toBytes(), enforceBroadcastMemoryLimit);
                localRevocableMemoryContext.setBytes(0);
                lookupSourceChecksum = OptionalLong.of(<strong>lookupSourceSupplier</strong>.checksum());
                lookupSourceSupplier = null;
                state = State.INPUT_SPILLED;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L423C17-L423C44)

<pre><code class="java">                localRevocableMemoryContext.setBytes(0);
                lookupSourceChecksum = OptionalLong.of(lookupSourceSupplier.checksum());
                <strong>lookupSourceSupplier = null</strong>;
                state = State.INPUT_SPILLED;
            });
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L424C17-L424C44)

<pre><code class="java">                lookupSourceChecksum = OptionalLong.of(lookupSourceSupplier.checksum());
                lookupSourceSupplier = null;
                <strong>state = State.INPUT_SPILLED</strong>;
            });
            return spillIndex();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L430C13-L430C55)

<pre><code class="java">        else if (operatorContext.getReservedRevocableBytes() == 0) {
            // Probably stale revoking request
            <strong>finishMemoryRevoke = Optional.of(() -&gt; {})</strong>;
            return immediateFuture(null);
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L434C118-L434C123)

<pre><code class="java">        }

        throw new IllegalStateException(format("State %s can not have revocable memory, but has %s revocable bytes", <strong>state</strong>, operatorContext.getReservedRevocableBytes()));
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L439C21-L439C28)

<pre><code class="java">    private ListenableFuture&lt;?&gt; spillIndex()
    {
        checkState(!<strong>spiller</strong>.isPresent(), "Spiller already created");
        spiller = Optional.of(singleStreamSpillerFactory.create(
                index.getTypes(),
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L440C9-L443C61)

<pre><code class="java">    {
        checkState(!spiller.isPresent(), "Spiller already created");
        <strong>spiller = Optional.of(singleStreamSpillerFactory.create(</strong>
<strong>                index.getTypes(),</strong>
<strong>                operatorContext.getSpillContext().newLocalSpillContext(),</strong>
<strong>                operatorContext.localSystemMemoryContext()))</strong>;
        long indexEstimatedSize = index.getEstimatedSize().toBytes();
        log.debug("Spilling Index for operator: %s, index estimated size: %s", operatorContext, indexEstimatedSize);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L458C20-L458C38)

<pre><code class="java">    public void finishMemoryRevoke()
    {
        checkState(<strong>finishMemoryRevoke</strong>.isPresent(), "Cannot finish unknown revoking");
        finishMemoryRevoke.get().run();
        finishMemoryRevoke = Optional.empty();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L459C9-L459C27)

<pre><code class="java">    {
        checkState(finishMemoryRevoke.isPresent(), "Cannot finish unknown revoking");
        <strong>finishMemoryRevoke</strong>.get().run();
        finishMemoryRevoke = Optional.empty();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L460C9-L460C46)

<pre><code class="java">        checkState(finishMemoryRevoke.isPresent(), "Cannot finish unknown revoking");
        finishMemoryRevoke.get().run();
        <strong>finishMemoryRevoke = Optional.empty()</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L477C13-L477C31)

<pre><code class="java">        }

        if (<strong>finishMemoryRevoke</strong>.isPresent()) {
            return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L481C17-L481C22)

<pre><code class="java">        }

        switch (<strong>state</strong>) {
            case CONSUMING_INPUT:
                finishInput();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L516C63-L516C68)

<pre><code class="java">        }

        throw new IllegalStateException("Unhandled state: " + <strong>state</strong>);
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L521C20-L521C25)

<pre><code class="java">    private void finishInput()
    {
        checkState(<strong>state</strong> == State.CONSUMING_INPUT);
        if (lookupSourceFactoryDestroyed.isDone()) {
            close();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L534C9-L534C118)

<pre><code class="java">            localUserMemoryContext.setBytes(partition.get().getInMemorySizeInBytes(), enforceBroadcastMemoryLimit);
        }
        <strong>lookupSourceNotNeeded = Optional.of(lookupSourceFactory.lendPartitionLookupSource(partitionIndex, partition))</strong>;

        state = State.LOOKUP_SOURCE_BUILT;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L536C9-L536C42)

<pre><code class="java">        lookupSourceNotNeeded = Optional.of(lookupSourceFactory.lendPartitionLookupSource(partitionIndex, partition));

        <strong>state = State.LOOKUP_SOURCE_BUILT</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L541C20-L541C25)

<pre><code class="java">    private void disposeLookupSourceIfRequested()
    {
        checkState(<strong>state</strong> == State.LOOKUP_SOURCE_BUILT);
        verify(lookupSourceNotNeeded.isPresent());
        if (!lookupSourceNotNeeded.get().isDone()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L542C16-L542C37)

<pre><code class="java">    {
        checkState(state == State.LOOKUP_SOURCE_BUILT);
        verify(<strong>lookupSourceNotNeeded</strong>.isPresent());
        if (!lookupSourceNotNeeded.get().isDone()) {
            return;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L543C14-L543C35)

<pre><code class="java">        checkState(state == State.LOOKUP_SOURCE_BUILT);
        verify(lookupSourceNotNeeded.isPresent());
        if (!<strong>lookupSourceNotNeeded</strong>.get().isDone()) {
            return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L550C9-L550C36)

<pre><code class="java">        localRevocableMemoryContext.setBytes(0);
        localUserMemoryContext.setBytes(index.getEstimatedSize().toBytes(), enforceBroadcastMemoryLimit);
        <strong>lookupSourceSupplier = null</strong>;
        close();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L556C20-L556C25)

<pre><code class="java">    private void finishSpilledInput()
    {
        checkState(<strong>state</strong> == State.SPILLING_INPUT);
        if (!spillInProgress.isDone()) {
            // Not ready to handle finish() yet
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L557C14-L557C29)

<pre><code class="java">    {
        checkState(state == State.SPILLING_INPUT);
        if (!<strong>spillInProgress</strong>.isDone()) {
            // Not ready to handle finish() yet
            return;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L561C29-L561C44)

<pre><code class="java">            return;
        }
        checkSpillSucceeded(<strong>spillInProgress</strong>);
        state = State.INPUT_SPILLED;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L562C9-L562C36)

<pre><code class="java">        }
        checkSpillSucceeded(spillInProgress);
        <strong>state = State.INPUT_SPILLED</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L567C20-L567C25)

<pre><code class="java">    private void unspillLookupSourceIfRequested()
    {
        checkState(<strong>state</strong> == State.INPUT_SPILLED);
        if (!spilledLookupSourceHandle.getUnspillingRequested().isDone()) {
            // Nothing to do yet.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L573C16-L573C23)

<pre><code class="java">        }

        verify(<strong>spiller</strong>.isPresent());
        verify(!unspillInProgress.isPresent());

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L574C17-L574C34)

<pre><code class="java">
        verify(spiller.isPresent());
        verify(!<strong>unspillInProgress</strong>.isPresent());

        long memorySizeOfSpillPages = getSpiller().getSpilledPagesInMemorySize();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L580C9-L580C75)

<pre><code class="java">        log.debug("Unspilling lookup source for operator %s: memorySizeOfSpillPages: %s estimatedSizeOfIndex: %s", operatorContext, memorySizeOfSpillPages, estimatedSizeOfIndex);
        localUserMemoryContext.setBytes(memorySizeOfSpillPages + estimatedSizeOfIndex, enforceBroadcastMemoryLimit);
        <strong>unspillInProgress = Optional.of(getSpiller().getAllSpilledPages())</strong>;

        state = State.INPUT_UNSPILLING;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L582C9-L582C39)

<pre><code class="java">        unspillInProgress = Optional.of(getSpiller().getAllSpilledPages());

        <strong>state = State.INPUT_UNSPILLING</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L594C54-L594C71)

<pre><code class="java">
        // Use Queue so that Pages already consumed by Index are not retained by us.
        Queue&lt;Page&gt; pages = new ArrayDeque&lt;&gt;(getDone(<strong>unspillInProgress</strong>.get()));
        unspillInProgress = Optional.empty();
        long sizeOfUnSpilledPages = pages.stream()
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L587C20-L587C25)

<pre><code class="java">    private void finishLookupSourceUnspilling()
    {
        checkState(<strong>state</strong> == State.INPUT_UNSPILLING);
        if (!unspillInProgress.get().isDone()) {
            // Pages have not been unspilled yet.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L588C14-L588C31)

<pre><code class="java">    {
        checkState(state == State.INPUT_UNSPILLING);
        if (!<strong>unspillInProgress</strong>.get().isDone()) {
            // Pages have not been unspilled yet.
            return;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L595C9-L595C45)

<pre><code class="java">        // Use Queue so that Pages already consumed by Index are not retained by us.
        Queue&lt;Page&gt; pages = new ArrayDeque&lt;&gt;(getDone(unspillInProgress.get()));
        <strong>unspillInProgress = Optional.empty()</strong>;
        long sizeOfUnSpilledPages = pages.stream()
                .mapToLong(Page::getSizeInBytes)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L619C9-L619C29)

<pre><code class="java">
        LookupSourceSupplier partition = buildLookupSource();
        <strong>lookupSourceChecksum</strong>.ifPresent(checksum -&gt;
                checkState(partition.checksum() == checksum, "Unspilled lookupSource checksum does not match original one"));
        localUserMemoryContext.setBytes(partition.get().getInMemorySizeInBytes(), enforceBroadcastMemoryLimit);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L625C9-L625C48)

<pre><code class="java">        spilledLookupSourceHandle.setLookupSource(partition);

        <strong>state = State.INPUT_UNSPILLED_AND_BUILT</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L630C20-L630C25)

<pre><code class="java">    private void disposeUnspilledLookupSourceIfRequested()
    {
        checkState(<strong>state</strong> == State.INPUT_UNSPILLED_AND_BUILT);
        if (!spilledLookupSourceHandle.getDisposeRequested().isDone()) {
            return;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L648C20-L648C40)

<pre><code class="java">        operatorContext.recordNullJoinBuildKeyCount(partition.getPositionIsNullCount());
        operatorContext.recordJoinBuildKeyCount(partition.getPositionCount());
        checkState(<strong>lookupSourceSupplier</strong> == null, "lookupSourceSupplier is already set");
        this.lookupSourceSupplier = partition;
        return partition;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L649C9-L649C46)

<pre><code class="java">        operatorContext.recordJoinBuildKeyCount(partition.getPositionCount());
        checkState(lookupSourceSupplier == null, "lookupSourceSupplier is already set");
        <strong>this.lookupSourceSupplier = partition</strong>;
        return partition;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L662C16-L662C21)

<pre><code class="java">        }

        return <strong>state</strong> == State.CLOSED;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L667C16-L667C23)

<pre><code class="java">    private SingleStreamSpiller getSpiller()
    {
        return <strong>spiller</strong>.orElseThrow(() -&gt; new IllegalStateException("Spiller not created"));
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L673C13-L673C18)

<pre><code class="java">    public void close()
    {
        if (<strong>state</strong> == State.CLOSED) {
            return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L677C9-L677C36)

<pre><code class="java">        }
        // close() can be called in any state, due for example to query failure, and must clean resource up unconditionally
        <strong>lookupSourceSupplier = null</strong>;
        unspillInProgress = Optional.empty();
        state = State.CLOSED;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L678C9-L678C45)

<pre><code class="java">        // close() can be called in any state, due for example to query failure, and must clean resource up unconditionally
        lookupSourceSupplier = null;
        <strong>unspillInProgress = Optional.empty()</strong>;
        state = State.CLOSED;
        finishMemoryRevoke = finishMemoryRevoke.map(ifPresent -&gt; () -&gt; {});
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L679C9-L679C29)

<pre><code class="java">        lookupSourceSupplier = null;
        unspillInProgress = Optional.empty();
        <strong>state = State.CLOSED</strong>;
        finishMemoryRevoke = finishMemoryRevoke.map(ifPresent -&gt; () -&gt; {});

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L680C9-L680C75)

<pre><code class="java">        unspillInProgress = Optional.empty();
        state = State.CLOSED;
        <strong>finishMemoryRevoke = finishMemoryRevoke.map(ifPresent -&gt; () -&gt; {})</strong>;

        try (Closer closer = Closer.create()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L680C30-L680C48)

<pre><code class="java">        unspillInProgress = Optional.empty();
        state = State.CLOSED;
        finishMemoryRevoke = <strong>finishMemoryRevoke</strong>.map(ifPresent -&gt; () -&gt; {});

        try (Closer closer = Closer.create()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L684C13-L684C20)

<pre><code class="java">        try (Closer closer = Closer.create()) {
            closer.register(index::clear);
            <strong>spiller</strong>.ifPresent(closer::register);
            closer.register(() -&gt; localUserMemoryContext.setBytes(0, enforceBroadcastMemoryLimit));
            closer.register(() -&gt; localRevocableMemoryContext.setBytes(0));
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java#L100C74-L100C89)

<pre><code class="java">    public Iterator&lt;Partition&lt;T&gt;&gt; beginConsumption()
    {
        Queue&lt;Partition&lt;T&gt;&gt; partitions = new ArrayDeque&lt;&gt;(requireNonNull(<strong>this.partitions</strong>, "partitions is already null"));
        if (consumed.incrementAndGet() &gt;= consumersCount) {
            // Unreference futures to allow GC
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java#L103C13-L103C35)

<pre><code class="java">        if (consumed.incrementAndGet() &gt;= consumersCount) {
            // Unreference futures to allow GC
            <strong>this.partitions = null</strong>;
        }
        return new AbstractIterator&lt;Partition&lt;T&gt;&gt;()
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L557C17-L557C42)

<pre><code class="java">        {
            if (!driverContext.isExecutionStarted()) {
                <strong>physicallyQueuedDrivers++</strong>;
            }
            else if (driverContext.isFullyBlocked()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L557C17-L557C40)

<pre><code class="java">        {
            if (!driverContext.isExecutionStarted()) {
                <strong>physicallyQueuedDrivers</strong>++;
            }
            else if (driverContext.isFullyBlocked()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L560C17-L560C33)

<pre><code class="java">            }
            else if (driverContext.isFullyBlocked()) {
                <strong>blockedDrivers++</strong>;
                blockedSplitsWeight += driverContext.getSplitWeight();
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L560C17-L560C31)

<pre><code class="java">            }
            else if (driverContext.isFullyBlocked()) {
                <strong>blockedDrivers</strong>++;
                blockedSplitsWeight += driverContext.getSplitWeight();
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L561C17-L561C70)

<pre><code class="java">            else if (driverContext.isFullyBlocked()) {
                blockedDrivers++;
                <strong>blockedSplitsWeight += driverContext.getSplitWeight()</strong>;
            }
            else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L561C17-L561C36)

<pre><code class="java">            else if (driverContext.isFullyBlocked()) {
                blockedDrivers++;
                <strong>blockedSplitsWeight</strong> += driverContext.getSplitWeight();
            }
            else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L564C17-L564C33)

<pre><code class="java">            }
            else {
                <strong>runningDrivers++</strong>;
                runningSplitsWeight += driverContext.getSplitWeight();
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L564C17-L564C31)

<pre><code class="java">            }
            else {
                <strong>runningDrivers</strong>++;
                runningSplitsWeight += driverContext.getSplitWeight();
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L565C17-L565C70)

<pre><code class="java">            else {
                runningDrivers++;
                <strong>runningSplitsWeight += driverContext.getSplitWeight()</strong>;
            }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L565C17-L565C36)

<pre><code class="java">            else {
                runningDrivers++;
                <strong>runningSplitsWeight</strong> += driverContext.getSplitWeight();
            }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L573C17-L573C42)

<pre><code class="java">            if (driverStats.getStartTime() == null) {
                // driver has not started running
                <strong>physicallyQueuedDrivers++</strong>;
            }
            else if (driverStats.isFullyBlocked()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L573C17-L573C40)

<pre><code class="java">            if (driverStats.getStartTime() == null) {
                // driver has not started running
                <strong>physicallyQueuedDrivers</strong>++;
            }
            else if (driverStats.isFullyBlocked()) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L576C17-L576C33)

<pre><code class="java">            }
            else if (driverStats.isFullyBlocked()) {
                <strong>blockedDrivers++</strong>;
                blockedSplitsWeight += splitWeight;
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L576C17-L576C31)

<pre><code class="java">            }
            else if (driverStats.isFullyBlocked()) {
                <strong>blockedDrivers</strong>++;
                blockedSplitsWeight += splitWeight;
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L577C17-L577C51)

<pre><code class="java">            else if (driverStats.isFullyBlocked()) {
                blockedDrivers++;
                <strong>blockedSplitsWeight += splitWeight</strong>;
            }
            else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L577C17-L577C36)

<pre><code class="java">            else if (driverStats.isFullyBlocked()) {
                blockedDrivers++;
                <strong>blockedSplitsWeight</strong> += splitWeight;
            }
            else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L580C17-L580C33)

<pre><code class="java">            }
            else {
                <strong>runningDrivers++</strong>;
                runningSplitsWeight += splitWeight;
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L580C17-L580C31)

<pre><code class="java">            }
            else {
                <strong>runningDrivers</strong>++;
                runningSplitsWeight += splitWeight;
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L581C17-L581C51)

<pre><code class="java">            else {
                runningDrivers++;
                <strong>runningSplitsWeight += splitWeight</strong>;
            }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L581C17-L581C36)

<pre><code class="java">            else {
                runningDrivers++;
                <strong>runningSplitsWeight</strong> += splitWeight;
            }
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L593C64-L593C78)

<pre><code class="java">            long runningPartitionedSplitsWeight;
            if (partitioned) {
                queuedDrivers = totalSplits - runningDrivers - <strong>blockedDrivers</strong> - completedDrivers;
                if (queuedDrivers &lt; 0) {
                    // It is possible to observe negative here because inputs to the above expression was not taken in a snapshot.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L593C47-L593C61)

<pre><code class="java">            long runningPartitionedSplitsWeight;
            if (partitioned) {
                queuedDrivers = totalSplits - <strong>runningDrivers</strong> - blockedDrivers - completedDrivers;
                if (queuedDrivers &lt; 0) {
                    // It is possible to observe negative here because inputs to the above expression was not taken in a snapshot.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L598C103-L598C122)

<pre><code class="java">                    queuedDrivers = 0;
                }
                queuedPartitionedSplitsWeight = activePartitionedSplitsWeight - runningSplitsWeight - <strong>blockedSplitsWeight</strong>;
                if (queuedDrivers == 0 || queuedPartitionedSplitsWeight &lt; 0) {
                    // negative or inconsistent count vs weight inputs might occur
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L598C81-L598C100)

<pre><code class="java">                    queuedDrivers = 0;
                }
                queuedPartitionedSplitsWeight = activePartitionedSplitsWeight - <strong>runningSplitsWeight</strong> - blockedSplitsWeight;
                if (queuedDrivers == 0 || queuedPartitionedSplitsWeight &lt; 0) {
                    // negative or inconsistent count vs weight inputs might occur
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L604C44-L604C58)

<pre><code class="java">                }
                queuedPartitionedSplits = queuedDrivers;
                runningPartitionedSplits = <strong>runningDrivers</strong>;
                runningPartitionedSplitsWeight = runningSplitsWeight;
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L605C50-L605C69)

<pre><code class="java">                queuedPartitionedSplits = queuedDrivers;
                runningPartitionedSplits = runningDrivers;
                runningPartitionedSplitsWeight = <strong>runningSplitsWeight</strong>;
            }
            else {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L608C33-L608C56)

<pre><code class="java">            }
            else {
                queuedDrivers = <strong>physicallyQueuedDrivers</strong>;
                queuedPartitionedSplits = 0;
                queuedPartitionedSplitsWeight = 0;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L614C54-L614C68)

<pre><code class="java">                runningPartitionedSplitsWeight = 0;
            }
            return new PipelineStatus(queuedDrivers, <strong>runningDrivers</strong>, blockedDrivers, queuedPartitionedSplits, queuedPartitionedSplitsWeight, runningPartitionedSplits, runningPartitionedSplitsWeight);
        }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L614C70-L614C84)

<pre><code class="java">                runningPartitionedSplitsWeight = 0;
            }
            return new PipelineStatus(queuedDrivers, runningDrivers, <strong>blockedDrivers</strong>, queuedPartitionedSplits, queuedPartitionedSplitsWeight, runningPartitionedSplits, runningPartitionedSplitsWeight);
        }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L104C25-L104C31)

<pre><code class="java">        public Operator createOperator(DriverContext driverContext)
        {
            checkState(!<strong>closed</strong>, "Factory is already closed");
            OperatorContext operatorContext = driverContext.addOperatorContext(operatorId, planNodeId, SetBuilderOperator.class.getSimpleName());
            return new SetBuilderOperator(operatorContext, setProvider, setChannel, hashChannel, expectedPositions, joinCompiler);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L112C13-L112C26)

<pre><code class="java">        public void noMoreOperators()
        {
            <strong>closed = true</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L170C13-L170C21)

<pre><code class="java">    public void finish()
    {
        if (<strong>finished</strong>) {
            return;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L177C9-L177C24)

<pre><code class="java">        setSupplier.setChannelSet(channelSet);
        operatorContext.recordOutput(channelSet.getEstimatedSizeInBytes(), channelSet.size());
        <strong>finished = true</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L183C16-L183C24)

<pre><code class="java">    public boolean isFinished()
    {
        return <strong>finished</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L192C17-L192C25)

<pre><code class="java">        // method may never be called. We need to handle any unfinished work
        // before addInput() can be called again.
        return !<strong>finished</strong> &amp;&amp; (unfinishedWork == null || processUnfinishedWork());
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L192C30-L192C44)

<pre><code class="java">        // method may never be called. We need to handle any unfinished work
        // before addInput() can be called again.
        return !finished &amp;&amp; (<strong>unfinishedWork</strong> == null || processUnfinishedWork());
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L201C9-L201C89)

<pre><code class="java">        checkState(!isFinished(), "Operator is already finished");

        <strong>unfinishedWork = channelSetBuilder.addPage(page.extractChannels(sourceChannels))</strong>;
        processUnfinishedWork();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L216C24-L216C38)

<pre><code class="java">        // can't be fully consumed (e.g. rehashing fails), the unfinishedWork will be left with non-empty value.
        checkState(unfinishedWork != null, "unfinishedWork is empty");
        boolean done = <strong>unfinishedWork</strong>.process();
        if (done) {
            unfinishedWork = null;
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L215C20-L215C34)

<pre><code class="java">        // Processes the unfinishedWork for this page by adding the data to the hash table. If this page
        // can't be fully consumed (e.g. rehashing fails), the unfinishedWork will be left with non-empty value.
        checkState(<strong>unfinishedWork</strong> != null, "unfinishedWork is empty");
        boolean done = unfinishedWork.process();
        if (done) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L218C13-L218C34)

<pre><code class="java">        boolean done = unfinishedWork.process();
        if (done) {
            <strong>unfinishedWork = null</strong>;
        }
        // We need to update the memory reservation again since the page builder memory may also be increasing.
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L117C30-L117C35)

<pre><code class="java">    private void assertState(State expectedState)
    {
        State currentState = <strong>state</strong>;
        checkState(currentState == expectedState, "Expected state %s, but state is %s", expectedState, currentState);
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L125C9-L125C66)

<pre><code class="java">    {
        //this.state.set(requireNonNull(newState, "newState is null"));
        <strong>this.state = requireNonNull(newState, "newState is null")</strong>;
    }
}
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L400C25-L400C41)

<pre><code class="java">                        partitioningProviderManager,
                        session,
                        <strong>numSinkFactories</strong>,
                        bufferCount,
                        partitioning,
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L396C28-L396C47)

<pre><code class="java">            }
            return localExchangeMap.computeIfAbsent(lifespan, ignored -&gt; {
                checkState(<strong>noMoreSinkFactories</strong>);
                LocalExchange localExchange = new LocalExchange(
                        partitioningProviderManager,
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java#L147C13-L147C22)

<pre><code class="java">
        //  Fast path, definitely not blocked
        if (<strong>finishing</strong> || !buffer.isEmpty()) {
            return NOT_BLOCKED;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java#L167C14-L167C23)

<pre><code class="java">    {
        // Common case fast-path without synchronizing
        if (!<strong>finishing</strong>) {
            return false;
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java#L249C52-L249C67)

<pre><code class="java">        PageBuffer pageBuffer = new PageBuffer(100);
        DriverFactory driverFactory = indexBuildDriverFactoryProvider.createStreaming(pageBuffer, indexKeyTuple);
        Driver driver = driverFactory.createDriver(<strong>pipelineContext</strong>.addDriverContext());

        PageRecordSet pageRecordSet = new PageRecordSet(keyTypes, indexKeyTuple);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L52C25-L52C31)

<pre><code class="java">        public Operator createOperator(DriverContext driverContext)
        {
            checkState(!<strong>closed</strong>, "Factory is already closed");

            OperatorContext operatorContext = driverContext.addOperatorContext(operatorId, planNodeId, operatorType);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L61C13-L61C26)

<pre><code class="java">        public void noMoreOperators()
        {
            <strong>closed = true</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L91C9-L91C24)

<pre><code class="java">    public void finish()
    {
        <strong>finished = true</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L97C16-L97C24)

<pre><code class="java">    public boolean isFinished()
    {
        return <strong>finished</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L103C17-L103C25)

<pre><code class="java">    public boolean needsInput()
    {
        return !<strong>finished</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java#L78C20-L78C27)

<pre><code class="java">        public double getAverage()
        {
            return <strong>average</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java#L83C20-L83C25)

<pre><code class="java">        public long getCount()
        {
            return <strong>count</strong>;
        }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L155C13-L155C44)

<pre><code class="java">        {
            pages.add(page);
            <strong>rows += page.getPositionCount()</strong>;
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L155C13-L155C17)

<pre><code class="java">        {
            pages.add(page);
            <strong>rows</strong> += page.getPositionCount();
        }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L165C20-L165C24)

<pre><code class="java">        private long getRows()
        {
            return <strong>rows</strong>;
        }
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L73C29-L73C51)

<pre><code class="java">            closer.register(revocableAggregateMemoryContext::close);
            closer.register(systemAggregateMemoryContext::close);
            closer.register(<strong>userLocalMemoryContext</strong>::close);
            closer.register(revocableLocalMemoryContext::close);
            closer.register(systemLocalMemoryContext::close);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L74C29-L74C56)

<pre><code class="java">            closer.register(systemAggregateMemoryContext::close);
            closer.register(userLocalMemoryContext::close);
            closer.register(<strong>revocableLocalMemoryContext</strong>::close);
            closer.register(systemLocalMemoryContext::close);
        }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L75C29-L75C53)

<pre><code class="java">            closer.register(userLocalMemoryContext::close);
            closer.register(revocableLocalMemoryContext::close);
            closer.register(<strong>systemLocalMemoryContext</strong>::close);
        }
        catch (IOException e) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L84C16-L84C38)

<pre><code class="java">    public LocalMemoryContext localUserMemoryContext()
    {
        verify(<strong>userLocalMemoryContext</strong> != null, "local memory contexts are not initialized");
        return userLocalMemoryContext;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L85C16-L85C38)

<pre><code class="java">    {
        verify(userLocalMemoryContext != null, "local memory contexts are not initialized");
        return <strong>userLocalMemoryContext</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L90C16-L90C40)

<pre><code class="java">    public LocalMemoryContext localSystemMemoryContext()
    {
        verify(<strong>systemLocalMemoryContext</strong> != null, "local memory contexts are not initialized");
        return systemLocalMemoryContext;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L91C16-L91C40)

<pre><code class="java">    {
        verify(systemLocalMemoryContext != null, "local memory contexts are not initialized");
        return <strong>systemLocalMemoryContext</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L96C16-L96C43)

<pre><code class="java">    public LocalMemoryContext localRevocableMemoryContext()
    {
        verify(<strong>revocableLocalMemoryContext</strong> != null, "local memory contexts are not initialized");
        return revocableLocalMemoryContext;
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L97C16-L97C43)

<pre><code class="java">    {
        verify(revocableLocalMemoryContext != null, "local memory contexts are not initialized");
        return <strong>revocableLocalMemoryContext</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L149C9-L149C102)

<pre><code class="java">    public void initializeLocalMemoryContexts(String allocationTag)
    {
        <strong>this.userLocalMemoryContext = userAggregateMemoryContext.newLocalMemoryContext(allocationTag)</strong>;
        this.revocableLocalMemoryContext = revocableAggregateMemoryContext.newLocalMemoryContext(allocationTag);
        this.systemLocalMemoryContext = systemAggregateMemoryContext.newLocalMemoryContext(allocationTag);
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L150C9-L150C112)

<pre><code class="java">    {
        this.userLocalMemoryContext = userAggregateMemoryContext.newLocalMemoryContext(allocationTag);
        <strong>this.revocableLocalMemoryContext = revocableAggregateMemoryContext.newLocalMemoryContext(allocationTag)</strong>;
        this.systemLocalMemoryContext = systemAggregateMemoryContext.newLocalMemoryContext(allocationTag);
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L151C9-L151C106)

<pre><code class="java">        this.userLocalMemoryContext = userAggregateMemoryContext.newLocalMemoryContext(allocationTag);
        this.revocableLocalMemoryContext = revocableAggregateMemoryContext.newLocalMemoryContext(allocationTag);
        <strong>this.systemLocalMemoryContext = systemAggregateMemoryContext.newLocalMemoryContext(allocationTag)</strong>;
    }

</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L163C50-L163C74)

<pre><code class="java">                .add("userLocalMemoryContext", userLocalMemoryContext)
                .add("revocableLocalMemoryContext", revocableLocalMemoryContext)
                .add("systemLocalMemoryContext", <strong>systemLocalMemoryContext</strong>)
                .toString();
    }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L162C53-L162C80)

<pre><code class="java">                .add("systemAggregateMemoryContext", systemAggregateMemoryContext)
                .add("userLocalMemoryContext", userLocalMemoryContext)
                .add("revocableLocalMemoryContext", <strong>revocableLocalMemoryContext</strong>)
                .add("systemLocalMemoryContext", systemLocalMemoryContext)
                .toString();
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L161C48-L161C70)

<pre><code class="java">                .add("revocableAggregateMemoryContext", revocableAggregateMemoryContext)
                .add("systemAggregateMemoryContext", systemAggregateMemoryContext)
                .add("userLocalMemoryContext", <strong>userLocalMemoryContext</strong>)
                .add("revocableLocalMemoryContext", revocableLocalMemoryContext)
                .add("systemLocalMemoryContext", systemLocalMemoryContext)
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java#L51C17-L51C31)

<pre><code class="java">            Map&lt;String, Object&gt; fields = mapper.convertValue(response, Map.class);
            if (fields.containsKey("status") &amp;&amp; (int) fields.get("status") != OK.code()) {
                <strong>cpuInfo = null</strong>;
                return;
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java#L54C13-L54C103)

<pre><code class="java">                return;
            }
            <strong>cpuInfo = new CpuInfo((int) fields.get(CPU_TIME_LABEL), (String) fields.get(CPU_TIME_STR))</strong>;
        }
        catch (Exception e) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java#L63C16-L63C23)

<pre><code class="java">    public CpuInfo getCpuInfo()
    {
        return <strong>cpuInfo</strong>;
    }
}
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java#L51C17-L51C34)

<pre><code class="java">            Map&lt;String, Object&gt; fields = mapper.convertValue(response, Map.class);
            if (fields.containsKey("status") &amp;&amp; (int) fields.get("status") != OK.code()) {
                <strong>memoryInfo = null</strong>;
                return;
            }
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java#L54C13-L54C117)

<pre><code class="java">                return;
            }
            <strong>memoryInfo = new MemoryInfo((int) fields.get(MEMORY_BYTES_LABEL), (String) fields.get(MEMORY_BYTES_STR))</strong>;
        }
        catch (Exception e) {
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java#L63C16-L63C26)

<pre><code class="java">    public MemoryInfo getMemoryInfo()
    {
        return <strong>memoryInfo</strong>;
    }
}
</code></pre>

*Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

| e |  |
| --- | --- |
| [`lazilyLoadedParentType`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L89C16-L89C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`get(...).lazilyLoadedParentType`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L118C16-L118C57) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`get(...).lazilyLoadedParentType`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L119C29-L119C70) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`get(...).lazilyLoadedParentType`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L128C16-L128C58) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`get(...).lazilyLoadedParentType`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L129C30-L129C72) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`type.lazilyLoadedParentType`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L190C18-L190C44) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`type.lazilyLoadedParentType`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L195C24-L195C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`distinctTypeLoader`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-common/src/main/java/com/facebook/presto/common/type/DistinctType.java#L368C14-L368C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`previousTaskAge`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L291C21-L291C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L292C21-L292C53) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L293C21-L293C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`previousTaskAge`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L297C40-L297C54) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`previousValue`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L302C50-L302C62) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`previousTaskAge`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L303C60-L303C74) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L304C21-L304C53) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/NodeTaskMap.java#L305C21-L305C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`stageTaskRecoveryCallback`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L598C21-L598C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`stageTaskRecoveryCallback`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/SqlStageExecution.java#L640C16-L640C40) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/StateMachine.java#L93C16-L93C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L602C25-L602C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L667C33-L667C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L678C22-L678C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`printed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L1026C20-L1026C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L1031C13-L1031C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L1063C9-L1063C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`this.lowMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskExecutor.java#L1068C16-L1068C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`destroyed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/executor/TaskHandle.java#L85C16-L85C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...+=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L863C72-L863C135) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`cachedMemoryUsageBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L863C72-L863C93) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`schedulingPolicy`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L944C13-L944C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`schedulingPolicy`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L948C119-L948C134) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`eligibleSubGroups`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L954C29-L954C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`softConcurrencyLimit`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L969C46-L969C65) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`schedulingWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L970C20-L970C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`schedulingWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/execution/resourceGroups/InternalResourceGroup.java#L973C43-L973C58) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`leakedBytes`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/ClusterMemoryLeakDetector.java#L67C44-L67C54) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`memoryLimitsInitialized`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L158C16-L158C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`maxUserMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L337C16-L337C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`maxTotalMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L342C16-L342C29) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`heapDumpOnExceededMemoryLimitEnabled`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L502C21-L502C56) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`heapDumpFilePath`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L503C21-L503C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L523C9-L523C72) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`peakNodeTotalMemory`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L523C53-L523C71) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`heapDumpOnExceededMemoryLimitEnabled`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L527C21-L527C56) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`heapDumpFilePath`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L528C21-L528C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`heapDumpOnExceededMemoryLimitEnabled`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L537C138-L537C173) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`heapDumpFilePath`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L537C176-L537C191) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`memoryPool`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L544C46-L544C55) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`verboseExceededMemoryLimitErrorsEnabled`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/memory/QueryContext.java#L568C13-L568C51) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`functions`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java#L1101C16-L1101C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`functions`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/metadata/BuiltInTypeAndFunctionNamespaceManager.java#L1107C16-L1107C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`oldValue`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L564C31-L564C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`oldValue`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L564C60-L564C67) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L565C13-L565C31) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`oldValue`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/ExchangeClient.java#L570C27-L570C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L124C25-L124C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`enforceBroadcastMemoryLimit`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L144C21-L144C47) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L150C13-L150C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L292C16-L292C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L298C17-L298C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L303C24-L303C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lookupSourceNotNeeded`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L306C24-L306C44) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`unspillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L312C24-L312C40) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L320C63-L320C67) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L326C36-L326C40) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L327C21-L327C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L327C54-L327C68) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L342C13-L342C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L347C20-L347C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L369C20-L369C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L370C29-L370C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L382C9-L382C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L392C13-L392C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L397C17-L397C58) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L400C201-L400C205) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L402C13-L410C14) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L405C198-L405C202) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L409C17-L409C44) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L413C18-L413C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L414C13-L425C14) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L416C17-L416C56) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L419C197-L419C201) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L422C17-L422C87) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lookupSourceSupplier`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L422C56-L422C75) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L423C17-L423C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L424C17-L424C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L430C13-L430C54) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L434C118-L434C122) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spiller`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L439C21-L439C27) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L440C9-L443C60) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finishMemoryRevoke`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L458C20-L458C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finishMemoryRevoke`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L459C9-L459C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L460C9-L460C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finishMemoryRevoke`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L477C13-L477C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L481C17-L481C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L516C63-L516C67) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L521C20-L521C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L534C9-L534C117) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L536C9-L536C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L541C20-L541C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lookupSourceNotNeeded`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L542C16-L542C36) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lookupSourceNotNeeded`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L543C14-L543C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L550C9-L550C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L556C20-L556C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L557C14-L557C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L561C29-L561C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L562C9-L562C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L567C20-L567C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spiller`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L573C16-L573C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`unspillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L574C17-L574C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L580C9-L580C74) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L582C9-L582C38) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`unspillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L594C54-L594C70) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L587C20-L587C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`unspillInProgress`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L588C14-L588C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L595C9-L595C44) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lookupSourceChecksum`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L619C9-L619C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L625C9-L625C47) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L630C20-L630C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`lookupSourceSupplier`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L648C20-L648C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L649C9-L649C45) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L662C16-L662C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spiller`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L667C16-L667C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L673C13-L673C17) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L677C9-L677C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L678C9-L678C44) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L679C9-L679C28) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L680C9-L680C74) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finishMemoryRevoke`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L680C30-L680C47) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`spiller`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/HashBuilderOperator.java#L684C13-L684C19) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`this.partitions`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java#L100C74-L100C88) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PartitionedConsumption.java#L103C13-L103C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L557C17-L557C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`physicallyQueuedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L557C17-L557C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L560C17-L560C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`blockedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L560C17-L560C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...+=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L561C17-L561C69) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`blockedSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L561C17-L561C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L564C17-L564C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L564C17-L564C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...+=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L565C17-L565C69) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L565C17-L565C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L573C17-L573C41) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`physicallyQueuedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L573C17-L573C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L576C17-L576C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`blockedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L576C17-L576C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...+=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L577C17-L577C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`blockedSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L577C17-L577C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...++`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L580C17-L580C32) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L580C17-L580C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...+=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L581C17-L581C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L581C17-L581C35) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`blockedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L593C64-L593C77) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L593C47-L593C60) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`blockedSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L598C103-L598C121) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L598C81-L598C99) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L604C44-L604C57) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningSplitsWeight`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L605C50-L605C68) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`physicallyQueuedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L608C33-L608C55) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`runningDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L614C54-L614C67) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`blockedDrivers`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/PipelineContext.java#L614C70-L614C83) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L104C25-L104C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L112C13-L112C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L170C13-L170C20) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L177C9-L177C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L183C16-L183C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L192C17-L192C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`unfinishedWork`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L192C30-L192C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L201C9-L201C88) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`unfinishedWork`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L216C24-L216C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`unfinishedWork`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L215C20-L215C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SetBuilderOperator.java#L218C13-L218C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`state`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L117C30-L117C34) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/SpilledLookupSourceHandle.java#L125C9-L125C65) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`numSinkFactories`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L400C25-L400C40) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`noMoreSinkFactories`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchange.java#L396C28-L396C46) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finishing`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java#L147C13-L147C21) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finishing`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/exchange/LocalExchangeSource.java#L167C14-L167C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`pipelineContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/IndexLoader.java#L249C52-L249C66) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`closed`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L52C25-L52C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L61C13-L61C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L91C9-L91C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L97C16-L97C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`finished`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/operator/index/PagesIndexBuilderOperator.java#L103C17-L103C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`average`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java#L78C20-L78C26) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`count`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-main/src/main/java/com/facebook/presto/server/SimpleHttpResponseHandlerStats.java#L83C20-L83C24) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...+=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L155C13-L155C43) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`rows`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L155C13-L155C16) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`rows`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory/src/main/java/com/facebook/presto/plugin/memory/MemoryPagesStore.java#L165C20-L165C23) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`userLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L73C29-L73C50) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`revocableLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L74C29-L74C55) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`systemLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L75C29-L75C52) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`userLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L84C16-L84C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`userLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L85C16-L85C37) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`systemLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L90C16-L90C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`systemLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L91C16-L91C39) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`revocableLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L96C16-L96C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`revocableLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L97C16-L97C42) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L149C9-L149C101) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L150C9-L150C111) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L151C9-L151C105) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`systemLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L163C50-L163C73) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`revocableLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L162C53-L162C79) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`userLocalMemoryContext`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-memory-context/src/main/java/com/facebook/presto/memory/context/MemoryTrackingContext.java#L161C48-L161C69) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java#L51C17-L51C30) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java#L54C13-L54C102) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`cpuInfo`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryCpu.java#L63C16-L63C22) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java#L51C17-L51C33) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`...=...`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java#L54C13-L54C116) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`memoryInfo`](https://github.com/prestodb/presto/blob/62d9641d15f55306cb627c404c8383bd0bfdc509/presto-router/src/main/java/com/facebook/presto/router/predictor/RemoteQueryMemory.java#L63C16-L63C25) | `Writes to a field. Consider it being in a lock and make sure that the lock and unlock is on the same object.` |