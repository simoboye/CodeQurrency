### JetBrains/kotlin

| c |
| --- |
| `DeprecationLogger` |