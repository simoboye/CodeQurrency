### apache/hbase

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L42C29-L42C92)

<pre><code class="java">  @Override
  public void testStarted(Description description) throws Exception {
    Category[] categories = <strong>description.getTestClass().getAnnotationsByType(Category.class)</strong>;

    // @Category is not repeatable -- it is only possible to get an array of length zero or one.
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L42C29-L42C55)

<pre><code class="java">  @Override
  public void testStarted(Description description) throws Exception {
    Category[] categories = <strong>description.getTestClass()</strong>.getAnnotationsByType(Category.class);

    // @Category is not repeatable -- it is only possible to get an array of length zero or one.
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L46C25-L46C46)

<pre><code class="java">    // @Category is not repeatable -- it is only possible to get an array of length zero or one.
    if (categories.length == 1) {
      for (Class&lt;?&gt; c : <strong>categories[0].value()</strong>) {
        if (c == IntegrationTests.class) {
          return;
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L52C24-L52C62)

<pre><code class="java">      }
    }
    for (Field field : <strong>description.getTestClass().getFields()</strong>) {
      if (
        Modifier.isStatic(field.getModifiers()) &amp;&amp; field.getType() == HBaseClassTestRule.class
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L52C24-L52C50)

<pre><code class="java">      }
    }
    for (Field field : <strong>description.getTestClass()</strong>.getFields()) {
      if (
        Modifier.isStatic(field.getModifiers()) &amp;&amp; field.getType() == HBaseClassTestRule.class
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L55C14-L55C56)

<pre><code class="java">      if (
        Modifier.isStatic(field.getModifiers()) &amp;&amp; field.getType() == HBaseClassTestRule.class
          &amp;&amp; <strong>field.isAnnotationPresent(ClassRule.class)</strong>
      ) {
        HBaseClassTestRule timeout = (HBaseClassTestRule) field.get(null);
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L54C9-L54C48)

<pre><code class="java">    for (Field field : description.getTestClass().getFields()) {
      if (
        <strong>Modifier.isStatic(field.getModifiers())</strong> &amp;&amp; field.getType() == HBaseClassTestRule.class
          &amp;&amp; field.isAnnotationPresent(ClassRule.class)
      ) {
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L54C27-L54C47)

<pre><code class="java">    for (Field field : description.getTestClass().getFields()) {
      if (
        Modifier.isStatic(<strong>field.getModifiers()</strong>) &amp;&amp; field.getType() == HBaseClassTestRule.class
          &amp;&amp; field.isAnnotationPresent(ClassRule.class)
      ) {
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L54C52-L54C67)

<pre><code class="java">    for (Field field : description.getTestClass().getFields()) {
      if (
        Modifier.isStatic(field.getModifiers()) &amp;&amp; <strong>field.getType()</strong> == HBaseClassTestRule.class
          &amp;&amp; field.isAnnotationPresent(ClassRule.class)
      ) {
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L57C59-L57C74)

<pre><code class="java">          &amp;&amp; field.isAnnotationPresent(ClassRule.class)
      ) {
        HBaseClassTestRule timeout = (HBaseClassTestRule) <strong>field.get(null)</strong>;
        assertEquals("The HBaseClassTestRule ClassRule in " + description.getTestClass().getName()
          + " is for " + timeout.getClazz().getName(), description.getTestClass(),
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L58C9-L60C30)

<pre><code class="java">      ) {
        HBaseClassTestRule timeout = (HBaseClassTestRule) field.get(null);
        <strong>assertEquals("The HBaseClassTestRule ClassRule in " + description.getTestClass().getName()</strong>
<strong>          + " is for " + timeout.getClazz().getName(), description.getTestClass(),</strong>
<strong>          timeout.getClazz())</strong>;
        return;
      }
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L59C56-L59C82)

<pre><code class="java">        HBaseClassTestRule timeout = (HBaseClassTestRule) field.get(null);
        assertEquals("The HBaseClassTestRule ClassRule in " + description.getTestClass().getName()
          + " is for " + timeout.getClazz().getName(), <strong>description.getTestClass()</strong>,
          timeout.getClazz());
        return;
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L60C11-L60C29)

<pre><code class="java">        assertEquals("The HBaseClassTestRule ClassRule in " + description.getTestClass().getName()
          + " is for " + timeout.getClazz().getName(), description.getTestClass(),
          <strong>timeout.getClazz()</strong>);
        return;
      }
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L59C26-L59C54)

<pre><code class="java">        HBaseClassTestRule timeout = (HBaseClassTestRule) field.get(null);
        assertEquals("The HBaseClassTestRule ClassRule in " + description.getTestClass().getName()
          + " is for " + <strong>timeout.getClazz().getName()</strong>, description.getTestClass(),
          timeout.getClazz());
        return;
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L58C63-L58C99)

<pre><code class="java">      ) {
        HBaseClassTestRule timeout = (HBaseClassTestRule) field.get(null);
        assertEquals("The HBaseClassTestRule ClassRule in " + <strong>description.getTestClass().getName()</strong>
          + " is for " + timeout.getClazz().getName(), description.getTestClass(),
          timeout.getClazz());
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L58C63-L58C89)

<pre><code class="java">      ) {
        HBaseClassTestRule timeout = (HBaseClassTestRule) field.get(null);
        assertEquals("The HBaseClassTestRule ClassRule in " + <strong>description.getTestClass()</strong>.getName()
          + " is for " + timeout.getClazz().getName(), description.getTestClass(),
          timeout.getClazz());
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L59C26-L59C44)

<pre><code class="java">        HBaseClassTestRule timeout = (HBaseClassTestRule) field.get(null);
        assertEquals("The HBaseClassTestRule ClassRule in " + description.getTestClass().getName()
          + " is for " + <strong>timeout.getClazz()</strong>.getName(), description.getTestClass(),
          timeout.getClazz());
        return;
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L64C5-L64C88)

<pre><code class="java">      }
    }
    <strong>fail("No HBaseClassTestRule ClassRule for " + description.getTestClass().getName())</strong>;
  }
}
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L64C51-L64C87)

<pre><code class="java">      }
    }
    fail("No HBaseClassTestRule ClassRule for " + <strong>description.getTestClass().getName()</strong>);
  }
}
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

[hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L64C51-L64C77)

<pre><code class="java">      }
    }
    fail("No HBaseClassTestRule ClassRule for " + <strong>description.getTestClass()</strong>.getName());
  }
}
</code></pre>

*Consider the method it being in a lock and make sure that the lock and unlock is on the same object.*

----------------------------------------

| m |  |
| --- | --- |
| [`getAnnotationsByType(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L42C29-L42C91) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getTestClass(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L42C29-L42C54) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`value(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L46C25-L46C45) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getFields(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L52C24-L52C61) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getTestClass(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L52C24-L52C49) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`isAnnotationPresent(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L55C14-L55C55) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`isStatic(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L54C9-L54C47) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getModifiers(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L54C27-L54C46) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getType(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L54C52-L54C66) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`get(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L57C59-L57C73) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`assertEquals(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L58C9-L60C29) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getTestClass(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L59C56-L59C81) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getClazz(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L60C11-L60C28) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getName(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L59C26-L59C53) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getName(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L58C63-L58C98) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getTestClass(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L58C63-L58C88) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getClazz(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L59C26-L59C43) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`fail(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L64C5-L64C87) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getName(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L64C51-L64C86) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |
| [`getTestClass(...)`](https://github.com/apache/hbase/blob/52e0a8cdaf6054c82faea7dac79ebc75925f8855/hbase-common/src/test/java/org/apache/hadoop/hbase/HBaseClassTestRuleChecker.java#L64C51-L64C76) | `Consider the method it being in a lock and make sure that the lock and unlock is on the same object.` |