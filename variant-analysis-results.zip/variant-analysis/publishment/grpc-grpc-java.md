### grpc/grpc-java

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L200C13-L200C23)

<pre><code class="java">    final Runnable task;
    boolean isCancelled;
    boolean <strong>hasStarted</strong>;

    ManagedRunnable(Runnable task) {
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/SynchronizationContext.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L199C13-L199C24)

<pre><code class="java">  private static class ManagedRunnable implements Runnable {
    final Runnable task;
    boolean <strong>isCancelled</strong>;
    boolean hasStarted;

</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L207C20-L207C34)

<pre><code class="java">  @GuardedBy("this")
  @Nullable
  protected Status <strong>shutdownStatus</strong>;

  @Nullable private OneWayBinderProxy outgoingBinder;
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L200C24-L200C34)

<pre><code class="java">
  @GuardedBy("this")
  protected Attributes <strong>attributes</strong>;

  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L60C10-L60C13)

<pre><code class="java">
  private static final class LongHolder {
    long <strong>num</strong>;
  }

</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L799C19-L799C24)

<pre><code class="java">  static final class TransportLogger extends ChannelLogger {
    // Changed just after construction to break a cyclic dependency.
    InternalLogId <strong>logId</strong>;

    @Override
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L476C23-L476C31)

<pre><code class="java">
  private final class ChannelStreamProvider implements ClientStreamProvider {
    volatile Throttle <strong>throttle</strong>;

    private ClientTransport getTransport(PickSubchannelArgs args) {
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1467C32-L1467C34)

<pre><code class="java">
  private final class LbHelperImpl extends LoadBalancer.Helper {
    AutoConfiguredLoadBalancer <strong>lb</strong>;

    @Override
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1934C13-L1934C21)

<pre><code class="java">    InternalSubchannel subchannel;
    boolean started;
    boolean <strong>shutdown</strong>;
    ScheduledHandle delayedShutdownTask;

</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1933C13-L1933C20)

<pre><code class="java">    List&lt;EquivalentAddressGroup&gt; addressGroups;
    InternalSubchannel subchannel;
    boolean <strong>started</strong>;
    boolean shutdown;
    ScheduledHandle delayedShutdownTask;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1932C24-L1932C34)

<pre><code class="java">    final ChannelTracer subchannelTracer;
    List&lt;EquivalentAddressGroup&gt; addressGroups;
    InternalSubchannel <strong>subchannel</strong>;
    boolean started;
    boolean shutdown;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1931C34-L1931C47)

<pre><code class="java">    final ChannelLoggerImpl subchannelLogger;
    final ChannelTracer subchannelTracer;
    List&lt;EquivalentAddressGroup&gt; <strong>addressGroups</strong>;
    InternalSubchannel subchannel;
    boolean started;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1396C12-L1396C26)

<pre><code class="java">
    @GuardedBy("lock")
    Status <strong>shutdownStatus</strong>;

    void onShutdown(Status reason) {
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1393C30-L1393C57)

<pre><code class="java">
    @GuardedBy("lock")
    Collection&lt;ClientStream&gt; <strong>uncommittedRetriableStreams</strong> = new HashSet&lt;&gt;();

    @GuardedBy("lock")
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/SharedResourceHolder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L177C9-L177C17)

<pre><code class="java">  private static class Instance {
    final Object payload;
    int <strong>refcount</strong>;
    ScheduledFuture&lt;?&gt; destroyTask;

</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L824C13-L824C22)

<pre><code class="java">  static final class MaybeTruncated&lt;T&gt; {
    T proto;
    boolean <strong>truncated</strong>;

    private MaybeTruncated(T proto, boolean truncated) {
</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L823C7-L823C12)

<pre><code class="java">
  static final class MaybeTruncated&lt;T&gt; {
    T <strong>proto</strong>;
    boolean truncated;

</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L378C18-L378C22)

<pre><code class="java">
  private final class SizedValue {
    volatile int <strong>size</strong>;
    final V value;

</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L186C23-L186C41)

<pre><code class="java">      private CallOptions callOptions = CallOptions.DEFAULT;
      private int previousAttempts;
      private boolean <strong>isTransparentRetry</strong>;

      Builder() {
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L185C19-L185C35)

<pre><code class="java">    public static final class Builder {
      private CallOptions callOptions = CallOptions.DEFAULT;
      private int <strong>previousAttempts</strong>;
      private boolean isTransparentRetry;

</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/ClientStreamTracer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L184C27-L184C38)

<pre><code class="java">     */
    public static final class Builder {
      private CallOptions <strong>callOptions</strong> = CallOptions.DEFAULT;
      private int previousAttempts;
      private boolean isTransparentRetry;
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/LoadBalancerRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/LoadBalancerRegistry.java#L44C39-L44C47)

<pre><code class="java">public final class LoadBalancerRegistry {
  private static final Logger logger = Logger.getLogger(LoadBalancerRegistry.class.getName());
  private static LoadBalancerRegistry <strong>instance</strong>;
  private static final Iterable&lt;Class&lt;?&gt;&gt; HARDCODED_CLASSES = getHardCodedClasses();

</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/ManagedChannelRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ManagedChannelRegistry.java#L52C40-L52C58)

<pre><code class="java">  /** Immutable, sorted version of {@code allProviders}. Is replaced instead of mutating. */
  @GuardedBy("this")
  private List&lt;ManagedChannelProvider&gt; <strong>effectiveProviders</strong> = Collections.emptyList();

  /**
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/ManagedChannelRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ManagedChannelRegistry.java#L46C41-L46C49)

<pre><code class="java">public final class ManagedChannelRegistry {
  private static final Logger logger = Logger.getLogger(ManagedChannelRegistry.class.getName());
  private static ManagedChannelRegistry <strong>instance</strong>;

  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/NameResolverRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/NameResolverRegistry.java#L59C54-L59C72)

<pre><code class="java">   * {@link NameResolverProvider}. Is replaced instead of mutating. */
  @GuardedBy("this")
  private ImmutableMap&lt;String, NameResolverProvider&gt; <strong>effectiveProviders</strong> = ImmutableMap.of();

  public synchronized String getDefaultScheme() {
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/NameResolverRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/NameResolverRegistry.java#L52C18-L52C31)

<pre><code class="java">  private static final String UNKNOWN_SCHEME = "unknown";
  @GuardedBy("this")
  private String <strong>defaultScheme</strong> = UNKNOWN_SCHEME;

  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/NameResolverRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/NameResolverRegistry.java#L47C39-L47C47)

<pre><code class="java">public final class NameResolverRegistry {
  private static final Logger logger = Logger.getLogger(NameResolverRegistry.class.getName());
  private static NameResolverRegistry <strong>instance</strong>;

  private final NameResolver.Factory factory = new NameResolverFactory();
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/ServerRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ServerRegistry.java#L45C32-L45C50)

<pre><code class="java">  /** Immutable, sorted version of {@code allProviders}. Is replaced instead of mutating. */
  @GuardedBy("this")
  private List&lt;ServerProvider&gt; <strong>effectiveProviders</strong> = Collections.emptyList();

  /**
</code></pre>

*Is not safely published*

----------------------------------------

[api/src/main/java/io/grpc/ServerRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ServerRegistry.java#L39C33-L39C41)

<pre><code class="java">public final class ServerRegistry {
  private static final Logger logger = Logger.getLogger(ServerRegistry.class.getName());
  private static ServerRegistry <strong>instance</strong>;

  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderServer.java#L69C19-L69C27)

<pre><code class="java">
  @GuardedBy("this")
  private boolean <strong>shutdown</strong>;

  /**
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderServer.java#L66C36-L66C51)

<pre><code class="java">
  @GuardedBy("this")
  private ScheduledExecutorService <strong>executorService</strong>;

  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderServer.java#L63C26-L63C34)

<pre><code class="java">
  @GuardedBy("this")
  private ServerListener <strong>listener</strong>;

  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L217C16-L217C41)

<pre><code class="java">
  /** The number of incoming bytes we've told our peer we've received. */
  private long <strong>acknowledgedIncomingBytes</strong>;

  private BinderTransport(
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L209C39-L209C53)

<pre><code class="java">  protected Status shutdownStatus;

  @Nullable private OneWayBinderProxy <strong>outgoingBinder</strong>;

  private final FlowController flowController;
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L203C26-L203C40)

<pre><code class="java">
  @GuardedBy("this")
  private TransportState <strong>transportState</strong> = TransportState.NOT_STARTED;

  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L571C17-L571C29)

<pre><code class="java">
    @GuardedBy("this")
    private int <strong>latestCallId</strong> = FIRST_CALL_ID;

    /**
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L568C55-L568C78)

<pre><code class="java">    private final PingTracker pingTracker;

    @Nullable private ManagedClientTransport.Listener <strong>clientTransportListener</strong>;

    @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/BinderTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L832C47-L832C70)

<pre><code class="java">
    private final List&lt;ServerStreamTracer.Factory&gt; streamTracerFactories;
    @Nullable private ServerTransportListener <strong>serverTransportListener</strong>;

    /**
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L97C17-L97C30)

<pre><code class="java">  @Nullable private Context sourceContext; // Only null in the unbound state.

  private State <strong>reportedState</strong>; // Only used on the main thread.

  @AnyThread
</code></pre>

*Is not safely published*

----------------------------------------

[binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L89C17-L89C22)

<pre><code class="java">
  @GuardedBy("this")
  private State <strong>state</strong>;

  // The following fields are intentionally not guarded, since (aside from the constructor),
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L158C18-L158C32)

<pre><code class="java">  private volatile ConnectivityStateInfo state = ConnectivityStateInfo.forNonError(IDLE);

  private Status <strong>shutdownReason</strong>;

  InternalSubchannel(List&lt;EquivalentAddressGroup&gt; addressGroups, String authority, String userAgent,
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L156C42-L156C47)

<pre><code class="java">  private volatile ManagedClientTransport activeTransport;

  private volatile ConnectivityStateInfo <strong>state</strong> = ConnectivityStateInfo.forNonError(IDLE);

  private Status shutdownReason;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L103C49-L103C62)

<pre><code class="java">   * unnecessary volatile reads while it delivers clearer intention of why .
   */
  private volatile List&lt;EquivalentAddressGroup&gt; <strong>addressGroups</strong>;

  /**
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/InternalSubchannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L719C42-L719C55)

<pre><code class="java">  @VisibleForTesting
  static final class Index {
    private List&lt;EquivalentAddressGroup&gt; <strong>addressGroups</strong>;
    private int groupIndex;
    private int addressIndex;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L290C39-L290C56)

<pre><code class="java">  // Must be mutated and read from constructor or syncContext
  // used for channel tracing when value changed
  private ManagedChannelServiceConfig <strong>lastServiceConfig</strong> = EMPTY_SERVICE_CONFIG;

  @Nullable
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L287C27-L287C46)

<pre><code class="java">  // Must be mutated and read from syncContext
  // a flag for doing channel tracing when flipped
  private ResolutionState <strong>lastResolutionState</strong> = ResolutionState.NO_RESOLUTION;
  // Must be mutated and read from constructor or syncContext
  // used for channel tracing when value changed
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L276C28-L276C38)

<pre><code class="java">  private boolean terminating;
  // Must be mutated from syncContext
  private volatile boolean <strong>terminated</strong>;
  private final CountDownLatch terminatedLatch = new CountDownLatch(1);

</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L274C19-L274C30)

<pre><code class="java">  private boolean shutdownNowed;
  // Must only be mutated from syncContext
  private boolean <strong>terminating</strong>;
  // Must be mutated from syncContext
  private volatile boolean terminated;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L272C19-L272C32)

<pre><code class="java">  private final AtomicBoolean shutdown = new AtomicBoolean(false);
  // Must only be mutated and read from syncContext
  private boolean <strong>shutdownNowed</strong>;
  // Must only be mutated from syncContext
  private boolean terminating;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L234C19-L234C28)

<pre><code class="java">
  // Must be accessed from the syncContext
  private boolean <strong>panicMode</strong>;

  // Must be mutated from syncContext
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L196C19-L196C42)

<pre><code class="java">      });

  private boolean <strong>fullStreamDecompression</strong>;

  private final DecompressorRegistry decompressorRegistry;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1187C37-L1187C45)

<pre><code class="java">    private CallOptions callOptions;

    private ClientCall&lt;ReqT, RespT&gt; <strong>delegate</strong>;

    ConfigSelectingClientCall(
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1185C25-L1185C36)

<pre><code class="java">    private final MethodDescriptor&lt;ReqT, RespT&gt; method;
    private final Context context;
    private CallOptions <strong>callOptions</strong>;

    private ClientCall&lt;ReqT, RespT&gt; delegate;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/ManagedChannelImpl.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2207C22-L2207C30)

<pre><code class="java">  static final class ExecutorHolder implements Executor {
    private final ObjectPool&lt;? extends Executor&gt; pool;
    private Executor <strong>executor</strong>;

    ExecutorHolder(ObjectPool&lt;? extends Executor&gt; executorPool) {
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L81C28-L81C36)

<pre><code class="java">  private final ScheduledExecutorService deadlineCancellationExecutor;
  private final CountDownLatch terminatedLatch = new CountDownLatch(1);
  private volatile boolean <strong>shutdown</strong>;
  private final CallTracer channelCallsTracer;
  private final ChannelTracer channelTracer;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L71C28-L71C44)

<pre><code class="java">  private InternalSubchannel subchannel;
  private AbstractSubchannel subchannelImpl;
  private SubchannelPicker <strong>subchannelPicker</strong>;

  private final InternalLogId logId;
</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L70C30-L70C44)

<pre><code class="java">
  private InternalSubchannel subchannel;
  private AbstractSubchannel <strong>subchannelImpl</strong>;
  private SubchannelPicker subchannelPicker;

</code></pre>

*Is not safely published*

----------------------------------------

[core/src/main/java/io/grpc/internal/OobChannel.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L69C30-L69C40)

<pre><code class="java">  private static final Logger log = Logger.getLogger(OobChannel.class.getName());

  private InternalSubchannel <strong>subchannel</strong>;
  private AbstractSubchannel subchannelImpl;
  private SubchannelPicker subchannelPicker;
</code></pre>

*Is not safely published*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L69C25-L69C51)

<pre><code class="java">  private volatile long callsFailedToSend;
  @SuppressWarnings("unused")
  private volatile long <strong>callsFinishedKnownReceived</strong>;

  GrpclbClientLoadRecorder(TimeProvider time) {
</code></pre>

*Is not safely published*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L67C25-L67C42)

<pre><code class="java">  private Map&lt;String, LongHolder&gt; callsDroppedPerToken = new HashMap&lt;&gt;(1);
  @SuppressWarnings("unused")
  private volatile long <strong>callsFailedToSend</strong>;
  @SuppressWarnings("unused")
  private volatile long callsFinishedKnownReceived;
</code></pre>

*Is not safely published*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L65C35-L65C55)

<pre><code class="java">  // Specific finish types
  @GuardedBy("this")
  private Map&lt;String, LongHolder&gt; <strong>callsDroppedPerToken</strong> = new HashMap&lt;&gt;(1);
  @SuppressWarnings("unused")
  private volatile long callsFailedToSend;
</code></pre>

*Is not safely published*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L57C25-L57C38)

<pre><code class="java">  private volatile long callsStarted;
  @SuppressWarnings("unused")
  private volatile long <strong>callsFinished</strong>;

  private static final class LongHolder {
</code></pre>

*Is not safely published*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L55C25-L55C37)

<pre><code class="java">  private final TimeProvider time;
  @SuppressWarnings("unused")
  private volatile long <strong>callsStarted</strong>;
  @SuppressWarnings("unused")
  private volatile long callsFinished;
</code></pre>

*Is not safely published*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L129C30-L129C46)

<pre><code class="java">  private class StreamTracer extends ClientStreamTracer {
    private volatile boolean headersSent;
    private volatile boolean <strong>anythingReceived</strong>;

    @Override
</code></pre>

*Is not safely published*

----------------------------------------

[grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L128C30-L128C41)

<pre><code class="java">
  private class StreamTracer extends ClientStreamTracer {
    private volatile boolean <strong>headersSent</strong>;
    private volatile boolean anythingReceived;

</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L63C36-L63C45)

<pre><code class="java">   * outlive this server, they must get their own reference.
   */
  private ScheduledExecutorService <strong>scheduler</strong>;

  InProcessServer(
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L56C19-L56C27)

<pre><code class="java">  private final List&lt;ServerStreamTracer.Factory&gt; streamTracerFactories;
  private ServerListener listener;
  private boolean <strong>shutdown</strong>;
  /** Defaults to be a SharedResourcePool. */
  private final ObjectPool&lt;ScheduledExecutorService&gt; schedulerPool;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L55C26-L55C34)

<pre><code class="java">  private final int maxInboundMetadataSize;
  private final List&lt;ServerStreamTracer.Factory&gt; streamTracerFactories;
  private ServerListener <strong>listener</strong>;
  private boolean shutdown;
  /** Defaults to be a SharedResourcePool. */
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L111C43-L111C67)

<pre><code class="java">  private Attributes attributes;

  private Thread.UncaughtExceptionHandler <strong>uncaughtExceptionHandler</strong> =
      new Thread.UncaughtExceptionHandler() {
        @Override
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L109C22-L109C32)

<pre><code class="java">  @GuardedBy("this")
  private List&lt;ServerStreamTracer.Factory&gt; serverStreamTracerFactories;
  private Attributes <strong>attributes</strong>;

  private Thread.UncaughtExceptionHandler uncaughtExceptionHandler =
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L108C44-L108C71)

<pre><code class="java">          new IdentityHashMap&lt;InProcessStream, Boolean&gt;());
  @GuardedBy("this")
  private List&lt;ServerStreamTracer.Factory&gt; <strong>serverStreamTracerFactories</strong>;
  private Attributes attributes;

</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L103C18-L103C32)

<pre><code class="java">  private boolean terminated;
  @GuardedBy("this")
  private Status <strong>shutdownStatus</strong>;
  @GuardedBy("this")
  private final Set&lt;InProcessStream&gt; streams = Collections.newSetFromMap(
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L101C19-L101C29)

<pre><code class="java">  private boolean shutdown;
  @GuardedBy("this")
  private boolean <strong>terminated</strong>;
  @GuardedBy("this")
  private Status shutdownStatus;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L99C19-L99C27)

<pre><code class="java">  private ManagedClientTransport.Listener clientTransportListener;
  @GuardedBy("this")
  private boolean <strong>shutdown</strong>;
  @GuardedBy("this")
  private boolean terminated;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L97C43-L97C66)

<pre><code class="java">  private ServerTransportListener serverTransportListener;
  private Attributes serverStreamAttributes;
  private ManagedClientTransport.Listener <strong>clientTransportListener</strong>;
  @GuardedBy("this")
  private boolean shutdown;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L96C22-L96C44)

<pre><code class="java">  private ScheduledExecutorService serverScheduler;
  private ServerTransportListener serverTransportListener;
  private Attributes <strong>serverStreamAttributes</strong>;
  private ManagedClientTransport.Listener clientTransportListener;
  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L95C35-L95C58)

<pre><code class="java">  private ObjectPool&lt;ScheduledExecutorService&gt; serverSchedulerPool;
  private ScheduledExecutorService serverScheduler;
  private ServerTransportListener <strong>serverTransportListener</strong>;
  private Attributes serverStreamAttributes;
  private ManagedClientTransport.Listener clientTransportListener;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L94C36-L94C51)

<pre><code class="java">  private final boolean includeCauseWithStatus;
  private ObjectPool&lt;ScheduledExecutorService&gt; serverSchedulerPool;
  private ScheduledExecutorService <strong>serverScheduler</strong>;
  private ServerTransportListener serverTransportListener;
  private Attributes serverStreamAttributes;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L93C48-L93C67)

<pre><code class="java">  private int serverMaxInboundMetadataSize;
  private final boolean includeCauseWithStatus;
  private ObjectPool&lt;ScheduledExecutorService&gt; <strong>serverSchedulerPool</strong>;
  private ScheduledExecutorService serverScheduler;
  private ServerTransportListener serverTransportListener;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L91C15-L91C43)

<pre><code class="java">  private final String userAgent;
  private final Optional&lt;ServerListener&gt; optionalServerListener;
  private int <strong>serverMaxInboundMetadataSize</strong>;
  private final boolean includeCauseWithStatus;
  private ObjectPool&lt;ScheduledExecutorService&gt; serverSchedulerPool;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L396C29-L396C38)

<pre><code class="java">    private final Metadata headers;
    private final MethodDescriptor&lt;?, ?&gt; method;
    private volatile String <strong>authority</strong>;

    private InProcessStream(
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L443C19-L443C32)

<pre><code class="java">      private boolean closed;
      @GuardedBy("this")
      private int <strong>outboundSeqNo</strong>;

      InProcessServerStream(MethodDescriptor&lt;?, ?&gt; method, Metadata headers) {
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L441C23-L441C29)

<pre><code class="java">      // Only is intended to prevent double-close when client cancels.
      @GuardedBy("this")
      private boolean <strong>closed</strong>;
      @GuardedBy("this")
      private int outboundSeqNo;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L438C24-L438C44)

<pre><code class="java">      private Status clientNotifyStatus;
      @GuardedBy("this")
      private Metadata <strong>clientNotifyTrailers</strong>;
      // Only is intended to prevent double-close when client cancels.
      @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L436C22-L436C40)

<pre><code class="java">          new ArrayDeque&lt;&gt;();
      @GuardedBy("this")
      private Status <strong>clientNotifyStatus</strong>;
      @GuardedBy("this")
      private Metadata clientNotifyTrailers;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L433C58-L433C76)

<pre><code class="java">      private int clientRequested;
      @GuardedBy("this")
      private ArrayDeque&lt;StreamListener.MessageProducer&gt; <strong>clientReceiveQueue</strong> =
          new ArrayDeque&lt;&gt;();
      @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L431C19-L431C34)

<pre><code class="java">          new SynchronizationContext(uncaughtExceptionHandler);
      @GuardedBy("this")
      private int <strong>clientRequested</strong>;
      @GuardedBy("this")
      private ArrayDeque&lt;StreamListener.MessageProducer&gt; clientReceiveQueue =
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L427C36-L427C56)

<pre><code class="java">      final StatsTraceContext statsTraceCtx;
      // All callbacks must run in syncContext to avoid possibility of deadlock in direct executors
      private ClientStreamListener <strong>clientStreamListener</strong>;
      private final SynchronizationContext syncContext =
          new SynchronizationContext(uncaughtExceptionHandler);
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L725C19-L725C32)

<pre><code class="java">      private boolean closed;
      @GuardedBy("this")
      private int <strong>outboundSeqNo</strong>;

      InProcessClientStream(
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L723C23-L723C29)

<pre><code class="java">      // Only is intended to prevent double-close when server closes.
      @GuardedBy("this")
      private boolean <strong>closed</strong>;
      @GuardedBy("this")
      private int outboundSeqNo;
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L717C58-L717C76)

<pre><code class="java">      private int serverRequested;
      @GuardedBy("this")
      private ArrayDeque&lt;StreamListener.MessageProducer&gt; <strong>serverReceiveQueue</strong> =
          new ArrayDeque&lt;&gt;();
      @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L715C19-L715C34)

<pre><code class="java">          new SynchronizationContext(uncaughtExceptionHandler);
      @GuardedBy("this")
      private int <strong>serverRequested</strong>;
      @GuardedBy("this")
      private ArrayDeque&lt;StreamListener.MessageProducer&gt; serverReceiveQueue =
</code></pre>

*Is not safely published*

----------------------------------------

[inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L711C36-L711C56)

<pre><code class="java">      final CallOptions callOptions;
      // All callbacks must run in syncContext to avoid possibility of deadlock in direct executors
      private ServerStreamListener <strong>serverStreamListener</strong>;
      private final SynchronizationContext syncContext =
          new SynchronizationContext(uncaughtExceptionHandler);
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L725C20-L725C26)

<pre><code class="java">  static final class Builder {

    private Helper <strong>helper</strong>;
    private LbPolicyConfiguration lbPolicyConfig;
    private Throttler throttler = new HappyThrottler();
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L726C35-L726C49)

<pre><code class="java">
    private Helper helper;
    private LbPolicyConfiguration <strong>lbPolicyConfig</strong>;
    private Throttler throttler = new HappyThrottler();
    private ResolvedAddressFactory resolvedAddressFactory;
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L729C20-L729C26)

<pre><code class="java">    private Throttler throttler = new HappyThrottler();
    private ResolvedAddressFactory resolvedAddressFactory;
    private Ticker <strong>ticker</strong> = Ticker.systemTicker();
    private EvictionListener&lt;RouteLookupRequest, CacheEntry&gt; evictionListener;
    private BackoffPolicy.Provider backoffProvider = new ExponentialBackoffPolicy.Provider();
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L727C23-L727C32)

<pre><code class="java">    private Helper helper;
    private LbPolicyConfiguration lbPolicyConfig;
    private Throttler <strong>throttler</strong> = new HappyThrottler();
    private ResolvedAddressFactory resolvedAddressFactory;
    private Ticker ticker = Ticker.systemTicker();
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L730C62-L730C78)

<pre><code class="java">    private ResolvedAddressFactory resolvedAddressFactory;
    private Ticker ticker = Ticker.systemTicker();
    private EvictionListener&lt;RouteLookupRequest, CacheEntry&gt; <strong>evictionListener</strong>;
    private BackoffPolicy.Provider backoffProvider = new ExponentialBackoffPolicy.Provider();

</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L728C36-L728C58)

<pre><code class="java">    private LbPolicyConfiguration lbPolicyConfig;
    private Throttler throttler = new HappyThrottler();
    private ResolvedAddressFactory <strong>resolvedAddressFactory</strong>;
    private Ticker ticker = Ticker.systemTicker();
    private EvictionListener&lt;RouteLookupRequest, CacheEntry&gt; evictionListener;
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L731C36-L731C51)

<pre><code class="java">    private Ticker ticker = Ticker.systemTicker();
    private EvictionListener&lt;RouteLookupRequest, CacheEntry&gt; evictionListener;
    private BackoffPolicy.Provider <strong>backoffProvider</strong> = new ExponentialBackoffPolicy.Provider();

    Builder setHelper(Helper helper) {
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L681C23-L681C38)

<pre><code class="java">    private final Status status;
    private final BackoffPolicy backoffPolicy;
    private Future&lt;?&gt; <strong>scheduledFuture</strong>;

    BackoffCacheEntry(RouteLookupRequest request, Status status, BackoffPolicy backoffPolicy) {
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L373C30-L373C36)

<pre><code class="java">    final Helper helper;
    private ConnectivityState state;
    private SubchannelPicker <strong>picker</strong>;

    RlsLbHelper(Helper helper) {
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L372C31-L372C36)

<pre><code class="java">
    final Helper helper;
    private ConnectivityState <strong>state</strong>;
    private SubchannelPicker picker;

</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L962C32-L962C58)

<pre><code class="java">    }

    private ChildPolicyWrapper <strong>fallbackChildPolicyWrapper</strong>;

    /** Uses Subchannel connected to default target. */
</code></pre>

*Is not safely published*

----------------------------------------

[rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L59C16-L59C37)

<pre><code class="java">  private final EvictionListener&lt;K, SizedValue&gt; evictionListener;
  private final AtomicLong estimatedSizeBytes = new AtomicLong();
  private long <strong>estimatedMaxSizeBytes</strong>;

  LinkedHashLruCache(
</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L100C26-L100C38)

<pre><code class="java">  static final class SinkWriterImpl extends SinkWriter {
    private final BinaryLogSink sink;
    private TimeProvider <strong>timeProvider</strong>;
    private final int maxHeaderBytes;
    private final int maxMessageBytes;
</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L51C28-L51C36)

<pre><code class="java">  private double qps = 0;
  private double eps = 0;
  private volatile boolean <strong>disabled</strong>;

  /**
</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L50C18-L50C21)

<pre><code class="java">  private double memoryUtilizationMetric = 0;
  private double qps = 0;
  private double <strong>eps</strong> = 0;
  private volatile boolean disabled;

</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L49C18-L49C21)

<pre><code class="java">  private double applicationUtilizationMetric = 0;
  private double memoryUtilizationMetric = 0;
  private double <strong>qps</strong> = 0;
  private double eps = 0;
  private volatile boolean disabled;
</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L48C18-L48C41)

<pre><code class="java">  private double cpuUtilizationMetric = 0;
  private double applicationUtilizationMetric = 0;
  private double <strong>memoryUtilizationMetric</strong> = 0;
  private double qps = 0;
  private double eps = 0;
</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L47C18-L47C46)

<pre><code class="java">      new AtomicReference&lt;&gt;();
  private double cpuUtilizationMetric = 0;
  private double <strong>applicationUtilizationMetric</strong> = 0;
  private double memoryUtilizationMetric = 0;
  private double qps = 0;
</code></pre>

*Is not safely published*

----------------------------------------

[services/src/main/java/io/grpc/services/CallMetricRecorder.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L46C18-L46C38)

<pre><code class="java">  private final AtomicReference&lt;ConcurrentHashMap&lt;String, Double&gt;&gt; namedMetrics =
      new AtomicReference&lt;&gt;();
  private double <strong>cpuUtilizationMetric</strong> = 0;
  private double applicationUtilizationMetric = 0;
  private double memoryUtilizationMetric = 0;
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L56C42-L56C55)

<pre><code class="java">  private final Object lock = new Object();
  private final AtomicReference&lt;Map&lt;String, ?&gt;&gt; bootstrapOverride = new AtomicReference&lt;&gt;();
  private volatile ObjectPool&lt;XdsClient&gt; <strong>xdsClientPool</strong>;

  SharedXdsClientPoolProvider() {
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L120C17-L120C25)

<pre><code class="java">    private XdsClient xdsClient;
    @GuardedBy("lock")
    private int <strong>refCount</strong>;

    @VisibleForTesting
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L116C38-L116C47)

<pre><code class="java">    private final Object lock = new Object();
    @GuardedBy("lock")
    private ScheduledExecutorService <strong>scheduler</strong>;
    @GuardedBy("lock")
    private XdsClient xdsClient;
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/XdsCredentialsRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/XdsCredentialsRegistry.java#L55C56-L55C74)

<pre><code class="java">   */
  @GuardedBy("this")
  private ImmutableMap&lt;String, XdsCredentialsProvider&gt; <strong>effectiveProviders</strong> = ImmutableMap.of();

  /**
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/XdsCredentialsRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/XdsCredentialsRegistry.java#L44C41-L44C49)

<pre><code class="java">final class XdsCredentialsRegistry {
  private static final Logger logger = Logger.getLogger(XdsCredentialsRegistry.class.getName());
  private static XdsCredentialsRegistry <strong>instance</strong>;

  @GuardedBy("this")
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java#L332C49-L332C67)

<pre><code class="java">    private final AtomicLong callsFailed = new AtomicLong();
    private final AtomicLong callsIssued = new AtomicLong();
    private Map&lt;String, BackendLoadMetricStats&gt; <strong>loadMetricStatsMap</strong> = new HashMap&lt;&gt;();

    private ClusterLocalityStats(
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L111C17-L111C25)

<pre><code class="java">  private static final class Instance&lt;V extends Closeable&gt; {
    final V value;
    private int <strong>refCount</strong>;

    /** Increment refCount and acquire a reference to value. */
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderRegistry.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderRegistry.java#L29C46-L29C54)

<pre><code class="java">@ThreadSafe
public final class CertificateProviderRegistry {
  private static CertificateProviderRegistry <strong>instance</strong>;
  private final LinkedHashMap&lt;String, CertificateProviderProvider&gt; providers =
      new LinkedHashMap&lt;&gt;();
</code></pre>

*Is not safely published*

----------------------------------------

[xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderStore.java](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderStore.java#L38C43-L38C51)

<pre><code class="java">  private static final Logger logger = Logger.getLogger(CertificateProviderStore.class.getName());

  private static CertificateProviderStore <strong>instance</strong>;
  private final CertificateProviderRegistry certificateProviderRegistry;
  private final ReferenceCountingMap&lt;CertProviderKey, CertificateProvider&gt; certProviderMap;
</code></pre>

*Is not safely published*

----------------------------------------

| f |  |
| --- | --- |
| [`hasStarted`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L200C13-L200C22) | `Is not safely published` |
| [`isCancelled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/SynchronizationContext.java#L199C13-L199C23) | `Is not safely published` |
| [`shutdownStatus`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L207C20-L207C33) | `Is not safely published` |
| [`attributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L200C24-L200C33) | `Is not safely published` |
| [`num`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L60C10-L60C12) | `Is not safely published` |
| [`logId`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L799C19-L799C23) | `Is not safely published` |
| [`throttle`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L476C23-L476C30) | `Is not safely published` |
| [`lb`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1467C32-L1467C33) | `Is not safely published` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1934C13-L1934C20) | `Is not safely published` |
| [`started`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1933C13-L1933C19) | `Is not safely published` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1932C24-L1932C33) | `Is not safely published` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1931C34-L1931C46) | `Is not safely published` |
| [`shutdownStatus`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1396C12-L1396C25) | `Is not safely published` |
| [`uncommittedRetriableStreams`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1393C30-L1393C56) | `Is not safely published` |
| [`refcount`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/SharedResourceHolder.java#L177C9-L177C16) | `Is not safely published` |
| [`truncated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L824C13-L824C21) | `Is not safely published` |
| [`proto`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L823C7-L823C11) | `Is not safely published` |
| [`size`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L378C18-L378C21) | `Is not safely published` |
| [`isTransparentRetry`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L186C23-L186C40) | `Is not safely published` |
| [`previousAttempts`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L185C19-L185C34) | `Is not safely published` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ClientStreamTracer.java#L184C27-L184C37) | `Is not safely published` |
| [`instance`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/LoadBalancerRegistry.java#L44C39-L44C46) | `Is not safely published` |
| [`effectiveProviders`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ManagedChannelRegistry.java#L52C40-L52C57) | `Is not safely published` |
| [`instance`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ManagedChannelRegistry.java#L46C41-L46C48) | `Is not safely published` |
| [`effectiveProviders`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/NameResolverRegistry.java#L59C54-L59C71) | `Is not safely published` |
| [`defaultScheme`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/NameResolverRegistry.java#L52C18-L52C30) | `Is not safely published` |
| [`instance`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/NameResolverRegistry.java#L47C39-L47C46) | `Is not safely published` |
| [`effectiveProviders`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ServerRegistry.java#L45C32-L45C49) | `Is not safely published` |
| [`instance`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/api/src/main/java/io/grpc/ServerRegistry.java#L39C33-L39C40) | `Is not safely published` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderServer.java#L69C19-L69C26) | `Is not safely published` |
| [`executorService`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderServer.java#L66C36-L66C50) | `Is not safely published` |
| [`listener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderServer.java#L63C26-L63C33) | `Is not safely published` |
| [`acknowledgedIncomingBytes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L217C16-L217C40) | `Is not safely published` |
| [`outgoingBinder`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L209C39-L209C52) | `Is not safely published` |
| [`transportState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L203C26-L203C39) | `Is not safely published` |
| [`latestCallId`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L571C17-L571C28) | `Is not safely published` |
| [`clientTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L568C55-L568C77) | `Is not safely published` |
| [`serverTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/BinderTransport.java#L832C47-L832C69) | `Is not safely published` |
| [`reportedState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L97C17-L97C29) | `Is not safely published` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/binder/src/main/java/io/grpc/binder/internal/ServiceBinding.java#L89C17-L89C21) | `Is not safely published` |
| [`shutdownReason`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L158C18-L158C31) | `Is not safely published` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L156C42-L156C46) | `Is not safely published` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L103C49-L103C61) | `Is not safely published` |
| [`addressGroups`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/InternalSubchannel.java#L719C42-L719C54) | `Is not safely published` |
| [`lastServiceConfig`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L290C39-L290C55) | `Is not safely published` |
| [`lastResolutionState`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L287C27-L287C45) | `Is not safely published` |
| [`terminated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L276C28-L276C37) | `Is not safely published` |
| [`terminating`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L274C19-L274C29) | `Is not safely published` |
| [`shutdownNowed`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L272C19-L272C31) | `Is not safely published` |
| [`panicMode`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L234C19-L234C27) | `Is not safely published` |
| [`fullStreamDecompression`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L196C19-L196C41) | `Is not safely published` |
| [`delegate`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1187C37-L1187C44) | `Is not safely published` |
| [`callOptions`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L1185C25-L1185C35) | `Is not safely published` |
| [`executor`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/ManagedChannelImpl.java#L2207C22-L2207C29) | `Is not safely published` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L81C28-L81C35) | `Is not safely published` |
| [`subchannelPicker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L71C28-L71C43) | `Is not safely published` |
| [`subchannelImpl`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L70C30-L70C43) | `Is not safely published` |
| [`subchannel`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/core/src/main/java/io/grpc/internal/OobChannel.java#L69C30-L69C39) | `Is not safely published` |
| [`callsFinishedKnownReceived`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L69C25-L69C50) | `Is not safely published` |
| [`callsFailedToSend`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L67C25-L67C41) | `Is not safely published` |
| [`callsDroppedPerToken`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L65C35-L65C54) | `Is not safely published` |
| [`callsFinished`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L57C25-L57C37) | `Is not safely published` |
| [`callsStarted`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L55C25-L55C36) | `Is not safely published` |
| [`anythingReceived`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L129C30-L129C45) | `Is not safely published` |
| [`headersSent`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/grpclb/src/main/java/io/grpc/grpclb/GrpclbClientLoadRecorder.java#L128C30-L128C40) | `Is not safely published` |
| [`scheduler`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L63C36-L63C44) | `Is not safely published` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L56C19-L56C26) | `Is not safely published` |
| [`listener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessServer.java#L55C26-L55C33) | `Is not safely published` |
| [`uncaughtExceptionHandler`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L111C43-L111C66) | `Is not safely published` |
| [`attributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L109C22-L109C31) | `Is not safely published` |
| [`serverStreamTracerFactories`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L108C44-L108C70) | `Is not safely published` |
| [`shutdownStatus`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L103C18-L103C31) | `Is not safely published` |
| [`terminated`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L101C19-L101C28) | `Is not safely published` |
| [`shutdown`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L99C19-L99C26) | `Is not safely published` |
| [`clientTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L97C43-L97C65) | `Is not safely published` |
| [`serverStreamAttributes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L96C22-L96C43) | `Is not safely published` |
| [`serverTransportListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L95C35-L95C57) | `Is not safely published` |
| [`serverScheduler`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L94C36-L94C50) | `Is not safely published` |
| [`serverSchedulerPool`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L93C48-L93C66) | `Is not safely published` |
| [`serverMaxInboundMetadataSize`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L91C15-L91C42) | `Is not safely published` |
| [`authority`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L396C29-L396C37) | `Is not safely published` |
| [`outboundSeqNo`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L443C19-L443C31) | `Is not safely published` |
| [`closed`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L441C23-L441C28) | `Is not safely published` |
| [`clientNotifyTrailers`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L438C24-L438C43) | `Is not safely published` |
| [`clientNotifyStatus`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L436C22-L436C39) | `Is not safely published` |
| [`clientReceiveQueue`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L433C58-L433C75) | `Is not safely published` |
| [`clientRequested`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L431C19-L431C33) | `Is not safely published` |
| [`clientStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L427C36-L427C55) | `Is not safely published` |
| [`outboundSeqNo`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L725C19-L725C31) | `Is not safely published` |
| [`closed`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L723C23-L723C28) | `Is not safely published` |
| [`serverReceiveQueue`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L717C58-L717C75) | `Is not safely published` |
| [`serverRequested`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L715C19-L715C33) | `Is not safely published` |
| [`serverStreamListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/inprocess/src/main/java/io/grpc/inprocess/InProcessTransport.java#L711C36-L711C55) | `Is not safely published` |
| [`helper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L725C20-L725C25) | `Is not safely published` |
| [`lbPolicyConfig`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L726C35-L726C48) | `Is not safely published` |
| [`ticker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L729C20-L729C25) | `Is not safely published` |
| [`throttler`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L727C23-L727C31) | `Is not safely published` |
| [`evictionListener`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L730C62-L730C77) | `Is not safely published` |
| [`resolvedAddressFactory`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L728C36-L728C57) | `Is not safely published` |
| [`backoffProvider`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L731C36-L731C50) | `Is not safely published` |
| [`scheduledFuture`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L681C23-L681C37) | `Is not safely published` |
| [`picker`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L373C30-L373C35) | `Is not safely published` |
| [`state`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L372C31-L372C35) | `Is not safely published` |
| [`fallbackChildPolicyWrapper`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/CachingRlsLbClient.java#L962C32-L962C57) | `Is not safely published` |
| [`estimatedMaxSizeBytes`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/rls/src/main/java/io/grpc/rls/LinkedHashLruCache.java#L59C16-L59C36) | `Is not safely published` |
| [`timeProvider`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/protobuf/services/BinlogHelper.java#L100C26-L100C37) | `Is not safely published` |
| [`disabled`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L51C28-L51C35) | `Is not safely published` |
| [`eps`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L50C18-L50C20) | `Is not safely published` |
| [`qps`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L49C18-L49C20) | `Is not safely published` |
| [`memoryUtilizationMetric`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L48C18-L48C40) | `Is not safely published` |
| [`applicationUtilizationMetric`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L47C18-L47C45) | `Is not safely published` |
| [`cpuUtilizationMetric`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/services/src/main/java/io/grpc/services/CallMetricRecorder.java#L46C18-L46C37) | `Is not safely published` |
| [`xdsClientPool`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L56C42-L56C54) | `Is not safely published` |
| [`refCount`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L120C17-L120C24) | `Is not safely published` |
| [`scheduler`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/SharedXdsClientPoolProvider.java#L116C38-L116C46) | `Is not safely published` |
| [`effectiveProviders`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/XdsCredentialsRegistry.java#L55C56-L55C73) | `Is not safely published` |
| [`instance`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/XdsCredentialsRegistry.java#L44C41-L44C48) | `Is not safely published` |
| [`loadMetricStatsMap`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/client/LoadStatsManager2.java#L332C49-L332C66) | `Is not safely published` |
| [`refCount`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/ReferenceCountingMap.java#L111C17-L111C24) | `Is not safely published` |
| [`instance`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderRegistry.java#L29C46-L29C53) | `Is not safely published` |
| [`instance`](https://github.com/grpc/grpc-java/blob/da619e2bde611efd623ec1ec397a3b8c25931966/xds/src/main/java/io/grpc/xds/internal/security/certprovider/CertificateProviderStore.java#L38C43-L38C50) | `Is not safely published` |